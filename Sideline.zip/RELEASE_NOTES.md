**Sideline 3.2.1**

**Fixes**
- **Photos:** galleries only show photos from that game or event.
- **Scores:** both scores now show on game pages when they're three digits.
