**Sideline 3.2**

**New**
- **Win probability chart:** see how each team's chances swung over the game, live or after it ends.
- **Football drives:** every drive with its result, yards, plays and time, plus the one in progress.
- **Recaps:** finished games show ESPN's game story right in the app.
- **Season calendar:** add a team's whole season to your phone's calendar from its schedule. Changed times update the next time you open the team, and you can remove the games anytime.
- **Compare players:** pick two players from the same league and see their stats side by side.
- **Golf scorecards:** tap a golfer on the leaderboard to see their scores hole by hole, when ESPN posts them.
- **Screen reader support:** TalkBack now reads buttons, section headings and live graphics like the count, the field and shot charts. You can reorder lists with Move up and Move down.

**Fixes**
- **Between innings:** baseball now shows who's taking the field, their correct pitcher and the next three batters due up, instead of the count from the last at-bat.
