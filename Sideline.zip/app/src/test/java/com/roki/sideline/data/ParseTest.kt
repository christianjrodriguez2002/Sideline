package com.roki.sideline.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Parsers against ESPN-shaped samples, including the shape differences between leagues and endpoints. */
class ParseTest {
    private object L {
        val NBA = Leagues.of("NBA")!!
        val MLB = Leagues.of("MLB")!!
        val NFL = Leagues.of("NFL")!!
        val NHL = Leagues.of("NHL")!!
        val EPL = Leagues.of("EPL")!!
    }
    private fun json(name: String): JSONObject =
        JSONObject(javaClass.getResource("/$name")!!.readText())

    @Test fun scoreboardFinalAndUpcoming() {
        val games = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        assertEquals(2, games.size)
        val fin = games.first { it.id == "401800001" }
        assertEquals(GameState.POST, fin.state)
        assertEquals("121", fin.home.score)
        assertTrue(fin.home.winner)
        assertEquals("3-1", fin.home.record)
        assertEquals(listOf("30", "28", "33", "30"), fin.home.linescores)
        assertEquals("Stephen Curry", fin.home.leaders.single().athleteName)
        assertEquals(listOf("ESPN"), fin.broadcasts.map { it.network })
        assertEquals("Chase Center, San Francisco", fin.venue)

        val pre = games.first { it.id == "401800002" }
        assertEquals(GameState.PRE, pre.state)
        assertEquals("LAL", pre.home.team.abbr)
        assertEquals("LAL -4.5", pre.odds!!.details)
        assertEquals("228.5", pre.odds!!.overUnder)
        assertEquals("-180", pre.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video", "Spectrum SportsNet"), pre.broadcasts.map { it.network })
        assertFalse(pre.broadcasts[1].national)
    }

    @Test fun liveBaseballSituation() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        assertEquals(GameState.IN, g.state)
        assertEquals("2-1 · 1 out · on 1st, 3rd", g.situation)
        assertEquals("Ohtani singled to right.", g.lastPlay)
        assertEquals("World Series - Game 2", g.note)
        assertEquals("LAD", g.away.team.abbr)
    }

    @Test fun nflWeek() {
        assertEquals(8 to 2, Parse.week(json("nfl_scoreboard_week.json")))
        assertNull(Parse.week(json("nba_scoreboard.json")))
    }

    @Test fun standingsNestedAndSorted() {
        val tables = Parse.standings(json("nfl_standings.json"), L.NFL)
        assertEquals(listOf("American Football Conference", "NFC West"), tables.map { it.title })
        val afc = tables[0]
        assertEquals("BUF", afc.rows[0].team.abbr) // 1.000 sorts above .857
        assertEquals("Clinched Playoff Berth", afc.rows[1].note)
        assertEquals(listOf("W", "L", "T", "PCT", "PF", "PA", "DIFF", "STRK"), afc.columns.map { it.first })
        assertEquals("+110", afc.rows[0].stats["DIFF"])
        assertEquals(listOf("W", "L", "T", "PCT", "STRK"), tables[1].columns.map { it.first })
    }

    @Test fun nhlStandingsByPoints() {
        val t = Parse.standings(json("nhl_standings.json"), L.NHL).single()
        assertEquals(listOf("COL", "DAL", "UTA"), t.rows.map { it.team.abbr }) // 14 pts, then 13 in fewer games
        assertEquals("1", t.rows[1].stats["OTL"])
    }

    @Test fun rostersGroupedAndFlat() {
        val nfl = Parse.roster(json("nfl_roster.json"))
        assertEquals(2, nfl.size)
        val k = nfl[0]
        assertEquals("Kyler Murray", k.name)
        assertEquals("Offense", k.group)
        assertEquals("QB", k.position)
        assertEquals("Bedford, TX", k.birthPlace)
        assertEquals("8 yrs", k.experience)
        assertEquals("Questionable", k.injuryStatus)
        assertEquals("22", k.teamId)
        assertEquals("Rookie", nfl[1].experience)

        val nba = Parse.roster(json("nba_roster.json"))
        assertEquals(listOf("Devin Booker", "No Id Ok"), nba.map { it.name })
        assertEquals("Shooting Guard", nba[0].group)
    }

    @Test fun injuriesGroupedByTeam() {
        val list = Parse.injuries(json("nfl_injuries.json"))
        assertEquals(2, list.size)
        val k = list[0]
        assertEquals("22", k.teamId)
        assertEquals("Arizona Cardinals", k.teamName)
        assertEquals("https://l/ari.png", k.teamLogo)
        assertEquals("Questionable", k.status)
        assertEquals("Right Leg Foot", k.type)
        assertEquals("2026-10-26", k.returnDate)
        assertNotNull(k.date)
        assertEquals("Ankle", list[1].type)
        assertEquals("12", list[1].teamId)
    }

    @Test fun gameSummary() {
        val d = Parse.gameDetail(json("nba_summary.json"), L.NBA)!!
        assertEquals(63.4, d.homeWinPct!!, 0.001)
        assertEquals(36.6, d.awayWinPct!!, 0.001)
        assertEquals("ESPN BPI Win Probability", d.predictorName)
        assertEquals("3-0", d.game.home.record)
        assertEquals("Crypto.com Arena, Los Angeles", d.game.venue)
        assertEquals("", d.attendance)
        assertEquals(listOf(StatLine("PPG", "110.3", "118.0")), d.teamStats)
        assertEquals("PHX", d.leaders.single().first)
        assertEquals("27.5 PPG", d.leaders.single().second.single().value)
        assertEquals("D. Booker", d.box.single().rows.single().first)
        assertEquals(listOf("MIN", "PTS"), d.box.single().labels)
        assertEquals("LeBron James", d.injuries.single().athleteName)
        assertEquals(1, d.scoringPlays.size)
        assertTrue(d.scoringPlays[0].contains("PHX: Booker makes 3 (3-0)"))
        assertEquals("Series tied 1-1", d.seasonSeries)
        assertEquals("-180", d.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video"), d.broadcasts.map { it.network })
    }

    @Test fun teamScheduleScoresAreObjects() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)
        assertEquals(2, games.size)
        assertEquals(listOf(7, 9), games.map { it.week })
        assertEquals(8, Parse.byeWeek(json("nfl_schedule.json")))
        assertEquals(0, Parse.byeWeek(json("nba_roster.json")))
        val past = games[0]
        assertEquals(GameState.POST, past.state)
        assertEquals("27", past.home.score)
        assertEquals("20", past.away.score)
        assertEquals("4-3", past.home.record)
        assertEquals(listOf("FOX"), past.broadcasts.map { it.network })
        assertEquals("DAL", games[1].home.team.abbr)
    }

    @Test fun athleteOverview() {
        val o = Parse.overview(json("athlete_overview.json"))
        assertEquals(listOf("GP", "PTS", "REB", "AST"), o.labels)
        assertEquals(listOf("Regular Season", "Career"), o.rows.map { it.label })
        assertEquals("Booker drops 30", o.news.single().headline)
        assertEquals("Booker scores 30 in win", o.injuryNote)
        assertEquals("Phoenix Suns at Los Angeles Lakers", o.nextGame)
    }

    @Test fun teamsNewsMovesDetail() {
        assertEquals(listOf("Arizona Cardinals", "Atlanta Falcons").sorted(), Parse.teams(json("nfl_teams.json")).map { it.name })
        val news = Parse.articles(json("news.json"))
        assertEquals(1, news.size)
        assertEquals("https://i/x.jpg", news[0].image)
        assertEquals("Placed QB X on injured reserve.", Parse.transactions(json("transactions.json")).single().description)
        val td = Parse.teamDetail(json("team_detail.json"))!!
        assertEquals("4-3", td.record)
        assertEquals("2nd in NFC West", td.standingSummary)
        assertEquals("Home Record" to "3-1", td.recordDetails[1])
    }

    @Test fun streamingAndPrediction() {
        assertEquals("HBO Max", Streaming.appFor("TNT"))
        assertEquals("Peacock", Streaming.appFor("NBC"))
        assertNull(Streaming.appFor("Spectrum SportsNet"))
        val lines = Streaming.describe(L.NBA, listOf(Broadcast("Prime Video", "National"), Broadcast("Spectrum SportsNet", "Home")))
        assertEquals("Usually streams on Prime Video", lines[0])
        assertTrue(lines[1].contains("NBA League Pass"))
        val p = Predict.homeWinProb(L.NBA, "30-10", "10-30")!!
        assertTrue(p > 0.85 && p <= 0.97)
        assertNull(Predict.homeWinProb(L.NBA, "1-0", "0-1"))
    }

    // ---------- new sports ----------

    @Test fun ufcCardsMainEventFirst() {
        val card = Parse.fightCards(json("ufc_scoreboard.json")).single()
        assertEquals("UFC 322: Smith vs. Jones", card.name)
        assertEquals("Madison Square Garden, New York, NY", card.venue)
        assertEquals("Main Champ", card.fights[0].a.name)
        assertEquals("Lightweight - Title Fight", card.fights[0].weightClass)
        assertEquals("25-1-0", card.fights[0].a.record)
        assertEquals("https://h/champ.png", card.fights[0].a.headshot)
        assertEquals("Flyweight", card.fights[1].weightClass)
        assertEquals(listOf("Paramount+", "ESPN+"), card.broadcasts.map { it.network }.sorted().reversed())
        assertEquals(GameState.PRE, card.state)
    }

    @Test fun f1WeekendSessionsAndResults() {
        val w = Parse.raceWeekends(json("f1_scoreboard.json")).single()
        assertEquals("Autódromo Hermanos Rodríguez", w.circuit)
        assertEquals("Mexico City, Mexico", w.location)
        assertEquals(listOf("Qualifying", "Race"), w.sessions.map { it.name })
        val race = w.sessions[1]
        assertEquals(listOf("Max Verstappen", "Lando Norris"), race.results.map { it.name })
        assertEquals("1:40:12.3", race.results[0].detail)
        assertEquals("+3.2", race.results[1].detail)
        assertEquals("Red Bull", race.results[0].team)
        assertEquals(GameState.POST, w.state)
        assertEquals("Apple TV", Streaming.appFor(race.broadcasts.single().network))
    }

    @Test fun golfLeaderboard() {
        val t = Parse.tournaments(json("golf_scoreboard.json")).single()
        assertEquals(GameState.IN, t.state)
        assertEquals(listOf("Leader One", "Player Two"), t.players.map { it.name })
        assertEquals("-12", t.players[0].toPar)
        assertEquals("F", t.players[0].thru)
        assertEquals("T2", t.players[1].position)
        assertEquals("-2", t.players[1].today)
        assertEquals("Accordia Golf Narashino CC, Chiba, Japan", t.venue)
    }

    @Test fun tennisDrawsAndSets() {
        val e = Parse.tennisEvents(json("tennis_scoreboard.json")).single()
        assertEquals(listOf("Men's Singles"), e.draws.map { it.first }) // empty doubles draw dropped
        val m = e.draws[0].second[0]
        assertEquals("Round 1", m.round)
        assertEquals(listOf("6", "7(5)"), m.players[0].sets)
        assertTrue(m.players[0].winner)
        assertEquals("3", m.players[0].seed)
        assertEquals("Doubles A / Doubles B", e.draws[0].second[1].players[0].name)
    }

    @Test fun cricketIplFirst() {
        val series = Parse.cricket(json("cricket_header.json"))
        assertEquals("Indian Premier League", series[0].name)
        val m = series[0].matches.single()
        assertEquals(GameState.IN, m.state)
        assertEquals("150/4 (16)", m.sides[0].score)
        assertEquals("MI need 40 runs in 24 balls", m.status)
        assertEquals("https://www.espncricinfo.com/x", m.link)
        assertEquals("A won by 5 wickets", series[1].matches.single().status)
        assertEquals(GameState.POST, series[1].matches.single().state)
    }

    @Test fun soccerTableByRank() {
        val t = Parse.standings(json("epl_standings.json"), L.EPL).single()
        assertEquals(listOf("MCI", "ARS"), t.rows.map { it.team.abbr })
        assertEquals(listOf("GP", "W", "D", "L", "GF", "GA", "GD", "PTS"), t.columns.map { it.first })
        assertEquals("21", t.rows[0].stats["PTS"])
    }

    @Test fun rankingsMovement() {
        val r = Parse.rankings(json("cfb_rankings.json")).single()
        assertEquals("AP Top 25", r.name)
        assertEquals(2, r.rows[0].previous)
        assertNull(r.rows[1].previous)
        assertEquals("1525", r.rows[0].points)
        assertEquals("", r.rows[1].firstPlace)
    }

    @Test fun soccerKeyEventsLineupsAndDrawOdds() {
        val d = Parse.gameDetail(json("soccer_summary.json"), L.EPL)!!
        assertEquals(2, d.scoringPlays.size) // goal + card, not the substitution
        assertTrue(d.scoringPlays[0].contains("23' Goal · Arsenal: Saka scores."))
        assertEquals("Bukayo Saka", d.lineups.single().second.first().name)
        assertEquals("240", d.odds!!.drawMoneyline)
        assertNull(Predict.homeWinProb(L.EPL, "6-2-1", "7-0-2")) // no record estimate where draws exist
    }

    @Test fun localDayUsesPhoneTimeZone() {
        // A 7:30 pm Phoenix game is 02:30 UTC the next day; it belongs to Phoenix's date.
        val nba = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        val phoenix = java.time.ZoneId.of("America/Phoenix")
        val tokyo = java.time.ZoneId.of("Asia/Tokyo")
        val oct27 = java.time.LocalDate.of(2026, 10, 27)
        assertEquals(2, Espn.onLocalDate(nba + nba, oct27, phoenix).size) // de-duplicated
        assertEquals(0, Espn.onLocalDate(nba, oct27, tokyo).size)
        assertEquals(2, Espn.onLocalDate(nba, oct27.plusDays(1), tokyo).size)
    }

    @Test fun catalogIsComplete() {
        val keys = Leagues.all.map { it.key }
        listOf("NFL", "NBA", "MLB", "NHL", "WNBA", "UFL", "EPL", "MLS", "UCL", "LALIGA", "BUNDESLIGA", "SERIEA", "LIGUE1",
            "WORLDCUP", "EURO", "COPA", "CFB", "MCBB", "WCBB", "UFC", "F1", "NASCAR", "INDYCAR", "PGA", "ATP", "WTA",
            "CRICKET", "SIXNATIONS", "RWC").forEach { assertTrue(it, it in keys) }
        assertEquals(keys.size, keys.toSet().size)
    }

    // ---------- location: TV markets and venue clocks ----------

    private val phoenix = UserPlace(33.45, -112.07, "Phoenix, AZ", true)
    private val losAngeles = UserPlace(34.05, -118.24, "Los Angeles, CA", false)

    @Test fun teamsMapToTheirMetro() {
        fun m(name: String, l: League) = Places.metroFor(TeamRef("1", "X", name), l)?.key
        assertEquals("PHX", m("Phoenix Suns", L.NBA))
        assertEquals("PHX", m("Arizona Diamondbacks", L.MLB))
        assertEquals("LA", m("LA Clippers", L.NBA))
        assertEquals("ATL", m("Atlanta Hawks", L.NBA)) // not "LA"
        assertEquals("LV", m("Vegas Golden Knights", L.NHL))
        assertEquals("TB", m("Tampa Bay Lightning", L.NHL))
        assertEquals("MIA", m("Inter Miami CF", Leagues.of("MLS")!!))
        assertEquals("SLC", m("Real Salt Lake", Leagues.of("MLS")!!))
        assertEquals("WAS", m("D.C. United", Leagues.of("MLS")!!))
        assertNull(m("Arsenal", L.EPL))
    }

    @Test fun localChannelDependsOnWhereYouAre() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        val fromPhoenix = Tv.plan(lakers, phoenix)
        assertEquals(Reach.NATIONAL, fromPhoenix[0].reach)
        assertEquals("Prime Video · usually streams on Prime Video", fromPhoenix[0].text)
        val rsn = fromPhoenix.first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_ELSEWHERE, rsn.reach)
        assertTrue(rsn.text.contains("NBA League Pass"))
        val fromLA = Tv.plan(lakers, losAngeles).first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_YOURS, fromLA.reach)
        assertTrue(fromLA.text.contains("Spectrum SportsNet app"))
        assertEquals(Reach.LOCAL_UNKNOWN, Tv.plan(lakers, null).first { it.network == "Spectrum SportsNet" }.reach)
        // score cards hide channels you can't get
        assertEquals(listOf("Prime Video" to false), Tv.cardNetworks(lakers, phoenix))
        assertEquals(listOf("Spectrum SportsNet" to true, "Prime Video" to false).sortedBy { it.first }, Tv.cardNetworks(lakers, losAngeles).sortedBy { it.first })
    }

    @Test fun overTheAirNetworksGetAFinder() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        val fox = Tv.plan(g, phoenix).single()
        assertEquals("On your local FOX station · usually streams on Fox One", fox.text)
        assertTrue(fox.findUrl!!.contains("FOX+channel+Phoenix"))
    }

    @Test fun venueClocks() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        assertEquals("America/Los_Angeles", Places.venueZone(lakers)!!.id)
        assertEquals("Asia/Tokyo", Places.zoneFromPlace("Chiba, Japan")!!.id)
        assertEquals("America/Mexico_City", Places.zoneFromPlace("Mexico City, Mexico")!!.id)
        assertEquals("America/New_York", Places.zoneFromPlace("Madison Square Garden, New York, NY")!!.id)
    }

    @Test fun byeWeeksFromGapsAndFeed() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)   // weeks 7 and 9
        assertEquals(listOf(8), Byes.weeks(games))                      // inferred from the gap
        assertEquals(listOf(8), Byes.weeks(games, 8))                   // feed agrees, no duplicate
        assertEquals(listOf(5, 8), Byes.weeks(games, 5))                // feed names one the gap can't see
        assertEquals(7, Byes.placement(games, listOf(8))[8]?.week)      // sits after the week-7 game
        assertNull(Byes.placement(games, listOf(5))[5])                 // before the first listed game
        assertEquals(emptyList<Int>(), Byes.weeks(Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)))
    }

    @Test fun updateVersionsCompare() {
        assertEquals("2.4", Updates.versionOf("Sideline 2.4"))
        assertEquals("2.4", Updates.versionOf("v2.4-build7"))
        assertEquals("2.10.1", Updates.versionOf("Sideline 2.10.1"))
        assertEquals("", Updates.versionOf("build-3"))
        assertTrue(Updates.newer("2.5", "2.4"))
        assertTrue(Updates.newer("2.10", "2.9"))
        assertTrue(Updates.newer("3.0", "2.99"))
        assertFalse(Updates.newer("2.4", "2.4"))
        assertFalse(Updates.newer("2.3", "2.4"))
        assertTrue(Updates.newer("2.4.1", "2.4"))
    }
}
