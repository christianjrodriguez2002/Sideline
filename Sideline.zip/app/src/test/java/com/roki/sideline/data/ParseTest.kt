package com.roki.sideline.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Parsers against ESPN-shaped samples, including the shape differences between leagues and endpoints. */
class ParseTest {
    private object L {
        val NBA = Leagues.of("NBA")!!
        val MLB = Leagues.of("MLB")!!
        val NFL = Leagues.of("NFL")!!
        val NHL = Leagues.of("NHL")!!
        val EPL = Leagues.of("EPL")!!
    }
    private fun json(name: String): JSONObject =
        JSONObject(javaClass.getResource("/$name")!!.readText())

    @Test fun scoreboardFinalAndUpcoming() {
        val games = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        assertEquals(2, games.size)
        val fin = games.first { it.id == "401800001" }
        assertEquals(GameState.POST, fin.state)
        assertEquals("121", fin.home.score)
        assertTrue(fin.home.winner)
        assertEquals("3-1", fin.home.record)
        assertEquals(listOf("30", "28", "33", "30"), fin.home.linescores)
        assertEquals("Stephen Curry", fin.home.leaders.single().athleteName)
        assertEquals(listOf("ESPN"), fin.broadcasts.map { it.network })
        assertEquals("Chase Center, San Francisco", fin.venue)

        val pre = games.first { it.id == "401800002" }
        assertEquals(GameState.PRE, pre.state)
        assertEquals("LAL", pre.home.team.abbr)
        assertEquals("LAL -4.5", pre.odds!!.details)
        assertEquals("228.5", pre.odds!!.overUnder)
        assertEquals("-180", pre.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video", "Spectrum SportsNet"), pre.broadcasts.map { it.network })
        assertFalse(pre.broadcasts[1].national)
    }

    @Test fun liveBaseballSituation() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        assertEquals(GameState.IN, g.state)
        assertEquals("2-1 · 1 out · on 1st, 3rd", g.situation)
        assertEquals("Ohtani singled to right.", g.lastPlay)
        assertEquals("World Series - Game 2", g.note)
        assertEquals("LAD", g.away.team.abbr)
    }

    @Test fun nflWeek() {
        assertEquals(8 to 2, Parse.week(json("nfl_scoreboard_week.json")))
        assertNull(Parse.week(json("nba_scoreboard.json")))
    }

    @Test fun standingsNestedAndSorted() {
        val tables = Parse.standings(json("nfl_standings.json"), L.NFL)
        assertEquals(listOf("American Football Conference", "NFC West"), tables.map { it.title })
        val afc = tables[0]
        assertEquals("BUF", afc.rows[0].team.abbr) // 1.000 sorts above .857
        assertEquals("Clinched Playoff Berth", afc.rows[1].note)
        assertEquals(listOf("W", "L", "T", "PCT", "PF", "PA", "DIFF", "STRK"), afc.columns.map { it.first })
        assertEquals("+110", afc.rows[0].stats["DIFF"])
        assertEquals(listOf("W", "L", "T", "PCT", "STRK"), tables[1].columns.map { it.first })
    }

    @Test fun nhlStandingsByPoints() {
        val t = Parse.standings(json("nhl_standings.json"), L.NHL).single()
        assertEquals(listOf("COL", "DAL", "UTA"), t.rows.map { it.team.abbr }) // 14 pts, then 13 in fewer games
        assertEquals("1", t.rows[1].stats["OTL"])
    }

    @Test fun rostersGroupedAndFlat() {
        val nfl = Parse.roster(json("nfl_roster.json"))
        assertEquals(2, nfl.size)
        val k = nfl[0]
        assertEquals("Kyler Murray", k.name)
        assertEquals("Offense", k.group)
        assertEquals("QB", k.position)
        assertEquals("Bedford, TX", k.birthPlace)
        assertEquals("8 yrs", k.experience)
        assertEquals("Questionable", k.injuryStatus)
        assertEquals("22", k.teamId)
        assertEquals("Rookie", nfl[1].experience)

        val nba = Parse.roster(json("nba_roster.json"))
        assertEquals(listOf("Devin Booker", "No Id Ok"), nba.map { it.name })
        assertEquals("Shooting Guard", nba[0].group)
    }

    @Test fun injuriesGroupedByTeam() {
        val list = Parse.injuries(json("nfl_injuries.json"))
        assertEquals(2, list.size)
        val k = list[0]
        assertEquals("22", k.teamId)
        assertEquals("Arizona Cardinals", k.teamName)
        assertEquals("https://l/ari.png", k.teamLogo)
        assertEquals("Questionable", k.status)
        assertEquals("Right Leg Foot", k.type)
        assertEquals("2026-10-26", k.returnDate)
        assertNotNull(k.date)
        assertEquals("Ankle", list[1].type)
        assertEquals("12", list[1].teamId)
    }

    @Test fun gameSummary() {
        val d = Parse.gameDetail(json("nba_summary.json"), L.NBA)!!
        assertEquals(63.4, d.homeWinPct!!, 0.001)
        assertEquals(36.6, d.awayWinPct!!, 0.001)
        assertEquals("ESPN BPI Win Probability", d.predictorName)
        assertEquals("3-0", d.game.home.record)
        assertEquals("Crypto.com Arena, Los Angeles", d.game.venue)
        assertEquals("", d.attendance)
        assertEquals(listOf(StatLine("PPG", "110.3", "118.0")), d.teamStats)
        assertEquals("PHX", d.leaders.single().first)
        assertEquals("27.5 PPG", d.leaders.single().second.single().value)
        assertEquals("D. Booker", d.box.single().rows.single().first)
        assertEquals(listOf("MIN", "PTS"), d.box.single().labels)
        assertEquals("LeBron James", d.injuries.single().athleteName)
        assertEquals(1, d.scoringPlays.size)
        assertTrue(d.scoringPlays[0].contains("PHX: Booker makes 3 (3-0)"))
        assertEquals("Series tied 1-1", d.seasonSeries)
        assertEquals("-180", d.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video"), d.broadcasts.map { it.network })
    }

    @Test fun teamScheduleScoresAreObjects() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)
        assertEquals(2, games.size)
        assertEquals(listOf(7, 9), games.map { it.week })
        assertEquals(8, Parse.byeWeek(json("nfl_schedule.json")))
        assertEquals(0, Parse.byeWeek(json("nba_roster.json")))
        val past = games[0]
        assertEquals(GameState.POST, past.state)
        assertEquals("27", past.home.score)
        assertEquals("20", past.away.score)
        assertEquals("4-3", past.home.record)
        assertEquals(listOf("FOX"), past.broadcasts.map { it.network })
        assertEquals("DAL", games[1].home.team.abbr)
    }

    @Test fun athleteOverview() {
        val o = Parse.overview(json("athlete_overview.json"))
        assertEquals(listOf("GP", "PTS", "REB", "AST"), o.labels)
        assertEquals(listOf("Regular Season", "Career"), o.rows.map { it.label })
        assertEquals("Booker drops 30", o.news.single().headline)
        assertEquals("Booker scores 30 in win", o.injuryNote)
        assertEquals("Phoenix Suns at Los Angeles Lakers", o.nextGame)
    }

    @Test fun teamsNewsMovesDetail() {
        assertEquals(listOf("Arizona Cardinals", "Atlanta Falcons").sorted(), Parse.teams(json("nfl_teams.json")).map { it.name })
        val news = Parse.articles(json("news.json"))
        assertEquals(1, news.size)
        assertEquals("https://i/x.jpg", news[0].image)
        assertEquals("Placed QB X on injured reserve.", Parse.transactions(json("transactions.json")).single().description)
        val td = Parse.teamDetail(json("team_detail.json"))!!
        assertEquals("4-3", td.record)
        assertEquals("2nd in NFC West", td.standingSummary)
        assertEquals("Home Record" to "3-1", td.recordDetails[1])
    }

    @Test fun streamingAndPrediction() {
        assertEquals("HBO Max", Streaming.appFor("TNT"))
        assertEquals("Peacock", Streaming.appFor("NBC"))
        assertNull(Streaming.appFor("Spectrum SportsNet"))
        val lines = Streaming.describe(L.NBA, listOf(Broadcast("Prime Video", "National"), Broadcast("Spectrum SportsNet", "Home")))
        assertEquals("Usually streams on Prime Video", lines[0])
        assertTrue(lines[1].contains("NBA League Pass"))
        val p = Predict.homeWinProb(L.NBA, "30-10", "10-30")!!
        assertTrue(p > 0.85 && p <= 0.97)
        assertNull(Predict.homeWinProb(L.NBA, "1-0", "0-1"))
    }

    // ---------- new sports ----------

    @Test fun ufcCardsMainEventFirst() {
        val card = Parse.fightCards(json("ufc_scoreboard.json")).single()
        assertEquals("UFC 322: Smith vs. Jones", card.name)
        assertEquals("Madison Square Garden, New York, NY", card.venue)
        assertEquals("Main Champ", card.fights[0].a.name)
        assertEquals("Lightweight - Title Fight", card.fights[0].weightClass)
        assertEquals("25-1-0", card.fights[0].a.record)
        assertEquals("https://h/champ.png", card.fights[0].a.headshot)
        assertEquals("Flyweight", card.fights[1].weightClass)
        assertEquals(listOf("Paramount+", "ESPN+"), card.broadcasts.map { it.network }.sorted().reversed())
        assertEquals(GameState.PRE, card.state)
    }

    @Test fun f1WeekendSessionsAndResults() {
        val w = Parse.raceWeekends(json("f1_scoreboard.json")).single()
        assertEquals("Autódromo Hermanos Rodríguez", w.circuit)
        assertEquals("Mexico City, Mexico", w.location)
        assertEquals(listOf("Qualifying", "Race"), w.sessions.map { it.name })
        val race = w.sessions[1]
        assertEquals(listOf("Max Verstappen", "Lando Norris"), race.results.map { it.name })
        assertEquals("1:40:12.3", race.results[0].detail)
        assertEquals("+3.2", race.results[1].detail)
        assertEquals("Red Bull", race.results[0].team)
        assertEquals(GameState.POST, w.state)
        assertEquals("Apple TV", Streaming.appFor(race.broadcasts.single().network))
    }

    @Test fun golfLeaderboard() {
        val t = Parse.tournaments(json("golf_scoreboard.json")).single()
        assertEquals(GameState.IN, t.state)
        assertEquals(listOf("Leader One", "Player Two"), t.players.map { it.name })
        assertEquals("-12", t.players[0].toPar)
        assertEquals("F", t.players[0].thru)
        assertEquals("T2", t.players[1].position)
        assertEquals("-2", t.players[1].today)
        assertEquals("Accordia Golf Narashino CC, Chiba, Japan", t.venue)
    }

    @Test fun tennisDrawsAndSets() {
        val e = Parse.tennisEvents(json("tennis_scoreboard.json")).single()
        assertEquals(listOf("Men's Singles"), e.draws.map { it.first }) // empty doubles draw dropped
        val m = e.draws[0].second[0]
        assertEquals("Round 1", m.round)
        assertEquals(listOf("6", "7(5)"), m.players[0].sets)
        assertTrue(m.players[0].winner)
        assertEquals("3", m.players[0].seed)
        assertEquals("Doubles A / Doubles B", e.draws[0].second[1].players[0].name)
    }

    @Test fun cricketIplFirst() {
        val series = Parse.cricket(json("cricket_header.json"))
        assertEquals("Indian Premier League", series[0].name)
        val m = series[0].matches.single()
        assertEquals(GameState.IN, m.state)
        assertEquals("150/4 (16)", m.sides[0].score)
        assertEquals("MI need 40 runs in 24 balls", m.status)
        assertEquals("https://www.espncricinfo.com/x", m.link)
        assertEquals("A won by 5 wickets", series[1].matches.single().status)
        assertEquals(GameState.POST, series[1].matches.single().state)
    }

    @Test fun soccerTableByRank() {
        val t = Parse.standings(json("epl_standings.json"), L.EPL).single()
        assertEquals(listOf("MCI", "ARS"), t.rows.map { it.team.abbr })
        assertEquals(listOf("GP", "W", "D", "L", "GF", "GA", "GD", "PTS"), t.columns.map { it.first })
        assertEquals("21", t.rows[0].stats["PTS"])
    }

    @Test fun rankingsMovement() {
        val r = Parse.rankings(json("cfb_rankings.json")).single()
        assertEquals("AP Top 25", r.name)
        assertEquals(2, r.rows[0].previous)
        assertNull(r.rows[1].previous)
        assertEquals("1525", r.rows[0].points)
        assertEquals("", r.rows[1].firstPlace)
    }

    @Test fun soccerKeyEventsLineupsAndDrawOdds() {
        val d = Parse.gameDetail(json("soccer_summary.json"), L.EPL)!!
        assertEquals(2, d.scoringPlays.size) // goal + card, not the substitution
        assertTrue(d.scoringPlays[0].contains("23' Goal · Arsenal: Saka scores."))
        assertEquals("Bukayo Saka", d.lineups.single().second.first().name)
        assertEquals("240", d.odds!!.drawMoneyline)
        assertNull(Predict.homeWinProb(L.EPL, "6-2-1", "7-0-2")) // no record estimate where draws exist
    }

    @Test fun localDayUsesPhoneTimeZone() {
        // A 7:30 pm Phoenix game is 02:30 UTC the next day; it belongs to Phoenix's date.
        val nba = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        val phoenix = java.time.ZoneId.of("America/Phoenix")
        val tokyo = java.time.ZoneId.of("Asia/Tokyo")
        val oct27 = java.time.LocalDate.of(2026, 10, 27)
        assertEquals(2, Espn.onLocalDate(nba + nba, oct27, phoenix).size) // de-duplicated
        assertEquals(0, Espn.onLocalDate(nba, oct27, tokyo).size)
        assertEquals(2, Espn.onLocalDate(nba, oct27.plusDays(1), tokyo).size)
    }

    @Test fun catalogIsComplete() {
        val keys = Leagues.all.map { it.key }
        listOf("NFL", "NBA", "MLB", "NHL", "WNBA", "UFL", "EPL", "MLS", "UCL", "LALIGA", "BUNDESLIGA", "SERIEA", "LIGUE1",
            "WORLDCUP", "EURO", "COPA", "CFB", "MCBB", "WCBB", "UFC", "F1", "NASCAR", "INDYCAR", "PGA", "ATP", "WTA",
            "CRICKET", "SIXNATIONS", "RWC").forEach { assertTrue(it, it in keys) }
        assertEquals(keys.size, keys.toSet().size)
    }

    // ---------- location: TV markets and venue clocks ----------

    private val phoenix = UserPlace(33.45, -112.07, "Phoenix, AZ", true)
    private val losAngeles = UserPlace(34.05, -118.24, "Los Angeles, CA", false)

    @Test fun teamsMapToTheirMetro() {
        fun m(name: String, l: League) = Places.metroFor(TeamRef("1", "X", name), l)?.key
        assertEquals("PHX", m("Phoenix Suns", L.NBA))
        assertEquals("PHX", m("Arizona Diamondbacks", L.MLB))
        assertEquals("LA", m("LA Clippers", L.NBA))
        assertEquals("ATL", m("Atlanta Hawks", L.NBA)) // not "LA"
        assertEquals("LV", m("Vegas Golden Knights", L.NHL))
        assertEquals("TB", m("Tampa Bay Lightning", L.NHL))
        assertEquals("MIA", m("Inter Miami CF", Leagues.of("MLS")!!))
        assertEquals("SLC", m("Real Salt Lake", Leagues.of("MLS")!!))
        assertEquals("WAS", m("D.C. United", Leagues.of("MLS")!!))
        assertNull(m("Arsenal", L.EPL))
    }

    @Test fun localChannelDependsOnWhereYouAre() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        val fromPhoenix = Tv.plan(lakers, phoenix)
        assertEquals(Reach.NATIONAL, fromPhoenix[0].reach)
        assertEquals("Prime Video · usually streams on Prime Video", fromPhoenix[0].text)
        val rsn = fromPhoenix.first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_ELSEWHERE, rsn.reach)
        assertTrue(rsn.text.contains("NBA League Pass"))
        val fromLA = Tv.plan(lakers, losAngeles).first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_YOURS, fromLA.reach)
        assertTrue(fromLA.text.contains("Spectrum SportsNet app"))
        assertEquals(Reach.LOCAL_UNKNOWN, Tv.plan(lakers, null).first { it.network == "Spectrum SportsNet" }.reach)
        // score cards hide channels you can't get
        assertEquals(listOf("Prime Video" to false), Tv.cardNetworks(lakers, phoenix))
        assertEquals(listOf("Spectrum SportsNet" to true, "Prime Video" to false).sortedBy { it.first }, Tv.cardNetworks(lakers, losAngeles).sortedBy { it.first })
    }

    @Test fun overTheAirNetworksGetAFinder() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        val fox = Tv.plan(g, phoenix).single()
        assertEquals("On your local FOX station · usually streams on Fox One", fox.text)
        assertTrue(fox.findUrl!!.contains("FOX+channel+Phoenix"))
    }

    @Test fun venueClocks() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        assertEquals("America/Los_Angeles", Places.venueZone(lakers)!!.id)
        assertEquals("Asia/Tokyo", Places.zoneFromPlace("Chiba, Japan")!!.id)
        assertEquals("America/Mexico_City", Places.zoneFromPlace("Mexico City, Mexico")!!.id)
        assertEquals("America/New_York", Places.zoneFromPlace("Madison Square Garden, New York, NY")!!.id)
    }

    @Test fun byeWeeksFromGapsAndFeed() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)   // weeks 7 and 9
        assertEquals(listOf(8), Byes.weeks(games))                      // inferred from the gap
        assertEquals(listOf(8), Byes.weeks(games, 8))                   // feed agrees, no duplicate
        assertEquals(listOf(5, 8), Byes.weeks(games, 5))                // feed names one the gap can't see
        assertEquals(7, Byes.placement(games, listOf(8))[8]?.week)      // sits after the week-7 game
        assertNull(Byes.placement(games, listOf(5))[5])                 // before the first listed game
        assertEquals(emptyList<Int>(), Byes.weeks(Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)))
    }

    @Test fun updateVersionsCompare() {
        assertEquals("2.4", Updates.versionOf("Sideline 2.4"))
        assertEquals("2.4", Updates.versionOf("v2.4-build7"))
        assertEquals("2.10.1", Updates.versionOf("Sideline 2.10.1"))
        assertEquals("", Updates.versionOf("build-3"))
        assertTrue(Updates.newer("2.5", "2.4"))
        assertTrue(Updates.newer("2.10", "2.9"))
        assertTrue(Updates.newer("3.0", "2.99"))
        assertFalse(Updates.newer("2.4", "2.4"))
        assertFalse(Updates.newer("2.3", "2.4"))
        assertTrue(Updates.newer("2.4.1", "2.4"))
    }

    @Test fun releaseNotesBecomePlainBullets() {
        val body = "## Sideline 2.6\n\n- Widget shows logos\n* Patch notes in the banner\n\nPlain line\n"
        assertEquals("• Sideline 2.6\n• Widget shows logos\n• Patch notes in the banner\n• Plain line", Updates.notes(body))
        assertEquals("", Updates.notes(""))
    }

    @Test fun leadersBothShapes() {
        val boards = More.leaders(json("nba_leaders.json"))
        assertEquals(1, boards.size)                                  // the empty category is dropped
        assertEquals("Points Per Game", boards[0].category)
        assertEquals("Devin Booker", boards[0].rows[1].name)
        assertEquals("PHX", boards[0].rows[1].team)
        assertEquals(2, boards[0].rows[1].rank)
        val flat = More.leaders(JSONObject().put("categories", json("nba_leaders.json").getJSONObject("leaders").getJSONArray("categories")))
        assertEquals(boards, flat)
    }

    @Test fun teamSeasonStats() {
        val cats = More.teamStats(json("team_stats.json"))
        assertEquals(listOf("Offense", "Defense"), cats.map { it.first })
        assertEquals(TeamStat("Points Per Game", "118.2", "4th"), cats[0].second[0])
        assertEquals("", cats[0].second[1].rank)
    }

    @Test fun playerSearchMapsLeagues() {
        val hits = More.searchPlayers(json("search.json"))
        assertEquals(2, hits.size)                                    // team result skipped, duplicate dropped
        assertEquals("3136193", hits[0].id)
        assertEquals("NBA", hits[0].league?.key)
        assertNull(hits[1].league)                                    // a league Sideline doesn't cover
    }

    @Test fun teamSearchRanksMatches() {
        val nba = Leagues.of("NBA")!!
        val teams = listOf(
            nba to TeamRef("1", "PHX", "Phoenix Suns", "Suns"),
            nba to TeamRef("2", "LAL", "Los Angeles Lakers", "Lakers"),
            nba to TeamRef("3", "SAS", "San Antonio Spurs", "Spurs"),
        )
        assertEquals(listOf("1"), More.matchTeams("suns", teams).map { it.second.id })
        assertEquals(listOf("2"), More.matchTeams("lal", teams).map { it.second.id })
        assertEquals(listOf("3"), More.matchTeams("san", teams).map { it.second.id })
        assertEquals(emptyList<Any>(), More.matchTeams("s", teams))   // one letter is too short to search
        assertEquals(emptyList<Any>(), More.matchTeams("x", teams))
    }

    @Test fun mlbProbablePitcher() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB)
        assertTrue(g.flatMap { listOf(it.home.probable, it.away.probable) }.contains("L. Webb (12-8, 3.21)"))
    }

    @Test fun playByPlay() {
        val plays = More.plays(json("nba_summary.json"), L.NBA)
        assertTrue(plays.isNotEmpty())
        assertEquals("Booker makes 3", plays[0].text)
        assertEquals("Q1", plays[0].period)
        assertEquals("PHX", plays[0].team)
        assertTrue(plays[0].scoring)
        assertEquals("3", plays[0].away)
    }

    @Test fun playoffRoundsAndSeries() {
        val nba = Leagues.of("NBA")!!
        val a = TeamRef("1", "PHX", "Phoenix Suns"); val b = TeamRef("2", "DEN", "Denver Nuggets")
        fun g(id: String, note: String, aWin: Boolean?, day: Long) = Game(id, nba, java.time.Instant.ofEpochSecond(1_700_000_000 + day * 86400), "", "",
            if (aWin == null) GameState.PRE else GameState.POST, "", "",
            Competitor(b, home = true, score = "100", winner = aWin == false), Competitor(a, home = false, score = "101", winner = aWin == true), note = note)
        val rounds = More.rounds(listOf(
            g("1", "West 1st Round - Game 1", true, 0), g("2", "West 1st Round - Game 2", true, 2),
            g("3", "West 1st Round - Game 3", false, 4), g("4", "West 1st Round - Game 4", null, 6),
        ))
        assertEquals(1, rounds.size)
        assertEquals("West 1st Round", rounds[0].name)
        assertEquals("PHX leads 2-1", rounds[0].series.single().summary)
        assertEquals(4, rounds[0].series.single().games.size)
    }

    @Test fun backupRoundTrip() {
        val nba = Leagues.of("NBA")!!
        Favorites.list.clear(); Players.list.clear()
        Favorites.list.add(Favorite(nba, TeamRef("21", "PHX", "Phoenix Suns", "Suns", "https://l/phx.png", "1d1160")))
        Players.list.add(FollowedPlayer(nba, Player("3136193", "Devin Booker", headshot = "https://h/b.png", teamName = "Phoenix Suns")))
        val b = More.backup()
        assertEquals("Sideline", b.getString("app"))
        assertEquals("PHX", b.getJSONArray("favorites").getJSONObject(0).getString("abbr"))
        assertEquals("Devin Booker", b.getJSONArray("players").getJSONObject(0).getString("name"))
        Players.list.clear()
        Players.fromJson(b.getJSONArray("players"))
        assertEquals("3136193", Players.list.single().player.id)
        Favorites.list.clear(); Players.list.clear()
    }

    private fun live(key: String, a: String, h: String, periods: Int, clock: String): Game {
        val l = Leagues.of(key)!!
        val ls = List(periods) { "0" }
        return Game("x", l, java.time.Instant.now(), "", "", GameState.IN, "", "",
            Competitor(TeamRef("1", "HOM", "Home"), home = true, score = h, linescores = ls),
            Competitor(TeamRef("2", "AWY", "Away"), home = false, score = a, linescores = ls), clock = clock)
    }

    @Test fun closeGameRules() {
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NBA", "101", "99", 4, "3:10")))     // 2 pts, 4th, under 5 min
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NBA", "101", "99", 4, "9:10")))    // too early in the 4th
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NBA", "110", "99", 4, "1:00")))    // blowout
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NBA", "110", "110", 5, "4:00")))    // overtime always counts
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NFL", "24", "20", 4, "5:30")))      // one score, late
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NHL", "2", "2", 3, "8:00")))        // tied in the 3rd
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NHL", "2", "2", 2, "8:00")))       // only the 2nd
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("MLB", "3", "4", 9, "")))            // 1 run, 9th
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("MLB", "3", "4", 6, "")))           // 6th inning
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("EPL", "1", "1", 2, "81'")))         // level, 81st minute
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("EPL", "1", "1", 2, "60'")))
        assertEquals(90.0, com.roki.sideline.work.Alerts.clockMinutes(live("EPL", "0", "0", 2, "90'+3'"))!!, 0.01)
        assertEquals(4.5, com.roki.sideline.work.Alerts.clockMinutes(live("NBA", "0", "0", 4, "4:30"))!!, 0.01)
    }

    private fun g(key: String, awayId: String, awayAbbr: String, homeId: String, homeAbbr: String) = Game("1", Leagues.of(key)!!, null, "", "",
        GameState.IN, "", "", Competitor(TeamRef(homeId, homeAbbr, homeAbbr), home = true), Competitor(TeamRef(awayId, awayAbbr, awayAbbr), home = false))

    @Test fun baseballLive() {
        val mlb = Leagues.of("MLB")!!
        val b = LiveParse.parse(json("mlb_live_summary.json"), mlb, g("MLB", "8", "MIL", "30", "TB")).baseball!!
        assertEquals(listOf(1, 2, 2), listOf(b.balls, b.strikes, b.outs))
        assertEquals(listOf(true, false, true), listOf(b.first, b.second, b.third))   // a runner object counts as occupied
        assertEquals("T. Megill", b.pitcher!!.name)
        assertEquals("6.2 IP, 2 ER, 7 K", b.pitcher!!.line)
        assertEquals(mlb.headshotUrl("2"), b.batter!!.headshot)                          // missing headshot filled in
        assertEquals("J. Aranda", b.onDeck)
        assertEquals(4, b.pitches.size)                                                  // only the current at-bat
        assertEquals(listOf(PitchKind.BALL, PitchKind.STRIKE, PitchKind.STRIKE, PitchKind.STRIKE), b.pitches.map { it.kind })
        assertEquals("Slider", b.pitches[1].type)
        assertEquals("86", b.pitches[1].mph)
        assertEquals(3, b.calledStrikes.size)                                            // across the whole game
        assertEquals(PitchKind.IN_PLAY, LiveParse.pitchKind("In play, out(s)"))
        assertEquals(PitchKind.BALL, LiveParse.pitchKind("Hit By Pitch"))
    }

    @Test fun footballFieldPosition() {
        assertEquals(35.0, LiveParse.ballX("KC 35", "KC", "BUF")!!, 0.01)    // away side: yards from the away goal
        assertEquals(65.0, LiveParse.ballX("BUF 35", "KC", "BUF")!!, 0.01)   // home side, measured from the other end
        assertEquals(50.0, LiveParse.ballX("50", "KC", "BUF")!!, 0.01)
        assertNull(LiveParse.ballX("", "KC", "BUF"))
        assertNull(LiveParse.ballX("NYJ 20", "KC", "BUF"))
        val nfl = Leagues.of("NFL")!!
        val game = g("NFL", "12", "KC", "2", "BUF")
        val sit = JSONObject().put("down", 3).put("distance", 7).put("possession", "12").put("possessionText", "BUF 20")
            .put("downDistanceText", "3rd & 7 at BUF 20").put("isRedZone", true).put("homeTimeouts", 2).put("awayTimeouts", 3)
        val f = LiveParse.parse(JSONObject(), nfl, game, sit).football!!
        assertEquals(80.0, f.ballX!!, 0.01)
        assertEquals(87.0, f.toGainX!!, 0.01)          // KC drives toward the home goal line
        assertTrue(f.redZone)
        assertEquals(2, f.homeTimeouts)
        sit.put("downDistanceText", "1st & Goal at BUF 4").put("possessionText", "BUF 4").put("down", 1).put("distance", 4)
        assertEquals(100.0, LiveParse.parse(JSONObject(), nfl, game, sit).football!!.toGainX!!, 0.01)
        sit.put("possession", "2").put("possessionText", "BUF 30").put("downDistanceText", "2nd & 10 at BUF 30").put("distance", 10).put("down", 2)
        assertEquals(60.0, LiveParse.parse(JSONObject(), nfl, game, sit).football!!.toGainX!!, 0.01)   // BUF heads the other way
    }

    @Test fun basketballShotChart() {
        val shots = LiveParse.parse(json("nba_live_shots.json"), Leagues.of("NBA")!!, g("NBA", "7", "DEN", "21", "PHX")).shots
        assertEquals(2, shots.size)                    // free throw, bad coordinates and non-shots dropped
        assertTrue(shots[0].made)
        assertEquals(40.0, shots[1].x, 0.01)           // far-court shot folded onto the near basket
        assertEquals(14.0, shots[1].y, 0.01)
    }

    @Test fun hockeyShotMap() {
        val shots = LiveParse.parse(json("nhl_live_shots.json"), Leagues.of("NHL")!!, g("NHL", "3", "BOS", "21", "TOR")).shots
        assertEquals(3, shots.size)
        assertEquals(listOf(false, true, false), shots.map { it.made })
    }

    @Test fun soccerFormation() {
        val f = LiveParse.parse(json("soccer_lineups.json"), Leagues.of("EPL")!!, g("EPL", "1", "AAA", "359", "ARS")).formations
        assertEquals(1, f.size)                        // a team without eleven starters is skipped
        assertEquals("4-2-3-1", f[0].shape)
        assertEquals(listOf(1, 4, 2, 3, 1), f[0].rows.map { it.size })
        assertEquals("Raya", f[0].rows[0][0].name)
        assertEquals(listOf("Calafiori", "Gabriel", "Saliba", "White"), f[0].rows[1].map { it.name })   // left to right
        assertEquals(listOf("Trossard", "Ødegaard", "Saka"), f[0].rows[3].map { it.name })
        assertEquals("Gyökeres", f[0].rows[4][0].name)
        // A shape that doesn't add up falls back to grouping by position.
        val loose = LiveParse.rows("3-3", f[0].rows.drop(1).flatten().map { it to it.pos })
        assertEquals(listOf(4, 2, 1, 3), loose.map { it.size })
    }

    @Test fun baseballFieldersAndClips() {
        val mlb = Leagues.of("MLB")!!
        val top = g("MLB", "8", "MIL", "30", "TB").copy(statusShort = "Top 12th")
        val live = LiveParse.parse(json("mlb_live_summary.json"), mlb, top)
        val b = live.baseball!!
        assertEquals("30", b.fieldingTeamId)                        // top of the inning: the home team fields
        assertEquals("R. Palacios", b.fielders["SS"]!!.name)       // the sub replaced Walls at short
        assertEquals("T. Megill", b.fielders["P"]!!.name)          // pitcher from the live situation
        assertNull(b.fielders["DH"])
        assertEquals(setOf("P", "C", "1B", "2B", "3B", "SS", "LF", "CF", "RF"), b.fielders.keys)
        // Bottom of the inning: the away team fields, and one listed player isn't enough to draw.
        assertTrue(LiveParse.parse(json("mlb_live_summary.json"), mlb, top.copy(statusShort = "Bot 12th")).baseball!!.fielders.isEmpty())
        assertEquals(true, LiveParse.fieldingIsHome("End 6th"))
        assertEquals(false, LiveParse.fieldingIsHome("Mid 7th"))
        assertNull(LiveParse.fieldingIsHome("Final"))
        assertEquals(listOf("https://v/1.mp4", "https://v/2.m3u8"), live.clips.map { it.url })   // the unplayable one is dropped
        assertEquals(42, live.clips[0].seconds)
    }

    @Test fun gamePhotoSources() {
        val summary = Photos.fromSummary(json("photos_summary.json"))
        assertEquals(2, summary.size)                                   // logo composite and thumbnail dropped
        assertEquals("Pratt doubles in the 12th", summary[0].caption)
        assertEquals("AP Photo/Morry Gash", summary[0].credit)
        assertEquals("Celebration", summary[1].caption)                 // alt text when there's no caption
        val start = java.time.Instant.parse("2026-10-28T00:08:00Z")
        val (from, to) = Photos.gameWindow(start)
        val news = Photos.fromNews(json("photos_news.json"), from, to)
        assertEquals(2, news.size)                                      // last week's story and the undated one left out
        val all = Photos.merge(summary, news)
        assertEquals(3, all.size)                                       // the smaller copy of the recap photo is a repeat
        assertEquals(listOf("Pratt doubles in the 12th", "Celebration", "Dugout"), all.map { it.caption })
        assertEquals(Photos.key("https://x/r1_1296x729_16-9.jpg"), Photos.key("https://x/r1_576x324.jpg"))
    }

    @Test fun groupedTeamStats() {
        fun stat(name: String, label: String, v: String) = JSONObject().put("name", name).put("displayName", label).put("displayValue", v)
        fun box(id: String, hits: String, hr: String, era: String) = JSONObject().put("team", JSONObject().put("id", id)).put("statistics", org.json.JSONArray()
            .put(JSONObject().put("name", "batting").put("displayName", "Batting").put("stats", org.json.JSONArray()
                .put(stat("hits", "Hits", hits)).put(stat("homeRuns", "Home Runs", hr)).put(stat("empty", "Empty", ""))))
            .put(JSONObject().put("name", "pitching").put("displayName", "Pitching").put("stats", org.json.JSONArray().put(stat("ERA", "ERA", era))))
            .put(JSONObject().put("name", "fielding").put("displayName", "Fielding").put("stats", org.json.JSONArray())))
        val lines = More.teamStatLines(box("8", "9", "2", "1.50"), box("30", "6", "1", "4.00"))
        assertEquals(listOf("Batting", "Hits", "Home Runs", "Pitching", "ERA"), lines.map { it.label })   // empty group and stat dropped
        assertTrue(lines[0].header)
        assertEquals(StatLine("Hits", "9", "6"), lines[1])
        assertEquals(StatLine("ERA", "1.50", "4.00"), lines[4])
        // The flat layout most sports use still works.
        val flat = Parse.gameDetail(json("nba_summary.json"), L.NBA)!!.teamStats
        assertTrue(flat.isNotEmpty() && flat.none { it.header } && flat.all { it.away.isNotBlank() || it.home.isNotBlank() })
    }
}
