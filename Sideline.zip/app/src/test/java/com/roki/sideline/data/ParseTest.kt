package com.roki.sideline.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Parsers against ESPN-shaped samples, including the shape differences between leagues and endpoints. */
class ParseTest {
    private object L {
        val NBA = Leagues.of("NBA")!!
        val MLB = Leagues.of("MLB")!!
        val NFL = Leagues.of("NFL")!!
        val NHL = Leagues.of("NHL")!!
        val EPL = Leagues.of("EPL")!!
    }
    private fun json(name: String): JSONObject =
        JSONObject(javaClass.getResource("/$name")!!.readText())

    @Test fun scoreboardFinalAndUpcoming() {
        val games = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        assertEquals(2, games.size)
        val fin = games.first { it.id == "401800001" }
        assertEquals(GameState.POST, fin.state)
        assertEquals("121", fin.home.score)
        assertTrue(fin.home.winner)
        assertEquals("3-1", fin.home.record)
        assertEquals(listOf("30", "28", "33", "30"), fin.home.linescores)
        assertEquals("Stephen Curry", fin.home.leaders.single().athleteName)
        assertEquals(listOf("ESPN"), fin.broadcasts.map { it.network })
        assertEquals("Chase Center, San Francisco", fin.venue)

        val pre = games.first { it.id == "401800002" }
        assertEquals(GameState.PRE, pre.state)
        assertEquals("LAL", pre.home.team.abbr)
        assertEquals("LAL -4.5", pre.odds!!.details)
        assertEquals("228.5", pre.odds!!.overUnder)
        assertEquals("-180", pre.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video", "Spectrum SportsNet"), pre.broadcasts.map { it.network })
        assertFalse(pre.broadcasts[1].national)
    }

    @Test fun liveBaseballSituation() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        assertEquals(GameState.IN, g.state)
        assertEquals("2-1 · 1 out · on 1st, 3rd", g.situation)
        assertEquals("Ohtani singled to right.", g.lastPlay)
        assertEquals("World Series - Game 2", g.note)
        assertEquals("LAD", g.away.team.abbr)
    }

    @Test fun nflWeek() {
        assertEquals(8 to 2, Parse.week(json("nfl_scoreboard_week.json")))
        assertNull(Parse.week(json("nba_scoreboard.json")))
    }

    @Test fun standingsNestedAndSorted() {
        val tables = Parse.standings(json("nfl_standings.json"), L.NFL)
        assertEquals(listOf("American Football Conference", "NFC West"), tables.map { it.title })
        val afc = tables[0]
        assertEquals("BUF", afc.rows[0].team.abbr) // 1.000 sorts above .857
        assertEquals("Clinched Playoff Berth", afc.rows[1].note)
        assertEquals(listOf("W", "L", "T", "PCT", "PF", "PA", "DIFF", "STRK"), afc.columns.map { it.first })
        assertEquals("+110", afc.rows[0].stats["DIFF"])
        assertEquals(listOf("W", "L", "T", "PCT", "STRK"), tables[1].columns.map { it.first })
    }

    @Test fun nhlStandingsByPoints() {
        val t = Parse.standings(json("nhl_standings.json"), L.NHL).single()
        assertEquals(listOf("COL", "DAL", "UTA"), t.rows.map { it.team.abbr }) // 14 pts, then 13 in fewer games
        assertEquals("1", t.rows[1].stats["OTL"])
    }

    @Test fun rostersGroupedAndFlat() {
        val nfl = Parse.roster(json("nfl_roster.json"))
        assertEquals(2, nfl.size)
        val k = nfl[0]
        assertEquals("Kyler Murray", k.name)
        assertEquals("Offense", k.group)
        assertEquals("QB", k.position)
        assertEquals("Bedford, TX", k.birthPlace)
        assertEquals("8 yrs", k.experience)
        assertEquals("Questionable", k.injuryStatus)
        assertEquals("22", k.teamId)
        assertEquals("Rookie", nfl[1].experience)

        val nba = Parse.roster(json("nba_roster.json"))
        assertEquals(listOf("Devin Booker", "No Id Ok"), nba.map { it.name })
        assertEquals("Shooting Guard", nba[0].group)
    }

    @Test fun injuriesGroupedByTeam() {
        val list = Parse.injuries(json("nfl_injuries.json"))
        assertEquals(2, list.size)
        val k = list[0]
        assertEquals("22", k.teamId)
        assertEquals("Arizona Cardinals", k.teamName)
        assertEquals("https://l/ari.png", k.teamLogo)
        assertEquals("Questionable", k.status)
        assertEquals("Right Leg Foot", k.type)
        assertEquals("2026-10-26", k.returnDate)
        assertNotNull(k.date)
        assertEquals("Ankle", list[1].type)
        assertEquals("12", list[1].teamId)
    }

    @Test fun gameSummary() {
        val d = Parse.gameDetail(json("nba_summary.json"), L.NBA)!!
        assertEquals(63.4, d.homeWinPct!!, 0.001)
        assertEquals(36.6, d.awayWinPct!!, 0.001)
        assertEquals("ESPN BPI Win Probability", d.predictorName)
        assertEquals("3-0", d.game.home.record)
        assertEquals("Crypto.com Arena, Los Angeles", d.game.venue)
        assertEquals("", d.attendance)
        assertEquals(listOf(StatLine("PPG", "110.3", "118.0")), d.teamStats)
        assertEquals("PHX", d.leaders.single().first)
        assertEquals("27.5 PPG", d.leaders.single().second.single().value)
        assertEquals("D. Booker", d.box.single().rows.single().first)
        assertEquals(listOf("MIN", "PTS"), d.box.single().labels)
        assertEquals("LeBron James", d.injuries.single().athleteName)
        assertEquals(1, d.scoringPlays.size)
        assertTrue(d.scoringPlays[0].contains("PHX: Booker makes 3 (3-0)"))
        assertEquals("Series tied 1-1", d.seasonSeries)
        assertEquals("-180", d.odds!!.homeMoneyline)
        assertEquals(listOf("Prime Video"), d.broadcasts.map { it.network })
    }

    @Test fun teamScheduleScoresAreObjects() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)
        assertEquals(2, games.size)
        assertEquals(listOf(7, 9), games.map { it.week })
        assertEquals(8, Parse.byeWeek(json("nfl_schedule.json")))
        assertEquals(0, Parse.byeWeek(json("nba_roster.json")))
        val past = games[0]
        assertEquals(GameState.POST, past.state)
        assertEquals("27", past.home.score)
        assertEquals("20", past.away.score)
        assertEquals("4-3", past.home.record)
        assertEquals(listOf("FOX"), past.broadcasts.map { it.network })
        assertEquals("DAL", games[1].home.team.abbr)
    }

    @Test fun athleteOverview() {
        val o = Parse.overview(json("athlete_overview.json"))
        assertEquals(listOf("GP", "PTS", "REB", "AST"), o.labels)
        assertEquals(listOf("Regular Season", "Career"), o.rows.map { it.label })
        assertEquals("Booker drops 30", o.news.single().headline)
        assertEquals("Booker scores 30 in win", o.injuryNote)
        assertEquals("Phoenix Suns at Los Angeles Lakers", o.nextGame)
    }

    @Test fun teamsNewsMovesDetail() {
        assertEquals(listOf("Arizona Cardinals", "Atlanta Falcons").sorted(), Parse.teams(json("nfl_teams.json")).map { it.name })
        val news = Parse.articles(json("news.json"))
        assertEquals(1, news.size)
        assertEquals("https://i/x.jpg", news[0].image)
        assertEquals("Placed QB X on injured reserve.", Parse.transactions(json("transactions.json")).single().description)
        val td = Parse.teamDetail(json("team_detail.json"))!!
        assertEquals("4-3", td.record)
        assertEquals("2nd in NFC West", td.standingSummary)
        assertEquals("Home Record" to "3-1", td.recordDetails[1])
    }

    @Test fun streamingAndPrediction() {
        assertEquals("HBO Max", Streaming.appFor("TNT"))
        assertEquals("Peacock", Streaming.appFor("NBC"))
        assertNull(Streaming.appFor("Spectrum SportsNet"))
        val lines = Streaming.describe(L.NBA, listOf(Broadcast("Prime Video", "National"), Broadcast("Spectrum SportsNet", "Home")))
        assertEquals("Usually streams on Prime Video", lines[0])
        assertTrue(lines[1].contains("NBA League Pass"))
        val p = Predict.homeWinProb(L.NBA, "30-10", "10-30")!!
        assertTrue(p > 0.85 && p <= 0.97)
        assertNull(Predict.homeWinProb(L.NBA, "1-0", "0-1"))
    }

    // ---------- new sports ----------

    @Test fun ufcCardsMainEventFirst() {
        val card = Parse.fightCards(json("ufc_scoreboard.json")).single()
        assertEquals("UFC 322: Smith vs. Jones", card.name)
        assertEquals("Madison Square Garden, New York, NY", card.venue)
        assertEquals("Main Champ", card.fights[0].a.name)
        assertEquals("Lightweight - Title Fight", card.fights[0].weightClass)
        assertEquals("25-1-0", card.fights[0].a.record)
        assertEquals("https://h/champ.png", card.fights[0].a.headshot)
        assertEquals("Flyweight", card.fights[1].weightClass)
        assertEquals(listOf("Paramount+", "ESPN+"), card.broadcasts.map { it.network }.sorted().reversed())
        assertEquals(GameState.PRE, card.state)
    }

    @Test fun f1WeekendSessionsAndResults() {
        val w = Parse.raceWeekends(json("f1_scoreboard.json")).single()
        assertEquals("Autódromo Hermanos Rodríguez", w.circuit)
        assertEquals("Mexico City, Mexico", w.location)
        assertEquals(listOf("Qualifying", "Race"), w.sessions.map { it.name })
        val race = w.sessions[1]
        assertEquals(listOf("Max Verstappen", "Lando Norris"), race.results.map { it.name })
        assertEquals("1:40:12.3", race.results[0].detail)
        assertEquals("+3.2", race.results[1].detail)
        assertEquals("Red Bull", race.results[0].team)
        assertEquals(GameState.POST, w.state)
        assertEquals("Apple TV", Streaming.appFor(race.broadcasts.single().network))
    }

    @Test fun golfLeaderboard() {
        val t = Parse.tournaments(json("golf_scoreboard.json")).single()
        assertEquals(GameState.IN, t.state)
        assertEquals(listOf("Leader One", "Player Two"), t.players.map { it.name })
        assertEquals("-12", t.players[0].toPar)
        assertEquals("F", t.players[0].thru)
        assertEquals("T2", t.players[1].position)
        assertEquals("-2", t.players[1].today)
        assertEquals("Accordia Golf Narashino CC, Chiba, Japan", t.venue)
    }

    @Test fun tennisDrawsAndSets() {
        val e = Parse.tennisEvents(json("tennis_scoreboard.json")).single()
        assertEquals(listOf("Men's Singles"), e.draws.map { it.first }) // empty doubles draw dropped
        val m = e.draws[0].second[0]
        assertEquals("Round 1", m.round)
        assertEquals(listOf("6", "7(5)"), m.players[0].sets)
        assertTrue(m.players[0].winner)
        assertEquals("3", m.players[0].seed)
        assertEquals("Doubles A / Doubles B", e.draws[0].second[1].players[0].name)
    }

    @Test fun cricketIplFirst() {
        val series = Parse.cricket(json("cricket_header.json"))
        assertEquals("Indian Premier League", series[0].name)
        val m = series[0].matches.single()
        assertEquals(GameState.IN, m.state)
        assertEquals("150/4 (16)", m.sides[0].score)
        assertEquals("MI need 40 runs in 24 balls", m.status)
        assertEquals("https://www.espncricinfo.com/x", m.link)
        assertEquals("A won by 5 wickets", series[1].matches.single().status)
        assertEquals(GameState.POST, series[1].matches.single().state)
    }

    @Test fun soccerTableByRank() {
        val t = Parse.standings(json("epl_standings.json"), L.EPL).single()
        assertEquals(listOf("MCI", "ARS"), t.rows.map { it.team.abbr })
        assertEquals(listOf("GP", "W", "D", "L", "GF", "GA", "GD", "PTS"), t.columns.map { it.first })
        assertEquals("21", t.rows[0].stats["PTS"])
    }

    @Test fun rankingsMovement() {
        val r = Parse.rankings(json("cfb_rankings.json")).single()
        assertEquals("AP Top 25", r.name)
        assertEquals(2, r.rows[0].previous)
        assertNull(r.rows[1].previous)
        assertEquals("1525", r.rows[0].points)
        assertEquals("", r.rows[1].firstPlace)
    }

    @Test fun soccerKeyEventsLineupsAndDrawOdds() {
        val d = Parse.gameDetail(json("soccer_summary.json"), L.EPL)!!
        assertEquals(2, d.scoringPlays.size) // goal + card, not the substitution
        assertTrue(d.scoringPlays[0].contains("23' Goal · Arsenal: Saka scores."))
        assertEquals("Bukayo Saka", d.lineups.single().second.first().name)
        assertEquals("240", d.odds!!.drawMoneyline)
        assertNull(Predict.homeWinProb(L.EPL, "6-2-1", "7-0-2")) // no record estimate where draws exist
    }

    @Test fun localDayUsesPhoneTimeZone() {
        // A 7:30 pm Phoenix game is 02:30 UTC the next day; it belongs to Phoenix's date.
        val nba = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)
        val phoenix = java.time.ZoneId.of("America/Phoenix")
        val tokyo = java.time.ZoneId.of("Asia/Tokyo")
        val oct27 = java.time.LocalDate.of(2026, 10, 27)
        assertEquals(2, Espn.onLocalDate(nba + nba, oct27, phoenix).size) // de-duplicated
        assertEquals(0, Espn.onLocalDate(nba, oct27, tokyo).size)
        assertEquals(2, Espn.onLocalDate(nba, oct27.plusDays(1), tokyo).size)
    }

    @Test fun catalogIsComplete() {
        val keys = Leagues.all.map { it.key }
        listOf("NFL", "NBA", "MLB", "NHL", "WNBA", "UFL", "EPL", "MLS", "UCL", "LALIGA", "BUNDESLIGA", "SERIEA", "LIGUE1",
            "WORLDCUP", "EURO", "COPA", "CFB", "MCBB", "WCBB", "UFC", "F1", "NASCAR", "INDYCAR", "PGA", "ATP", "WTA",
            "CRICKET", "SIXNATIONS", "RWC").forEach { assertTrue(it, it in keys) }
        assertEquals(keys.size, keys.toSet().size)
    }

    // ---------- location: TV markets and venue clocks ----------

    private val phoenix = UserPlace(33.45, -112.07, "Phoenix, AZ", true)
    private val losAngeles = UserPlace(34.05, -118.24, "Los Angeles, CA", false)

    @Test fun teamsMapToTheirMetro() {
        fun m(name: String, l: League) = Places.metroFor(TeamRef("1", "X", name), l)?.key
        assertEquals("PHX", m("Phoenix Suns", L.NBA))
        assertEquals("PHX", m("Arizona Diamondbacks", L.MLB))
        assertEquals("LA", m("LA Clippers", L.NBA))
        assertEquals("ATL", m("Atlanta Hawks", L.NBA)) // not "LA"
        assertEquals("LV", m("Vegas Golden Knights", L.NHL))
        assertEquals("TB", m("Tampa Bay Lightning", L.NHL))
        assertEquals("MIA", m("Inter Miami CF", Leagues.of("MLS")!!))
        assertEquals("SLC", m("Real Salt Lake", Leagues.of("MLS")!!))
        assertEquals("WAS", m("D.C. United", Leagues.of("MLS")!!))
        assertNull(m("Arsenal", L.EPL))
    }

    @Test fun localChannelDependsOnWhereYouAre() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        val fromPhoenix = Tv.plan(lakers, phoenix)
        assertEquals(Reach.NATIONAL, fromPhoenix[0].reach)
        assertEquals("Prime Video · usually streams on Prime Video", fromPhoenix[0].text)
        val rsn = fromPhoenix.first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_ELSEWHERE, rsn.reach)
        assertTrue(rsn.text.contains("NBA League Pass"))
        val fromLA = Tv.plan(lakers, losAngeles).first { it.network == "Spectrum SportsNet" }
        assertEquals(Reach.LOCAL_YOURS, fromLA.reach)
        assertTrue(fromLA.text.contains("Spectrum SportsNet app"))
        assertEquals(Reach.LOCAL_UNKNOWN, Tv.plan(lakers, null).first { it.network == "Spectrum SportsNet" }.reach)
        // score cards hide channels you can't get
        assertEquals(listOf("Prime Video" to false), Tv.cardNetworks(lakers, phoenix))
        assertEquals(listOf("Spectrum SportsNet" to true, "Prime Video" to false).sortedBy { it.first }, Tv.cardNetworks(lakers, losAngeles).sortedBy { it.first })
    }

    @Test fun overTheAirNetworksGetAFinder() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB).single()
        val fox = Tv.plan(g, phoenix).single()
        assertEquals("On your local FOX station · usually streams on Fox One", fox.text)
        assertTrue(fox.findUrl!!.contains("FOX+channel+Phoenix"))
    }

    @Test fun venueClocks() {
        val lakers = Parse.scoreboard(json("nba_scoreboard.json"), L.NBA).first { it.id == "401800002" }
        assertEquals("America/Los_Angeles", Places.venueZone(lakers)!!.id)
        assertEquals("Asia/Tokyo", Places.zoneFromPlace("Chiba, Japan")!!.id)
        assertEquals("America/Mexico_City", Places.zoneFromPlace("Mexico City, Mexico")!!.id)
        assertEquals("America/New_York", Places.zoneFromPlace("Madison Square Garden, New York, NY")!!.id)
    }

    @Test fun byeWeeksFromGapsAndFeed() {
        val games = Parse.schedule(json("nfl_schedule.json"), L.NFL)   // weeks 7 and 9
        assertEquals(listOf(8), Byes.weeks(games))                      // inferred from the gap
        assertEquals(listOf(8), Byes.weeks(games, 8))                   // feed agrees, no duplicate
        assertEquals(listOf(5, 8), Byes.weeks(games, 5))                // feed names one the gap can't see
        assertEquals(7, Byes.placement(games, listOf(8))[8]?.week)      // sits after the week-7 game
        assertNull(Byes.placement(games, listOf(5))[5])                 // before the first listed game
        assertEquals(emptyList<Int>(), Byes.weeks(Parse.scoreboard(json("nba_scoreboard.json"), L.NBA)))
    }

    @Test fun updateVersionsCompare() {
        assertEquals("2.4", Updates.versionOf("Sideline 2.4"))
        assertEquals("2.4", Updates.versionOf("v2.4-build7"))
        assertEquals("2.10.1", Updates.versionOf("Sideline 2.10.1"))
        assertEquals("", Updates.versionOf("build-3"))
        assertTrue(Updates.newer("2.5", "2.4"))
        assertTrue(Updates.newer("2.10", "2.9"))
        assertTrue(Updates.newer("3.0", "2.99"))
        assertFalse(Updates.newer("2.4", "2.4"))
        assertFalse(Updates.newer("2.3", "2.4"))
        assertTrue(Updates.newer("2.4.1", "2.4"))
    }

    @Test fun releaseNotesBecomePlainBullets() {
        val body = "## Sideline 2.6\n\n- Widget shows logos\n* Patch notes in the banner\n\nPlain line\n"
        assertEquals("• Sideline 2.6\n• Widget shows logos\n• Patch notes in the banner\n• Plain line", Updates.notes(body))
        assertEquals("", Updates.notes(""))
    }

    @Test fun leadersBothShapes() {
        val boards = More.leaders(json("nba_leaders.json"))
        assertEquals(1, boards.size)                                  // the empty category is dropped
        assertEquals("Points Per Game", boards[0].category)
        assertEquals("Devin Booker", boards[0].rows[1].name)
        assertEquals("PHX", boards[0].rows[1].team)
        assertEquals(2, boards[0].rows[1].rank)
        val flat = More.leaders(JSONObject().put("categories", json("nba_leaders.json").getJSONObject("leaders").getJSONArray("categories")))
        assertEquals(boards, flat)
    }

    @Test fun teamSeasonStats() {
        val cats = More.teamStats(json("team_stats.json"))
        assertEquals(listOf("Offense", "Defense"), cats.map { it.first })
        assertEquals(TeamStat("Points Per Game", "118.2", "4th"), cats[0].second[0])
        assertEquals("", cats[0].second[1].rank)
    }

    @Test fun playerSearchMapsLeagues() {
        val hits = More.searchPlayers(json("search.json"))
        assertEquals(2, hits.size)                                    // team result skipped, duplicate dropped
        assertEquals("3136193", hits[0].id)
        assertEquals("NBA", hits[0].league?.key)
        assertNull(hits[1].league)                                    // a league Sideline doesn't cover
    }

    @Test fun teamSearchRanksMatches() {
        val nba = Leagues.of("NBA")!!
        val teams = listOf(
            nba to TeamRef("1", "PHX", "Phoenix Suns", "Suns"),
            nba to TeamRef("2", "LAL", "Los Angeles Lakers", "Lakers"),
            nba to TeamRef("3", "SAS", "San Antonio Spurs", "Spurs"),
        )
        assertEquals(listOf("1"), More.matchTeams("suns", teams).map { it.second.id })
        assertEquals(listOf("2"), More.matchTeams("lal", teams).map { it.second.id })
        assertEquals(listOf("3"), More.matchTeams("san", teams).map { it.second.id })
        assertEquals(emptyList<Any>(), More.matchTeams("s", teams))   // one letter is too short to search
        assertEquals(emptyList<Any>(), More.matchTeams("x", teams))
    }

    @Test fun mlbProbablePitcher() {
        val g = Parse.scoreboard(json("mlb_scoreboard_live.json"), L.MLB)
        assertTrue(g.flatMap { listOf(it.home.probable, it.away.probable) }.contains("L. Webb (12-8, 3.21)"))
    }

    @Test fun playByPlay() {
        val plays = More.plays(json("nba_summary.json"), L.NBA)
        assertTrue(plays.isNotEmpty())
        assertEquals("Booker makes 3", plays[0].text)
        assertEquals("Q1", plays[0].period)
        assertEquals("PHX", plays[0].team)
        assertTrue(plays[0].scoring)
        assertEquals("3", plays[0].away)
    }

    @Test fun playoffRoundsAndSeries() {
        val nba = Leagues.of("NBA")!!
        val a = TeamRef("1", "PHX", "Phoenix Suns"); val b = TeamRef("2", "DEN", "Denver Nuggets")
        fun g(id: String, note: String, aWin: Boolean?, day: Long) = Game(id, nba, java.time.Instant.ofEpochSecond(1_700_000_000 + day * 86400), "", "",
            if (aWin == null) GameState.PRE else GameState.POST, "", "",
            Competitor(b, home = true, score = "100", winner = aWin == false), Competitor(a, home = false, score = "101", winner = aWin == true), note = note)
        val rounds = More.rounds(listOf(
            g("1", "West 1st Round - Game 1", true, 0), g("2", "West 1st Round - Game 2", true, 2),
            g("3", "West 1st Round - Game 3", false, 4), g("4", "West 1st Round - Game 4", null, 6),
        ))
        assertEquals(1, rounds.size)
        assertEquals("West 1st Round", rounds[0].name)
        assertEquals("PHX leads 2-1", rounds[0].series.single().summary)
        assertEquals(4, rounds[0].series.single().games.size)
    }

    @Test fun backupRoundTrip() {
        val nba = Leagues.of("NBA")!!
        Favorites.list.clear(); Players.list.clear()
        Favorites.list.add(Favorite(nba, TeamRef("21", "PHX", "Phoenix Suns", "Suns", "https://l/phx.png", "1d1160")))
        Players.list.add(FollowedPlayer(nba, Player("3136193", "Devin Booker", headshot = "https://h/b.png", teamName = "Phoenix Suns")))
        val b = More.backup()
        assertEquals("Sideline", b.getString("app"))
        assertEquals("PHX", b.getJSONArray("favorites").getJSONObject(0).getString("abbr"))
        assertEquals("Devin Booker", b.getJSONArray("players").getJSONObject(0).getString("name"))
        Players.list.clear()
        Players.fromJson(b.getJSONArray("players"))
        assertEquals("3136193", Players.list.single().player.id)
        Favorites.list.clear(); Players.list.clear()
    }

    private fun live(key: String, a: String, h: String, periods: Int, clock: String): Game {
        val l = Leagues.of(key)!!
        val ls = List(periods) { "0" }
        return Game("x", l, java.time.Instant.now(), "", "", GameState.IN, "", "",
            Competitor(TeamRef("1", "HOM", "Home"), home = true, score = h, linescores = ls),
            Competitor(TeamRef("2", "AWY", "Away"), home = false, score = a, linescores = ls), clock = clock)
    }

    @Test fun closeGameRules() {
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NBA", "101", "99", 4, "3:10")))     // 2 pts, 4th, under 5 min
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NBA", "101", "99", 4, "9:10")))    // too early in the 4th
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NBA", "110", "99", 4, "1:00")))    // blowout
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NBA", "110", "110", 5, "4:00")))    // overtime always counts
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NFL", "24", "20", 4, "5:30")))      // one score, late
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("NHL", "2", "2", 3, "8:00")))        // tied in the 3rd
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("NHL", "2", "2", 2, "8:00")))       // only the 2nd
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("MLB", "3", "4", 9, "")))            // 1 run, 9th
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("MLB", "3", "4", 6, "")))           // 6th inning
        assertTrue(com.roki.sideline.work.Alerts.isClose(live("EPL", "1", "1", 2, "81'")))         // level, 81st minute
        assertFalse(com.roki.sideline.work.Alerts.isClose(live("EPL", "1", "1", 2, "60'")))
        assertEquals(90.0, com.roki.sideline.work.Alerts.clockMinutes(live("EPL", "0", "0", 2, "90'+3'"))!!, 0.01)
        assertEquals(4.5, com.roki.sideline.work.Alerts.clockMinutes(live("NBA", "0", "0", 4, "4:30"))!!, 0.01)
    }

    private fun g(key: String, awayId: String, awayAbbr: String, homeId: String, homeAbbr: String) = Game("1", Leagues.of(key)!!, null, "", "",
        GameState.IN, "", "", Competitor(TeamRef(homeId, homeAbbr, homeAbbr), home = true), Competitor(TeamRef(awayId, awayAbbr, awayAbbr), home = false))

    @Test fun baseballLive() {
        val mlb = Leagues.of("MLB")!!
        val b = LiveParse.parse(json("mlb_live_summary.json"), mlb, g("MLB", "8", "MIL", "30", "TB")).baseball!!
        assertEquals(listOf(1, 2, 2), listOf(b.balls, b.strikes, b.outs))
        assertEquals(listOf(true, false, true), listOf(b.first, b.second, b.third))   // a runner object counts as occupied
        assertEquals("T. Megill", b.pitcher!!.name)
        assertEquals("6.2 IP, 2 ER, 7 K", b.pitcher!!.line)
        assertEquals(mlb.headshotUrl("2"), b.batter!!.headshot)                          // missing headshot filled in
        assertEquals("J. Aranda", b.onDeck)
        assertEquals(4, b.pitches.size)                                                  // only the current at-bat
        assertEquals(listOf(PitchKind.BALL, PitchKind.STRIKE, PitchKind.STRIKE, PitchKind.STRIKE), b.pitches.map { it.kind })
        assertEquals("Slider", b.pitches[1].type)
        assertEquals("86", b.pitches[1].mph)
        assertEquals(3, b.calledStrikes.size)                                            // across the whole game
        assertEquals(PitchKind.IN_PLAY, LiveParse.pitchKind("In play, out(s)"))
        assertEquals(PitchKind.BALL, LiveParse.pitchKind("Hit By Pitch"))
    }

    @Test fun footballFieldPosition() {
        assertEquals(35.0, LiveParse.ballX("KC 35", "KC", "BUF")!!, 0.01)    // away side: yards from the away goal
        assertEquals(65.0, LiveParse.ballX("BUF 35", "KC", "BUF")!!, 0.01)   // home side, measured from the other end
        assertEquals(50.0, LiveParse.ballX("50", "KC", "BUF")!!, 0.01)
        assertNull(LiveParse.ballX("", "KC", "BUF"))
        assertNull(LiveParse.ballX("NYJ 20", "KC", "BUF"))
        val nfl = Leagues.of("NFL")!!
        val game = g("NFL", "12", "KC", "2", "BUF")
        val sit = JSONObject().put("down", 3).put("distance", 7).put("possession", "12").put("possessionText", "BUF 20")
            .put("downDistanceText", "3rd & 7 at BUF 20").put("isRedZone", true).put("homeTimeouts", 2).put("awayTimeouts", 3)
        val f = LiveParse.parse(JSONObject(), nfl, game, sit).football!!
        assertEquals(80.0, f.ballX!!, 0.01)
        assertEquals(87.0, f.toGainX!!, 0.01)          // KC drives toward the home goal line
        assertTrue(f.redZone)
        assertEquals(2, f.homeTimeouts)
        sit.put("downDistanceText", "1st & Goal at BUF 4").put("possessionText", "BUF 4").put("down", 1).put("distance", 4)
        assertEquals(100.0, LiveParse.parse(JSONObject(), nfl, game, sit).football!!.toGainX!!, 0.01)
        sit.put("possession", "2").put("possessionText", "BUF 30").put("downDistanceText", "2nd & 10 at BUF 30").put("distance", 10).put("down", 2)
        assertEquals(60.0, LiveParse.parse(JSONObject(), nfl, game, sit).football!!.toGainX!!, 0.01)   // BUF heads the other way
    }

    @Test fun basketballShotChart() {
        val shots = LiveParse.parse(json("nba_live_shots.json"), Leagues.of("NBA")!!, g("NBA", "7", "DEN", "21", "PHX")).shots
        assertEquals(2, shots.size)                    // free throw, bad coordinates and non-shots dropped
        assertTrue(shots[0].made)
        assertEquals(40.0, shots[1].x, 0.01)           // far-court shot folded onto the near basket
        assertEquals(14.0, shots[1].y, 0.01)
    }

    @Test fun hockeyShotMap() {
        val shots = LiveParse.parse(json("nhl_live_shots.json"), Leagues.of("NHL")!!, g("NHL", "3", "BOS", "21", "TOR")).shots
        assertEquals(3, shots.size)
        assertEquals(listOf(false, true, false), shots.map { it.made })
    }

    @Test fun soccerFormation() {
        val f = LiveParse.parse(json("soccer_lineups.json"), Leagues.of("EPL")!!, g("EPL", "1", "AAA", "359", "ARS")).formations
        assertEquals(1, f.size)                        // a team without eleven starters is skipped
        assertEquals("4-2-3-1", f[0].shape)
        assertEquals(listOf(1, 4, 2, 3, 1), f[0].rows.map { it.size })
        assertEquals("Raya", f[0].rows[0][0].name)
        assertEquals(listOf("Calafiori", "Gabriel", "Saliba", "White"), f[0].rows[1].map { it.name })   // left to right
        assertEquals(listOf("Trossard", "Ødegaard", "Saka"), f[0].rows[3].map { it.name })
        assertEquals("Gyökeres", f[0].rows[4][0].name)
        // A shape that doesn't add up falls back to grouping by position.
        val loose = LiveParse.rows("3-3", f[0].rows.drop(1).flatten().map { it to it.pos })
        assertEquals(listOf(4, 2, 1, 3), loose.map { it.size })
    }

    @Test fun baseballFieldersAndClips() {
        val mlb = Leagues.of("MLB")!!
        val top = g("MLB", "8", "MIL", "30", "TB").copy(statusShort = "Top 12th")
        val live = LiveParse.parse(json("mlb_live_summary.json"), mlb, top)
        val b = live.baseball!!
        assertEquals("30", b.fieldingTeamId)                        // top of the inning: the home team fields
        assertEquals("R. Palacios", b.fielders["SS"]!!.name)       // the sub replaced Walls at short
        assertEquals("T. Megill", b.fielders["P"]!!.name)          // pitcher from the live situation
        assertNull(b.fielders["DH"])
        assertEquals(setOf("P", "C", "1B", "2B", "3B", "SS", "LF", "CF", "RF"), b.fielders.keys)
        // Bottom of the inning: the away team fields, and one listed player isn't enough to draw.
        assertTrue(LiveParse.parse(json("mlb_live_summary.json"), mlb, top.copy(statusShort = "Bot 12th")).baseball!!.fielders.isEmpty())
        assertEquals(true, LiveParse.fieldingIsHome("End 6th"))
        assertEquals(false, LiveParse.fieldingIsHome("Mid 7th"))
        assertNull(LiveParse.fieldingIsHome("Final"))
        assertEquals(listOf("https://v/1.mp4", "https://v/2.m3u8"), live.clips.map { it.url })   // the unplayable one is dropped
        assertEquals(42, live.clips[0].seconds)
    }

    @Test fun gamePhotoSources() {
        val summary = Photos.fromSummary(json("photos_summary.json"))
        assertEquals(2, summary.size)                                   // logo composite and thumbnail dropped
        assertEquals("Pratt doubles in the 12th", summary[0].caption)
        assertEquals("AP Photo/Morry Gash", summary[0].credit)
        assertEquals("Celebration", summary[1].caption)                 // alt text when there's no caption
        val start = java.time.Instant.parse("2026-10-28T00:08:00Z")
        val (from, to) = Photos.gameWindow(start)
        val news = Photos.fromNews(json("photos_news.json"), from, to)
        assertEquals(2, news.size)                                      // last week's story and the undated one left out
        val all = Photos.merge(summary, news)
        assertEquals(3, all.size)                                       // the smaller copy of the recap photo is a repeat
        assertEquals(listOf("Pratt doubles in the 12th", "Celebration", "Dugout"), all.map { it.caption })
        assertEquals(Photos.key("https://x/r1_1296x729_16-9.jpg"), Photos.key("https://x/r1_576x324.jpg"))
    }

    @Test fun groupedTeamStats() {
        fun stat(name: String, label: String, v: String) = JSONObject().put("name", name).put("displayName", label).put("displayValue", v)
        fun box(id: String, hits: String, hr: String, era: String) = JSONObject().put("team", JSONObject().put("id", id)).put("statistics", org.json.JSONArray()
            .put(JSONObject().put("name", "batting").put("displayName", "Batting").put("stats", org.json.JSONArray()
                .put(stat("hits", "Hits", hits)).put(stat("homeRuns", "Home Runs", hr)).put(stat("empty", "Empty", ""))))
            .put(JSONObject().put("name", "pitching").put("displayName", "Pitching").put("stats", org.json.JSONArray().put(stat("ERA", "ERA", era))))
            .put(JSONObject().put("name", "fielding").put("displayName", "Fielding").put("stats", org.json.JSONArray())))
        val lines = More.teamStatLines(box("8", "9", "2", "1.50"), box("30", "6", "1", "4.00"))
        assertEquals(listOf("Batting", "Hits", "Home Runs", "Pitching", "ERA"), lines.map { it.label })   // empty group and stat dropped
        assertTrue(lines[0].header)
        assertEquals(StatLine("Hits", "9", "6"), lines[1])
        assertEquals(StatLine("ERA", "1.50", "4.00"), lines[4])
        // The flat layout most sports use still works.
        val flat = Parse.gameDetail(json("nba_summary.json"), L.NBA)!!.teamStats
        assertTrue(flat.isNotEmpty() && flat.none { it.header } && flat.all { it.away.isNotBlank() || it.home.isNotBlank() })
    }

    @Test fun winProbabilityDrivesRecap() {
        val root = json("story_summary.json")
        assertEquals(listOf(50.0, 55.0, 62.0, 40.0, 91.0), Story.winProbability(root).map { Math.round(it).toDouble() })
        assertEquals(emptyList<Double>(), Story.winProbability(JSONObject().put("winprobability", org.json.JSONArray().put(JSONObject().put("homeWinPercentage", 0.5)))))
        val drives = Story.drives(root)
        assertEquals(listOf("Touchdown", "PUNT", "In progress"), drives.map { it.result })   // empty drive dropped, current one last
        assertEquals(75, drives[0].yards)
        assertTrue(drives[0].scored)
        assertEquals("https://l/kc.png", drives[0].logo)
        val recap = Story.recap(root)!!
        assertEquals("Brewers walk it off", recap.headline)
        assertEquals(listOf("MILWAUKEE \u2014 Cooper Pratt's double in the 12th won it.", "\u201CHuge,\u201D he said.", "Game 4 is Friday."), recap.paragraphs)
        assertNull(Story.recap(JSONObject().put("article", JSONObject().put("story", "<p>Too short</p>"))))
    }

    @Test fun golfHoles() {
        val c = JSONObject("""{"linescores":[
            {"displayValue":"-2","linescores":[{"value":4.0,"period":1,"scoreType":{"displayValue":"E"}},{"value":2.0,"period":2,"scoreType":{"displayValue":"-1"}}]},
            {"displayValue":"-1"}]}""")
        val holes = Story.holes(c)
        assertEquals(2, holes.size)
        assertEquals(listOf(Hole(1, "4", "E"), Hole(2, "2", "-1")), holes[0])
        assertTrue(holes[1].isEmpty())                             // round with no hole data posted
    }

    @Test fun compareAndCalendar() {
        val rows = com.roki.sideline.ui.compareRows(
            listOf("GP", "PTS", "REB", "AST"), StatRow("2025-26", listOf("8", "30.1", "4.2", "6.0")),
            listOf("GP", "PTS", "AST", "BLK"), StatRow("2025-26", listOf("7", "27.5", "9.1", "0.5")),
        )
        assertEquals(listOf(Triple("GP", "8", "7"), Triple("PTS", "30.1", "27.5"), Triple("AST", "6.0", "9.1")), rows)   // shared columns only
        assertEquals(emptyList<Any>(), com.roki.sideline.ui.compareRows(listOf("GP"), null, listOf("GP"), StatRow("x", listOf("1"))))
        val nba = Leagues.of("NBA")!!
        val phx = TeamRef("21", "PHX", "Phoenix Suns", "Suns")
        val lal = TeamRef("13", "LAL", "Los Angeles Lakers", "Lakers")
        fun game(id: String, state: GameState, home: TeamRef, away: TeamRef, start: java.time.Instant?) =
            Game(id, nba, start, "", "", state, "", "", Competitor(home, home = true), Competitor(away, home = false))
        val t0 = java.time.Instant.parse("2026-11-01T02:00:00Z")
        assertEquals("NBA: Suns vs Lakers", SeasonCalendar.title(game("1", GameState.PRE, phx, lal, t0), phx))
        assertEquals("NBA: Suns at Lakers", SeasonCalendar.title(game("2", GameState.PRE, lal, phx, t0), phx))
        val list = listOf(game("1", GameState.PRE, phx, lal, t0), game("2", GameState.POST, phx, lal, t0), game("3", GameState.PRE, phx, lal, null))
        assertEquals(listOf("1"), SeasonCalendar.upcoming(list).map { it.id })   // finished and TBD games aren't added
    }

    @Test fun spokenSummaries() {
        fun bb(balls: Int, strikes: Int, outs: Int, f: Boolean, s: Boolean, t: Boolean) =
            BaseballLive(balls, strikes, outs, f, s, t, null, null, "", emptyList(), emptyList())
        assertEquals("2 balls, 1 strike, 1 out. Bases empty.", com.roki.sideline.ui.countSummary(bb(2, 1, 1, false, false, false)))
        assertEquals("0 balls, 2 strikes, 2 outs. Runners on first and third.", com.roki.sideline.ui.countSummary(bb(0, 2, 2, true, false, true)))
        assertEquals("3 balls, 2 strikes, 0 outs. Bases loaded.", com.roki.sideline.ui.countSummary(bb(3, 2, 0, true, true, true)))
        val pitches = listOf(Pitch(1, 0.0, 0.0, "Four-seam Fastball", "97", "Ball", PitchKind.BALL), Pitch(2, 0.0, 0.0, "Slider", "", "Strike looking", PitchKind.STRIKE))
        assertEquals("Pitches this at bat: 1, Four-seam Fastball, 97 mph, Ball; 2, Slider, Strike looking", com.roki.sideline.ui.pitchSummary(pitches))
    }

    @Test fun inningBreak() {
        val mlb = Leagues.of("MLB")!!
        fun bat(id: String, name: String, pos: String, hab: String, avg: String, subbed: Boolean = false) =
            """{"athlete":{"id":"$id","shortName":"$name"},"position":{"abbreviation":"$pos"},"subbedOut":$subbed,"stats":["$hab","0","0","$avg"]}"""
        fun pit(id: String, name: String) = """{"athlete":{"id":"$id","shortName":"$name"},"stats":[]}"""
        val root = JSONObject("""{
          "situation":{"balls":2,"strikes":2,"outs":3,
            "pitcher":{"athlete":{"id":"900","shortName":"Misiorowski"}},
            "dueUp":[{"athlete":{"id":"1"}},{"athlete":{"id":"2"}},{"athlete":{"id":"3"}}]},
          "plays":[{"pitchCoordinate":{"x":100,"y":150},"atBatId":"a1","type":{"text":"Strike Swinging"}}],
          "boxscore":{"players":[
            {"team":{"id":"8"},"statistics":[
              {"type":"batting","labels":["H-AB","R","RBI","AVG"],"athletes":[
                ${bat("1","Contreras","C","0-0",".270")},${bat("2","Turang","2B","0-0",".268")},${bat("3","Frelick","RF","0-0",".230")}]},
              {"type":"pitching","athletes":[${pit("900","Misiorowski")}]}]},
            {"team":{"id":"30"},"statistics":[
              {"type":"batting","labels":["H-AB","R","RBI","AVG"],"athletes":[
                ${bat("11","Hicks","C","0-1",".250")},${bat("12","Aranda","1B","0-1",".280")},${bat("13","Williamson","2B","0-0",".260")},
                ${bat("14","Caminero","3B","0-1",".290")},${bat("15","Walls","SS","0-0",".220")},${bat("16","Simpson","LF","0-0",".240")},
                ${bat("17","DeLuca","CF","0-0",".230")},${bat("18","Vilade","RF","0-0",".210")}]},
              {"type":"pitching","athletes":[${pit("20","Littell")},${pit("21","Rasmussen")}]}]}]}
        }""")
        val mil = TeamRef("8", "MIL", "Milwaukee Brewers", "Brewers")
        val tb = TeamRef("30", "TB", "Tampa Bay Rays", "Rays")
        val g = Game("1", mlb, null, "", "", GameState.IN, "End of 1st", "End 1st", Competitor(tb, home = true), Competitor(mil, home = false))
        val b = LiveParse.parse(root, mlb, g).baseball!!
        assertTrue(b.betweenInnings)
        assertEquals("30", b.fieldingTeamId)                                 // Rays take the field for the top of the 2nd
        assertEquals("Rasmussen", b.fielders["P"]?.name)                    // not Milwaukee's pitcher from the last half
        assertEquals("Hicks", b.fielders["C"]?.name)
        assertEquals(listOf("Contreras C 0-0, .270", "Turang 2B 0-0, .268", "Frelick RF 0-0, .230"), b.dueUp.map { "${it.name} ${it.pos} ${it.line}" })
        // During play nothing changes: the live pitcher stays and there's no due up row.
        val during = LiveParse.parse(root, mlb, g.copy(statusShort = "Top 2nd")).baseball!!
        assertFalse(during.betweenInnings)
        assertEquals("Misiorowski", during.fielders["P"]?.name)
        assertTrue(during.dueUp.isEmpty())
        assertFalse(LiveParse.isBetweenInnings("Bot 5th")); assertTrue(LiveParse.isBetweenInnings("Mid 5th"))
    }

    @Test fun gamePhotoFilter() {
        val start = java.time.Instant.parse("2026-10-29T00:08:00Z")
        val (from, to) = Photos.gameWindow(start)
        fun t(id: String, name: String, short: String) = TeamRef(id, id, name, short)
        fun check(ours: List<TeamRef>, others: List<TeamRef>, key: String, label: String, note: String, soccer: Boolean = false) =
            Photos.GameCheck(ours, others, key, label, note, from, to, soccer)
        fun ok(k: Photos.GameCheck, caption: String, recap: Boolean = false) = Photos.aboutGame(GamePhoto("https://x/a.jpg", caption, "", recap), k)

        // MLB, World Series Game 5, Brewers at Rays: the four photos from the screenshots and some that belong.
        val mil = t("8", "Milwaukee Brewers", "Brewers"); val tb = t("30", "Tampa Bay Rays", "Rays")
        val mlb = listOf(mil, tb, t("10", "New York Yankees", "Yankees"), t("4", "Chicago White Sox", "White Sox"), t("2", "Boston Red Sox", "Red Sox"),
            t("22", "Philadelphia Phillies", "Phillies"), t("15", "Atlanta Braves", "Braves"), t("16", "Chicago Cubs", "Cubs"))
        val ws = check(listOf(mil, tb), mlb, "MLB", "MLB", "World Series - Game 5")
        assertFalse(ok(ws, "Max Fried #54 of the New York Yankees looks on during Game 3 of the American League Division Series."))
        assertFalse(ok(ws, "George Lombard Jr. #96, Aaron Judge #99, and Paul Goldschmidt #48 of the New York Yankees look on during the seventh inning in Game 3 of the American League Division Series against the Tampa Bay Rays."))
        assertFalse(ok(ws, "Munetaka Murakami #5 of the Chicago White Sox walks to the dugout after striking out."))
        assertFalse(ok(ws, "Bryce Harper of the Philadelphia Phillies walks back to the dugout after striking out against the Atlanta Braves."))
        assertTrue(ok(ws, "Jackson Chourio #11 of the Milwaukee Brewers celebrates after defeating the Tampa Bay Rays in Game 5 of the 2026 World Series at Tropicana Field on October 28, 2026 in St Petersburg, Florida."))
        assertTrue(ok(ws, "The Brewers celebrate on the field."))
        assertFalse(ok(ws, "Brewers beat the Rays in Game 2."))                                           // earlier game, same series
        assertFalse(ok(ws, "Christian Yelich of the Milwaukee Brewers at bat on September 2, 2026."))     // dated outside the game
        assertFalse(ok(ws, "The Brewers celebrate winning the 2018 NL Central."))                          // another season
        assertFalse(ok(ws, "A view of the stadium before the game."))                                      // news photo naming neither team
        assertFalse(ok(ws, "Rays of light over the field as the Cubs take batting practice."))
        assertFalse(ok(ws, ""))
        assertTrue(ok(ws, "", recap = true))                                                               // the recap's own photos
        // Same teams in the regular season: a playoff photo doesn't belong.
        val reg = check(listOf(mil, tb), mlb, "MLB", "MLB", "")
        assertFalse(ok(reg, "Brewers players celebrate in the World Series."))
        assertFalse(ok(reg, "Rays starter in Game 4."))
        assertTrue(ok(reg, "Brewers starter delivers a pitch against the Tampa Bay Rays."))
        // A Cubs game must not pick up a White Sox photo (shared city), or the reverse.
        val chi = check(listOf(t("16", "Chicago Cubs", "Cubs"), mil), mlb, "MLB", "MLB", "")
        assertFalse(ok(chi, "Andrew Vaughn of the Chicago White Sox runs the bases."))
        assertTrue(ok(chi, "Seiya Suzuki of the Chicago Cubs runs the bases."))

        // NFL and college football: nicknames and shared nicknames.
        val kc = t("12", "Kansas City Chiefs", "Chiefs"); val den = t("7", "Denver Broncos", "Broncos")
        val nfl = check(listOf(kc, den), listOf(kc, den, t("21", "Philadelphia Eagles", "Eagles"), t("1", "Atlanta Falcons", "Falcons")), "NFL", "NFL", "")
        assertTrue(ok(nfl, "Patrick Mahomes #15 of the Kansas City Chiefs throws a pass."))
        assertFalse(ok(nfl, "Jalen Hurts of the Philadelphia Eagles in Super Bowl LIX."))
        val lsu = t("99", "LSU Tigers", "LSU"); val bama = t("333", "Alabama Crimson Tide", "Alabama"); val aub = t("2", "Auburn Tigers", "Auburn")
        val cfb = check(listOf(lsu, bama), listOf(lsu, bama, aub, t("61", "Georgia Bulldogs", "Georgia")), "CFB", "College Football", "")
        assertTrue(ok(cfb, "The LSU Tigers take the field against Alabama."))
        assertFalse(ok(cfb, "Auburn Tigers quarterback scrambles."))
        assertFalse(ok(cfb, "Georgia Bulldogs defense lines up."))

        // Soccer: a league photo in a cup game, and the other way round.
        val ars = t("359", "Arsenal", "Arsenal"); val psv = t("148", "PSV Eindhoven", "PSV")
        val ucl = check(listOf(ars, psv), listOf(ars, psv, t("450", "Bayern Munich", "Bayern")), "UCL", "Champions League", "", soccer = true)
        assertTrue(ok(ucl, "Bukayo Saka of Arsenal celebrates scoring during the UEFA Champions League match between Arsenal FC and PSV Eindhoven."))
        assertFalse(ok(ucl, "Bukayo Saka of Arsenal celebrates during the Premier League match between Arsenal FC and Chelsea FC."))
        val epl = check(listOf(ars, t("363", "Chelsea", "Chelsea")), listOf(ars, t("363", "Chelsea", "Chelsea"), t("382", "Manchester City", "Man City")), "EPL", "Premier League", "", soccer = true)
        assertTrue(ok(epl, "Bukayo Saka of Arsenal during the Premier League match between Arsenal FC and Chelsea FC."))
        assertFalse(ok(epl, "Bukayo Saka of Arsenal during the UEFA Champions League match against PSV."))
        assertFalse(ok(epl, "Erling Haaland of Manchester City scores against Arsenal."))
        val wc = check(listOf(t("205", "Brazil", "Brazil"), t("478", "France", "France")), emptyList(), "WORLDCUP", "FIFA World Cup", "", soccer = true)
        assertTrue(ok(wc, "Kylian Mbappe of France during the FIFA World Cup 2026 match."))
        assertFalse(ok(wc, "Vinicius Junior of Brazil during the FIFA Club World Cup."))
        assertFalse(ok(wc, "France players before the World Cup qualifier."))

        assertEquals(5, Photos.gameNumber("World Series - Game 5"))
        assertNull(Photos.gameNumber("Regular Season"))
        assertEquals(listOf(java.time.LocalDate.of(2026, 10, 28), java.time.LocalDate.of(2026, 3, 4)), Photos.datesIn("on October 28, 2026 and 4 March 2026"))
    }

    @Test fun eventPhotoFilter() {
        val start = java.time.Instant.parse("2026-10-25T20:00:00Z")
        val (from, to) = Photos.eventWindow(start, start.plusSeconds(3 * 3600))
        fun ok(caption: String, names: List<String>) = Photos.aboutEvent(GamePhoto("https://x/a.jpg", caption, ""), names, from, to)
        val f1 = listOf("Max Verstappen", "Lando Norris", "Oscar Piastri")
        assertTrue(ok("Max Verstappen of the Netherlands driving during the F1 Grand Prix of Mexico on October 25, 2026.", f1))
        assertFalse(ok("Max Verstappen celebrates on the podium on October 19, 2025.", f1))      // last year's race
        assertFalse(ok("A general view of the paddock.", f1))                                     // names nobody in the event
        assertFalse(ok("Lewis Hamilton on the grid.", emptyList()))                               // no field to check against
        assertTrue(ok("Jannik Sinner returns a shot.", listOf("J. Sinner", "C. Alcaraz")))         // abbreviated draw names
        assertFalse(ok("Novak Djokovic returns a shot.", listOf("J. Sinner", "C. Alcaraz")))
    }
}
