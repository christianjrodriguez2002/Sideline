package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Art
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.GameState
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.TeamRef

@Composable
fun TeamScreen(league: League, team: TeamRef) {
    val context = LocalContext.current
    val tabs = listOfNotNull(
        "Schedule",
        "Roster",
        if (league.teamBased) "Stats" else null,
        if (league.standings) "Standings" else null,
        if (league.injuries) "Injuries" else null,
        "News"
    )
    var tab by rememberSaveable("team:${league.key}:${team.id}") { mutableIntStateOf(0) }
    val color = teamColor(team.color, Color(league.accent))
    val fav = Favorites.isFavorite(league, team.id)
    Column(Modifier.fillMaxSize()) {
        Hero(color, photo = Art.photoFor(league)) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Logo(team.logo, 72.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            "${league.emoji} ${league.short}".uppercase(),
                            style = Type.Label,
                            color = Color.White.copy(alpha = 0.82f)
                        )
                        Text(
                            team.name,
                            style = Type.Title,
                            color = Color.White,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Loaded(
                    key = "td:${league.key}:${team.id}",
                    load = { force -> Espn.team(league, team.id, force) },
                    skeletonRows = 0
                ) { d, _ ->
                    if (d != null) Row(verticalAlignment = Alignment.CenterVertically) {
                        if (d.record.isNotBlank()) Text(d.record, style = Type.Title, color = Color.White)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            if (d.standingSummary.isNotBlank()) {
                                Text(d.standingSummary, style = Type.BodyStrong, color = Color.White)
                            }
                            val splits = d.recordDetails.drop(1).take(3).joinToString("  ·  ") { (k, v) ->
                                "${k.replace(" Record", "")} $v"
                            }
                            if (splits.isNotBlank()) {
                                Text(splits, style = Type.Small, color = Color.White.copy(alpha = 0.82f), maxLines = 1)
                            }
                        }
                    }
                }
                Box(
                    Modifier
                        .clip(ChipShape)
                        .background(if (fav) Palette.Gold else Color.Black.copy(alpha = 0.35f))
                        .border(1.dp, if (fav) Palette.Gold else Color.White.copy(alpha = 0.25f), ChipShape)
                        .clickable { Favorites.toggle(context, league, team) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                ) {
                    Text(
                        if (fav) "★ Following" else "☆ Follow",
                        style = Type.BodyStrong,
                        color = if (fav) Color(0xFF231700) else Color.White
                    )
                }
            }
        }
        PillTabs(tabs, tab) { tab = it }
        when (tabs.getOrNull(tab)) {
            "Schedule" -> TeamSchedule(league, team)
            "Roster" -> TeamRoster(league, team)
            "Stats" -> TeamStatsTab(league, team)
            "Standings" -> TeamStandings(league, team)
            "Injuries" -> TeamInjuries(league, team)
            "News" -> NewsList(league, team)
            else -> {}
        }
    }
}

@Composable
private fun TeamSchedule(league: League, team: TeamRef) {
    Loaded(
        key = "sch:${league.key}:${team.id}",
        load = { force -> Espn.schedule(league, team.id, force) to Espn.byeWeek(league, team.id, force) },
        pull = true
    ) { (games, espnBye), _ ->
        val upcoming = games.filter { it.state != GameState.POST }
        val byes = com.roki.sideline.data.Byes.weeks(games, espnBye)
        val after = com.roki.sideline.data.Byes.placement(games, byes)
        // Byes still ahead of the team: shown in the Upcoming list in their slot.
        val lastPlayedWeek = games.filter { it.state == GameState.POST }.maxOfOrNull { it.week } ?: 0
        val futureByes = byes.filter { it > lastPlayedWeek }
        val byesAtTop = futureByes.filter { bye -> after[bye]?.let { it.state == GameState.POST } ?: true }
        val results = games.filter { it.state == GameState.POST }.reversed()
        val wins = results.count { it.sideOf(team.id).winner }
        val losses = results.count { it.opponentOf(team.id).winner }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (games.isEmpty()) item { EmptyState(league.emoji, "No schedule posted yet") }
            if (com.roki.sideline.data.SeasonCalendar.upcoming(games).isNotEmpty()) item { CalendarRow(league, team, games) }
            if (results.isNotEmpty()) item {
                val form = results.take(5).joinToString(" ") { g ->
                    if (g.sideOf(team.id).winner) "W" else if (g.opponentOf(team.id).winner) "L" else "D"
                }
                Sub("Recent form: $form · Season results $wins-$losses")
            }
            if (upcoming.isNotEmpty() || byesAtTop.isNotEmpty()) {
                item { SectionHeader("Upcoming") }
                items(byesAtTop) { bye -> ByeCard(bye) }
                items(upcoming) { g ->
                    GameCard(g, showDate = true)
                    futureByes.filter { after[it] === g }.forEach { ByeCard(it, Modifier.padding(top = 10.dp)) }
                }
            }
            if (results.isNotEmpty()) {
                item { SectionHeader("Results") }
                items(results) { g -> GameCard(g, showDate = true) }
            }
        }
    }
}

/** Add the season to the phone's calendar, keep it current, or take it back out. */
@Composable
private fun CalendarRow(league: League, team: TeamRef, games: List<com.roki.sideline.data.Game>) {
    val context = LocalContext.current
    val cal = com.roki.sideline.data.SeasonCalendar
    var added by remember(team.id) { mutableStateOf(cal.isAdded(context, league, team)) }
    var msg by remember(team.id) { mutableStateOf<String?>(null) }
    fun run() {
        msg = runCatching {
            val r = cal.sync(context, league, team, games)
            added = true
            when {
                r.added > 0 && r.updated > 0 -> "Added ${r.added} games and updated ${r.updated}."
                r.added > 0 -> "Added ${r.added} games to your calendar."
                else -> "Updated ${r.updated} games."
            }
        }.getOrElse { it.message ?: "Couldn't write to your calendar." }
    }
    val ask = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { granted -> if (granted.values.all { it }) run() else msg = "Calendar access is needed to add games." }
    // Times move (flex scheduling, TBD games): refresh quietly once a day while the page is open.
    androidx.compose.runtime.LaunchedEffect(team.id, games.size) {
        if (cal.allowed(context) && cal.stale(context, league, team)) runCatching { cal.sync(context, league, team, games) }
    }
    Panel(padding = 12.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📅", style = Type.Heading)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(if (added) "In your calendar" else "Add the season to your calendar", style = Type.BodyStrong, color = Palette.Text)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton(if (added) "Update" else "Add games", { if (cal.allowed(context)) run() else ask.launch(cal.permissions) })
            if (added) PillButton("Remove", {
                val n = runCatching { cal.remove(context, league, team) }.getOrDefault(0)
                added = false
                msg = "Removed $n games from your calendar."
            }, primary = false)
        }
        msg?.let { Sub(it) }
    }
}

@Composable
private fun ByeCard(week: Int, modifier: Modifier = Modifier) {
    Panel(modifier, padding = 14.dp, borderColor = Palette.Gold.copy(alpha = 0.45f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Tag("BYE", Palette.Gold, Color(0xFF231700))
            Spacer(Modifier.width(10.dp))
            Text("Week $week · no game", style = Type.BodyStrong, color = Palette.Text)
        }
    }
}

@Composable
private fun TeamRoster(league: League, team: TeamRef) {
    val nav = LocalNav.current
    Loaded(key = "ros:${league.key}:${team.id}", load = { Espn.roster(league, team.id) }, pull = true) { players, _ ->
        val groups = players.groupBy { it.group.ifBlank { "Roster" } }.toList()
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (players.isEmpty()) item { EmptyState("👥", "No roster posted") }
            groups.forEach { (g, list) ->
                item { SectionHeader("$g · ${list.size}") }
                items(list) { p ->
                    Panel(onClick = { nav.player(league, p.copy(teamId = team.id, teamName = team.name)) }, padding = 12.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Headshot(p.headshot, 46.dp, name = p.name)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Sub(
                                    listOf(
                                        p.position,
                                        if (p.age.isNotBlank()) "Age ${p.age}" else "",
                                        p.height,
                                        p.weight,
                                        p.experience
                                    ).filter { it.isNotBlank() }.joinToString(" · "),
                                    maxLines = 1
                                )
                            }
                            if (p.injuryStatus.isNotBlank()) {
                                val (bg, fg) = statusColors(p.injuryStatus)
                                Tag(p.injuryStatus, bg, fg)
                                Spacer(Modifier.width(8.dp))
                            }
                            if (p.jersey.isNotBlank()) Text("#${p.jersey}", style = Type.Heading, color = Palette.Faint)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamStandings(league: League, team: TeamRef) {
    Loaded(key = "st:${league.key}", load = { force -> Espn.standings(league, force) }, pull = true) { tables, _ ->
        val mine = tables.filter { t -> t.rows.any { it.team.id == team.id } }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (mine.isEmpty()) item { EmptyState(league.emoji, "Standings aren't posted yet") }
            items(mine) { t -> StandingCard(league, t, highlight = team.id) }
        }
    }
}

@Composable
private fun TeamInjuries(league: League, team: TeamRef) {
    Loaded(key = "inj:${league.key}", load = { force -> Espn.injuries(league, force) }, pull = true) { all, _ ->
        val list = all.filter { it.teamId == team.id || (it.teamId.isBlank() && it.teamName == team.name) }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (list.isEmpty()) item { EmptyState("💪", "Nobody on the injury report") }
            items(list) { inj -> InjuryRow(league, inj, showTeam = false) }
        }
    }
}

@Composable
fun PlayerScreen(league: League, p: Player) {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Hero(Color(league.accent), photo = Art.photoFor(league)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Headshot(p.headshot, 96.dp, ring = Color.White.copy(alpha = 0.6f), name = p.name)
                    Spacer(Modifier.width(16.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(p.name, style = Type.Title, color = Color.White)
                        Text(
                            listOf(
                                if (p.jersey.isNotBlank()) "#${p.jersey}" else "",
                                p.positionName.ifBlank { p.position },
                                p.teamName
                            ).filter { it.isNotBlank() }.joinToString(" · "),
                            style = Type.Body,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                        if (p.injuryStatus.isNotBlank()) {
                            val (bg, fg) = statusColors(p.injuryStatus)
                            Tag(p.injuryStatus, bg, fg)
                        }
                        val context = LocalContext.current
                        val followed = com.roki.sideline.data.Players.isFollowed(league, p.id)
                        Box(
                            Modifier
                                .padding(top = 4.dp)
                                .clip(ChipShape)
                                .background(if (followed) Palette.Gold else Color.Black.copy(alpha = 0.35f))
                                .border(1.dp, if (followed) Palette.Gold else Color.White.copy(alpha = 0.25f), ChipShape)
                                .clickable { com.roki.sideline.data.Players.toggle(context, league, p) }
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                        ) {
                            Text(if (followed) "★ Following" else "☆ Follow", style = Type.BodyStrong, color = if (followed) Color(0xFF231700) else Color.White)
                        }
                    }
                }
            }
        }
        val bio = listOf(
            "Age" to p.age,
            "Height" to p.height,
            "Weight" to p.weight,
            "Born" to p.birthPlace,
            "College" to p.college,
            "Experience" to p.experience,
            "Status" to p.status
        ).filter { it.second.isNotBlank() }
        if (bio.isNotEmpty()) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Bio")
                bio.forEach { (k, v) -> InfoRow(k, v) }
            }
        }
        if (league.playerStats) item { ComparePicker(league, p) }
        item {
            Box(Modifier.padding(horizontal = 16.dp)) {
                Loaded(
                    key = "ath:${league.key}:${p.id}",
                    load = {
                        val o = runCatching { Espn.athlete(league, p.id) }.getOrNull()
                        val inj = runCatching { Espn.injuries(league).firstOrNull { it.athleteId == p.id } }.getOrNull()
                        o to inj
                    },
                    skeletonRows = 2
                ) { (o, inj), _ ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (inj != null) InjuryRow(league, inj, showTeam = false)
                        if (o == null) Sub("Detailed stats aren't available for this player.")
                        else {
                            if (o.injuryNote.isNotBlank()) {
                                Panel {
                                    SectionHeader("Latest")
                                    Text(o.injuryNote, style = Type.Body, color = Palette.Text)
                                }
                            }
                            if (o.rows.isNotEmpty() && o.labels.isNotEmpty()) {
                                Panel {
                                    SectionHeader("Stats")
                                    DataTable(o.labels, o.rows.map { it.label to it.values }, firstWidth = 120.dp)
                                }
                            }
                            if (o.nextGame.isNotBlank()) {
                                Panel {
                                    SectionHeader("Next game")
                                    Text(o.nextGame, style = Type.Body, color = Palette.Text)
                                }
                            }
                            if (o.news.isNotEmpty()) {
                                SectionHeader("News")
                                o.news.take(8).forEach { ArticleRow(it) }
                            }
                        }
                    }
                }
            }
        }
    }
}
