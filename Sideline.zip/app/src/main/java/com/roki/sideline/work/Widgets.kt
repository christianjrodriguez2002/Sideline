package com.roki.sideline.work

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import com.roki.sideline.MainActivity
import com.roki.sideline.R
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate

/** Shared plumbing for the extra widgets: run off the main thread, open the app on tap. */
abstract class BaseWidget : AppWidgetProvider() {
    abstract suspend fun build(context: Context): RemoteViews

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val rv = runCatching { build(context) }.getOrNull()
                if (rv != null) ids.forEach { manager.updateAppWidget(it, rv) }
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        fun open(context: Context): PendingIntent = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        /** Refresh every placed Sideline widget. The app calls this when Home loads. */
        suspend fun updateAll(context: Context) {
            SidelineWidget.update(context)
            val manager = AppWidgetManager.getInstance(context)
            listOf(SmallTeamWidget(), LeagueDayWidget(), StandingsWidget()).forEach { w ->
                val ids = manager.getAppWidgetIds(ComponentName(context, w.javaClass))
                if (ids.isNotEmpty()) runCatching { w.build(context) }.getOrNull()?.let { rv -> ids.forEach { manager.updateAppWidget(it, rv) } }
            }
        }
    }
}

/** 2x1: your first followed team, big logos and the score or matchup. */
class SmallTeamWidget : BaseWidget() {
    override suspend fun build(context: Context): RemoteViews {
        Favorites.load(context)
        val rv = RemoteViews(context.packageName, R.layout.widget_small)
        rv.setOnClickPendingIntent(R.id.sm_root, open(context))
        val f = Favorites.list.firstOrNull()
        if (f == null) {
            rv.setTextViewText(R.id.sm_mid, "Sideline")
            rv.setTextViewText(R.id.sm_status, "Follow a team to fill this")
            return rv
        }
        val r = SidelineWidget.row(f) ?: return rv
        SidelineWidget.setLogo(rv, R.id.sm_logo_a, SidelineWidget.logo(r.logoA))
        SidelineWidget.setLogo(rv, R.id.sm_logo_b, if (r.logoB.isBlank()) null else SidelineWidget.logo(r.logoB))
        rv.setTextViewText(R.id.sm_mid, r.mid.ifBlank { r.a })
        rv.setTextViewText(R.id.sm_status, r.status)
        rv.setTextColor(R.id.sm_status, if (r.live) 0xFFFF3B30.toInt() else 0xFF9BA8BC.toInt())
        return rv
    }
}

/** 4x3: today's games in your first pinned team-sport league. */
class LeagueDayWidget : BaseWidget() {
    private val rows = listOf(
        intArrayOf(R.id.lg1, R.id.lg1_logo_a, R.id.lg1_a, R.id.lg1_mid, R.id.lg1_b, R.id.lg1_logo_b, R.id.lg1_status),
        intArrayOf(R.id.lg2, R.id.lg2_logo_a, R.id.lg2_a, R.id.lg2_mid, R.id.lg2_b, R.id.lg2_logo_b, R.id.lg2_status),
        intArrayOf(R.id.lg3, R.id.lg3_logo_a, R.id.lg3_a, R.id.lg3_mid, R.id.lg3_b, R.id.lg3_logo_b, R.id.lg3_status),
        intArrayOf(R.id.lg4, R.id.lg4_logo_a, R.id.lg4_a, R.id.lg4_mid, R.id.lg4_b, R.id.lg4_logo_b, R.id.lg4_status),
        intArrayOf(R.id.lg5, R.id.lg5_logo_a, R.id.lg5_a, R.id.lg5_mid, R.id.lg5_b, R.id.lg5_logo_b, R.id.lg5_status),
        intArrayOf(R.id.lg6, R.id.lg6_logo_a, R.id.lg6_a, R.id.lg6_mid, R.id.lg6_b, R.id.lg6_logo_b, R.id.lg6_status),
    )

    override suspend fun build(context: Context): RemoteViews {
        Settings.load(context)
        val rv = RemoteViews(context.packageName, R.layout.widget_league)
        rv.setOnClickPendingIntent(R.id.lg_root, open(context))
        rv.setTextViewText(R.id.lg_updated, Fmt.time(Instant.now()))
        val league = Settings.pinnedLeagues().firstOrNull { it.teamBased }
        val today = LocalDate.now(Fmt.zone())
        val games = if (league == null) emptyList() else runCatching {
            if (league.weekly) Espn.week(league, null).games.filter { it.start?.atZone(Fmt.zone())?.toLocalDate() == today }
            else Espn.day(league, today)
        }.getOrDefault(emptyList()).sortedWith(compareBy({ when (it.state) { GameState.IN -> 0; GameState.PRE -> 1; GameState.POST -> 2 } }, { it.start }))
        rv.setTextViewText(R.id.lg_title, ((league?.short ?: "SIDELINE") + " TODAY").uppercase())
        rv.setViewVisibility(R.id.lg_empty, if (games.isEmpty()) View.VISIBLE else View.GONE)
        rv.setTextViewText(R.id.lg_empty, if (league == null) "Pin a league in Sideline to fill this" else "No ${league.short} games today")
        val favIds = Favorites.list.map { it.team.id }.toSet()
        rows.forEachIndexed { i, ids ->
            val g = games.getOrNull(i)
            rv.setViewVisibility(ids[0], if (g == null) View.GONE else View.VISIBLE)
            if (g == null) return@forEachIndexed
            val r = SidelineWidget.gameRow(g, favIds.firstOrNull { g.involves(it) })
            SidelineWidget.setLogo(rv, ids[1], SidelineWidget.logo(r.logoA))
            rv.setTextViewText(ids[2], r.a)
            rv.setTextViewText(ids[3], r.mid)
            rv.setTextViewText(ids[4], r.b)
            SidelineWidget.setLogo(rv, ids[5], SidelineWidget.logo(r.logoB))
            rv.setTextViewText(ids[6], r.status)
            rv.setTextColor(ids[6], if (r.live) 0xFFFF3B30.toInt() else 0xFF9BA8BC.toInt())
        }
        return rv
    }
}

/** 4x3: the division or table your first followed team is in, top 8. */
class StandingsWidget : BaseWidget() {
    private val rows = listOf(
        intArrayOf(R.id.st1, R.id.st1_rank, R.id.st1_logo, R.id.st1_name, R.id.st1_value),
        intArrayOf(R.id.st2, R.id.st2_rank, R.id.st2_logo, R.id.st2_name, R.id.st2_value),
        intArrayOf(R.id.st3, R.id.st3_rank, R.id.st3_logo, R.id.st3_name, R.id.st3_value),
        intArrayOf(R.id.st4, R.id.st4_rank, R.id.st4_logo, R.id.st4_name, R.id.st4_value),
        intArrayOf(R.id.st5, R.id.st5_rank, R.id.st5_logo, R.id.st5_name, R.id.st5_value),
        intArrayOf(R.id.st6, R.id.st6_rank, R.id.st6_logo, R.id.st6_name, R.id.st6_value),
        intArrayOf(R.id.st7, R.id.st7_rank, R.id.st7_logo, R.id.st7_name, R.id.st7_value),
        intArrayOf(R.id.st8, R.id.st8_rank, R.id.st8_logo, R.id.st8_name, R.id.st8_value),
    )

    override suspend fun build(context: Context): RemoteViews {
        Favorites.load(context)
        val rv = RemoteViews(context.packageName, R.layout.widget_standings)
        rv.setOnClickPendingIntent(R.id.sd_root, open(context))
        rv.setTextViewText(R.id.sd_updated, Fmt.time(Instant.now()))
        val f = Favorites.list.firstOrNull { it.league.standings && it.league.teamBased }
        val table = f?.let { fav -> runCatching { Espn.standings(fav.league) }.getOrDefault(emptyList()).firstOrNull { t -> t.rows.any { it.team.id == fav.team.id } } }
        rv.setTextViewText(R.id.sd_title, (table?.title ?: "STANDINGS").uppercase())
        rv.setViewVisibility(R.id.sd_empty, if (table == null) View.VISIBLE else View.GONE)
        rv.setTextViewText(R.id.sd_empty, if (f == null) "Follow a team to fill this" else "Standings aren't posted yet")
        val valueCol = table?.columns?.firstOrNull { it.second in listOf("PTS", "PCT", "W") }?.first
        val wCol = table?.columns?.firstOrNull { it.second == "W" }?.first
        val lCol = table?.columns?.firstOrNull { it.second == "L" }?.first
        rows.forEachIndexed { i, ids ->
            val r = table?.rows?.getOrNull(i)
            rv.setViewVisibility(ids[0], if (r == null) View.GONE else View.VISIBLE)
            if (r == null) return@forEachIndexed
            rv.setTextViewText(ids[1], "${i + 1}")
            SidelineWidget.setLogo(rv, ids[2], SidelineWidget.logo(r.team.logo))
            rv.setTextViewText(ids[3], r.team.shortName.ifBlank { r.team.name })
            rv.setTextColor(ids[3], if (r.team.id == f?.team?.id) 0xFFF5B83D.toInt() else 0xFFF4F7FB.toInt())
            val wl = if (wCol != null && lCol != null) "${r.stats[wCol]}-${r.stats[lCol]}" else ""
            val v = when {
                table.columns.any { it.second == "PTS" } -> "${r.stats[valueCol]} pts"
                wl.isNotBlank() -> wl
                else -> r.stats[valueCol].orEmpty()
            }
            rv.setTextViewText(ids[4], v)
        }
        return rv
    }
}
