package com.roki.sideline.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.TimeZone

data class Favorite(val league: League, val team: TeamRef) {
    val key get() = "${league.key}:${team.id}"
}

private fun prefsOf(context: Context) = context.applicationContext.getSharedPreferences("sideline", Context.MODE_PRIVATE)

object Favorites {
    val list = mutableStateListOf<Favorite>()
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val raw = prefsOf(context).getString("favorites", null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val league = Leagues.of(o.getString("league")) ?: continue
                list.add(Favorite(league, TeamRef(o.getString("id"), o.optString("abbr"), o.optString("name"),
                    o.optString("short"), o.optString("logo"), o.optString("color"))))
            }
        }
    }

    fun isFavorite(league: League, teamId: String) = list.any { it.league.key == league.key && it.team.id == teamId }

    fun toggle(context: Context, league: League, team: TeamRef) {
        val i = list.indexOfFirst { it.league.key == league.key && it.team.id == team.id }
        if (i >= 0) list.removeAt(i) else list.add(Favorite(league, team))
        save(context)
    }

    fun move(context: Context, from: Int, to: Int) {
        if (from !in list.indices || to !in list.indices) return
        val f = list.removeAt(from)
        list.add(to, f)
        save(context)
    }

    private fun save(context: Context) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().put("league", f.league.key).put("id", f.team.id).put("abbr", f.team.abbr)
                .put("name", f.team.name).put("short", f.team.shortName).put("logo", f.team.logo).put("color", f.team.color))
        }
        prefsOf(context).edit().putString("favorites", arr.toString()).apply()
    }

    fun prefs(context: Context) = prefsOf(context)
}

object Settings {
    val pins = mutableStateListOf<String>()
    val name = mutableStateOf("")
    val use24h = mutableStateOf<Boolean?>(null)
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val p = prefsOf(context)
        val saved = p.getString("pins", null)?.split(",")?.filter { Leagues.of(it) != null }
        pins.addAll(saved ?: Leagues.defaultPins)
        name.value = p.getString("name", "") ?: ""
        use24h.value = if (p.contains("use24h")) p.getBoolean("use24h", false) else null
        Fmt.systemIs24h = android.text.format.DateFormat.is24HourFormat(context)
    }

    fun togglePin(context: Context, key: String) {
        if (key in pins) pins.remove(key) else pins.add(key)
        prefsOf(context).edit().putString("pins", pins.joinToString(",")).apply()
    }

    fun movePin(context: Context, from: Int, to: Int) {
        if (from !in pins.indices || to !in pins.indices) return
        val k = pins.removeAt(from)
        pins.add(to, k)
        prefsOf(context).edit().putString("pins", pins.joinToString(",")).apply()
    }

    fun setName(context: Context, v: String) {
        name.value = v
        prefsOf(context).edit().putString("name", v).apply()
    }

    fun setClock(context: Context, v: Boolean?) {
        use24h.value = v
        val e = prefsOf(context).edit()
        if (v == null) e.remove("use24h") else e.putBoolean("use24h", v)
        e.apply()
    }

    fun pinnedLeagues(): List<League> = pins.mapNotNull { Leagues.of(it) }
}

object Streaming {
    private val map = listOf(
        listOf("ESPN", "ESPN2", "ESPNU", "ESPNEWS", "ABC", "ESPN+", "ESPN Deportes", "ESPN Unlimited", "SEC Network", "SECN", "ACC Network", "ACCN", "Longhorn Network") to "ESPN app",
        listOf("TNT", "TBS", "truTV", "TNT Sports", "Max", "HBO Max") to "HBO Max",
        listOf("FOX", "FS1", "FS2", "FOX Deportes", "Big Ten Network", "BTN", "Fox One") to "Fox One",
        listOf("CBS", "Paramount+", "CBS Sports Golazo") to "Paramount+",
        listOf("NBC", "NBCSN", "Peacock", "Telemundo", "Universo", "Golf Channel") to "Peacock",
        listOf("Prime Video", "Amazon Prime Video", "Prime") to "Prime Video",
        listOf("Apple TV", "Apple TV+", "AppleTV+", "MLS Season Pass") to "Apple TV",
        listOf("Netflix") to "Netflix",
        listOf("YouTube", "YouTube TV") to "YouTube",
        listOf("NFL Net", "NFL Network", "NFL+") to "NFL+",
        listOf("NBA TV") to "NBA app",
        listOf("MLB Network", "MLBN", "MLB.TV") to "MLB.TV",
        listOf("NHL Network", "NHLN") to "NHL Network app",
        listOf("Tennis Channel", "T2") to "Tennis Channel app",
        listOf("beIN SPORTS", "beIN Sports", "beIN SPORTS XTRA") to "beIN SPORTS / Fubo",
        listOf("TUDN", "Univision", "UniMás", "UniMas") to "ViX",
        listOf("DAZN") to "DAZN",
        listOf("Roku", "The Roku Channel") to "The Roku Channel",
    )

    fun appFor(network: String): String? {
        val n = network.trim()
        return map.firstOrNull { (names, _) -> names.any { it.equals(n, true) } }?.second
            ?: map.firstOrNull { (names, _) -> names.any { n.startsWith(it, true) && it.length >= 3 } }?.second
    }

    fun describe(league: League, broadcasts: List<Broadcast>): List<String> {
        if (broadcasts.isEmpty()) return emptyList()
        val lines = ArrayList<String>()
        val apps = LinkedHashSet<String>()
        var local = false
        broadcasts.forEach { b ->
            val app = appFor(b.network)
            if (app != null) apps.add(app) else if (!b.national) local = true
        }
        if (apps.isNotEmpty()) lines.add("Usually streams on " + apps.joinToString(", "))
        if (local) lines.add("Local channel: your regional sports network's app in-market" +
            (league.outOfMarket?.let { "; $it out of market" } ?: ""))
        return lines
    }
}

object Predict {
    fun winPct(record: String): Double? {
        val parts = record.split("-").mapNotNull { it.trim().toIntOrNull() }
        if (parts.size < 2) return null
        val w = parts[0].toDouble()
        val l = parts.drop(1).sum().toDouble()
        if (w + l < 3) return null
        return (w + 2) / (w + l + 4)
    }

    fun homeWinProb(league: League, homeRecord: String, awayRecord: String): Double? {
        if (league.homeEdge <= 0.0 || league.draws) return null
        val h = winPct(homeRecord) ?: return null
        val a = winPct(awayRecord) ?: return null
        val p = (h - h * a) / (h + a - 2 * h * a)
        return (p + league.homeEdge).coerceIn(0.03, 0.97)
    }

    fun pctText(p: Double) = String.format(Locale.US, "%.0f%%", p)
}

object Fmt {
    @Volatile var systemIs24h: Boolean = false
    private val is24 get() = Settings.use24h.value ?: systemIs24h

    private fun pattern(p12: String, p24: String) = DateTimeFormatter.ofPattern(if (is24) p24 else p12, Locale.getDefault())

    fun zone(): ZoneId = ZoneId.systemDefault()

    fun zoneShort(): String {
        val tz = TimeZone.getDefault()
        return tz.getDisplayName(tz.inDaylightTime(java.util.Date()), TimeZone.SHORT, Locale.getDefault())
    }

    fun zoneLong(): String {
        val tz = TimeZone.getDefault()
        return tz.getDisplayName(tz.inDaylightTime(java.util.Date()), TimeZone.LONG, Locale.getDefault())
    }

    fun zoneParenthetical(): String {
        val longName = zoneLong()
        val shortName = zoneShort()
        return if (longName.equals(shortName, ignoreCase = true)) shortName else "$longName · $shortName"
    }

    fun time(i: Instant?): String {
        i ?: return "TBD"
        val s = pattern("h:mm a", "HH:mm").format(i.atZone(zone()))
        return if (is24) s else s.replace(":00 ", " ").lowercase(Locale.getDefault())
    }

    fun timeIn(i: Instant?, zone: ZoneId): String {
        i ?: return "TBD"
        val z = i.atZone(zone)
        val t = pattern("h:mm a", "HH:mm").format(z).let { if (is24) it else it.replace(":00 ", " ").lowercase(Locale.getDefault()) }
        val abbr = java.util.TimeZone.getTimeZone(zone).getDisplayName(zone.rules.isDaylightSavings(i), TimeZone.SHORT, Locale.getDefault())
        return "$t $abbr"
    }

    fun day(i: Instant?): String = i?.let { DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault()).format(it.atZone(zone())) } ?: ""
    fun dayShort(i: Instant?): String = i?.let { DateTimeFormatter.ofPattern("MMM d", Locale.getDefault()).format(it.atZone(zone())) } ?: ""
    fun dayTime(i: Instant?): String = if (i == null) "TBD" else "${day(i)} · ${time(i)}"

    fun ago(i: Instant?): String {
        if (i == null) return ""
        val m = ChronoUnit.MINUTES.between(i, Instant.now())
        return when {
            m < 1 -> "just now"
            m < 60 -> "${m}m ago"
            m < 24 * 60 -> "${m / 60}h ago"
            m < 7 * 24 * 60 -> "${m / (24 * 60)}d ago"
            else -> day(i)
        }
    }

    fun whenText(i: Instant?): String {
        if (i == null) return "TBD"
        val d = i.atZone(zone()).toLocalDate()
        val today = LocalDate.now(zone())
        return when (d) {
            today -> "Today ${time(i)}"
            today.plusDays(1) -> "Tomorrow ${time(i)}"
            today.minusDays(1) -> "Yesterday ${time(i)}"
            else -> dayTime(i)
        }
    }

    fun dateRange(a: Instant?, b: Instant?): String {
        if (a == null) return ""
        if (b == null || a.atZone(zone()).toLocalDate() == b.atZone(zone()).toLocalDate()) return day(a)
        return "${dayShort(a)} – ${dayShort(b)}"
    }

    fun greeting(): String {
        val h = java.time.LocalTime.now(zone()).hour
        return when (h) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            else -> "Good evening"
        }
    }
}
