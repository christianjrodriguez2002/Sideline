@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.roki.sideline.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val CardShape = RoundedCornerShape(20.dp)
val ChipShape = RoundedCornerShape(50)

sealed class Load<out T> {
    object Loading : Load<Nothing>()
    data class Ok<T>(val value: T) : Load<T>()
    data class Err(val message: String) : Load<Nothing>()
}

/**
 * Loads [load] for [key], showing a skeleton, then the content or a retry card. With [pull], the content sits in a
 * pull-to-refresh box, so dragging down any list reloads it.
 */
@Composable
fun <T> Loaded(
    key: Any?,
    load: suspend (force: Boolean) -> T,
    modifier: Modifier = Modifier,
    skeletonRows: Int = 3,
    pull: Boolean = false,
    cached: (() -> T?)? = null,
    content: @Composable (value: T, refresh: () -> Unit) -> Unit,
) {
    // A value already in memory shows at once: no skeleton, no jump, when a card scrolls back into view.
    var state by remember(key) { mutableStateOf<Load<T>>(cached?.invoke()?.let { Load.Ok(it) } ?: Load.Loading) }
    var tick by remember(key) { mutableIntStateOf(0) }
    var refreshing by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key, tick) {
        if (state !is Load.Ok) state = Load.Loading else if (tick > 0) refreshing = true
        state = try {
            // Downloading and parsing both happen off the main thread, so scrolling never waits on them.
            Load.Ok(withContext(Dispatchers.Default) { load(tick > 0) })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val old = state
            if (old is Load.Ok && tick > 0) old else Load.Err(friendly(e))
        }
        refreshing = false
    }
    when (val s = state) {
        is Load.Loading -> Skeleton(skeletonRows, modifier)
        is Load.Err -> ErrorCard(s.message, modifier) { tick++ }
        is Load.Ok -> if (pull) {
            PullToRefreshBox(isRefreshing = refreshing, onRefresh = { tick++ }, modifier = modifier.fillMaxSize()) {
                content(s.value) { tick++ }
            }
        } else content(s.value) { tick++ }
    }
}

fun friendly(e: Exception): String = when (e) {
    is java.net.UnknownHostException -> "You're offline. Check your connection."
    is java.net.SocketTimeoutException -> "ESPN is taking too long to answer."
    else -> e.message ?: "Something went wrong."
}

@Composable
fun pulse(min: Float = 0.35f, max: Float = 1f, millis: Int = 900): Float {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(
        initialValue = min, targetValue = max,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = millis), repeatMode = RepeatMode.Reverse),
        label = "pulseAlpha",
    )
    return a
}

@Composable
fun Skeleton(rows: Int = 3, modifier: Modifier = Modifier) {
    val a = pulse(0.25f, 0.55f, 800)
    Column(modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        repeat(rows) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(94.dp)
                    .alpha(a)
                    .clip(CardShape)
                    .background(Brush.verticalGradient(listOf(Palette.Raised, Palette.Surface)))
                    .border(1.dp, Palette.Line, CardShape)
            )
        }
    }
}

@Composable
fun ErrorCard(message: String, modifier: Modifier = Modifier, onRetry: () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(CardShape)
            .background(Palette.Surface)
            .border(1.dp, Palette.Line, CardShape)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(message, style = Type.Body, color = Palette.Sub, textAlign = TextAlign.Center)
        PillButton("Try again", onRetry)
    }
}

@Composable
fun EmptyState(emoji: String, title: String, sub: String = "") {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(emoji, style = Type.Display)
        Text(title, style = Type.Heading, color = Palette.Text, textAlign = TextAlign.Center)
        if (sub.isNotBlank()) Text(sub, style = Type.Small, color = Palette.Sub, textAlign = TextAlign.Center)
    }
}

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: Dp = Space.card,
    borderColor: Color = Palette.Line,
    content: @Composable () -> Unit,
) {
    val surfaceBrush = Brush.verticalGradient(
        listOf(Palette.Raised.copy(alpha = 0.45f), Palette.Surface)
    )
    val base = modifier
        .fillMaxWidth()
        .clip(CardShape)
        .background(surfaceBrush)
        .border(1.dp, borderColor, CardShape)
    Column(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(padding),
        verticalArrangement = Arrangement.spacedBy(Space.gap),
    ) { content() }
}

@Composable
fun Hero(
    color: Color,
    modifier: Modifier = Modifier,
    second: Color? = null,
    photo: com.roki.sideline.data.Photo? = null,
    content: @Composable () -> Unit,
) {
    val brush = Brush.verticalGradient(
        listOf(
            color.copy(alpha = if (photo != null) 0.82f else 0.95f),
            (second ?: color).copy(alpha = if (photo != null) 0.62f else 0.55f),
            Palette.Bg
        )
    )
    Box(modifier.fillMaxWidth().background(Palette.Bg)) {
        if (photo != null) {
            AsyncImage(
                model = photo.url,
                contentDescription = photo.subject,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize().alpha(0.32f)
            )
        }
        Box(Modifier.fillMaxWidth().background(brush)) { content() }
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = 8.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(3.dp)
                .height(12.dp)
                .clip(CircleShape)
                .background(Palette.Blue)
        )
        Spacer(Modifier.width(8.dp))
        Text(title.uppercase(), Modifier.weight(1f), style = Type.Label, color = Palette.Sub)
        if (action != null && onAction != null) {
            Text(
                action,
                Modifier.clickable(onClick = onAction).padding(4.dp),
                style = Type.Small,
                color = Palette.Blue,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun PillButton(text: String, onClick: () -> Unit, primary: Boolean = true) {
    Box(
        Modifier
            .clip(ChipShape)
            .background(if (primary) Palette.Blue else Palette.Raised)
            .border(1.dp, if (primary) Color.White.copy(alpha = 0.15f) else Palette.Line, ChipShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 9.dp),
    ) {
        Text(text, style = Type.BodyStrong, color = Color.White)
    }
}

@Composable
fun PillTabs(tabs: List<String>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        tabs.forEachIndexed { i, t ->
            val on = i == selected
            Box(
                Modifier
                    .clip(ChipShape)
                    .background(if (on) Palette.Blue else Palette.Raised)
                    .border(1.dp, if (on) Color.White.copy(alpha = 0.2f) else Palette.Line, ChipShape)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            ) {
                Text(t, style = Type.BodyStrong, color = if (on) Color.White else Palette.Sub, maxLines = 1)
            }
        }
    }
}

@Composable
fun Tag(text: String, bg: Color = Palette.Raised2, fg: Color = Palette.Text) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(text, style = Type.Small, color = fg, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun LiveBadge(text: String = "LIVE") {
    val a = pulse()
    Row(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Palette.Live.copy(alpha = 0.18f))
            .border(0.5.dp, Palette.Live.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(7.dp).alpha(a).clip(CircleShape).background(Palette.Live))
        Spacer(Modifier.width(5.dp))
        Text(text, style = Type.Label, color = Palette.Live, maxLines = 1)
    }
}

@Composable
fun Logo(url: String, size: Dp = 28.dp, modifier: Modifier = Modifier) {
    if (url.isBlank()) {
        Box(modifier.size(size).clip(CircleShape).background(Palette.Raised2))
    } else {
        AsyncImage(model = url, contentDescription = null, modifier = modifier.size(size))
    }
}

@Composable
fun Headshot(url: String, size: Dp = 40.dp, ring: Color = Palette.Line, name: String = "") {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Palette.Raised2)
            .border(1.5.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        val initials = name.split(" ", "-").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }
        if (initials.isNotBlank()) {
            Text(initials, style = if (size > 60.dp) Type.Title else Type.BodyStrong, color = Palette.Sub)
        }
        if (url.isNotBlank()) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(size)
            )
        }
    }
}

@Composable
fun Flag(url: String, size: Dp = 18.dp) {
    if (url.isNotBlank()) {
        AsyncImage(
            model = url,
            contentDescription = null,
            modifier = Modifier.size(width = size * 1.4f, height = size).clip(RoundedCornerShape(2.dp))
        )
    }
}

@Composable
fun PhotoHero(
    photo: com.roki.sideline.data.Photo,
    tint: Color,
    height: Dp = 210.dp,
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.BoxScope.() -> Unit,
) {
    Box(modifier.fillMaxWidth().height(height).background(tint.copy(alpha = 0.6f))) {
        AsyncImage(
            model = photo.url,
            contentDescription = photo.subject,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(height)
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(height)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.Black.copy(alpha = 0.22f),
                            tint.copy(alpha = 0.42f),
                            Palette.Bg
                        )
                    )
                )
        )
        Box(Modifier.fillMaxWidth().height(height)) { content() }
    }
}

@Composable
fun LeagueMark(league: com.roki.sideline.data.League, size: Dp = 40.dp) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val logo = com.roki.sideline.data.Art.logos[league.key]
    LaunchedEffect(league.key) { com.roki.sideline.data.Art.logo(context, league) }
    val c = Color(league.accent)
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3.2f))
            .background(Brush.verticalGradient(listOf(c.copy(alpha = 0.92f), Palette.Raised2)))
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(size / 3.2f)),
        contentAlignment = Alignment.Center,
    ) {
        var failed by remember(logo) { mutableStateOf(false) }
        if (logo == null || failed) {
            Text(league.emoji, style = if (size > 44.dp) Type.Title else Type.Heading)
        }
        if (logo != null) {
            AsyncImage(
                model = logo,
                contentDescription = league.label,
                modifier = Modifier.size(size * 0.72f),
                onError = { failed = true },
            )
        }
    }
}

@Composable
fun LeagueBadge(emoji: String, accent: Long, size: Dp = 40.dp) {
    val c = Color(accent)
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3.2f))
            .background(Brush.verticalGradient(listOf(c, c.copy(alpha = 0.55f))))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(size / 3.2f)),
        contentAlignment = Alignment.Center,
    ) {
        Text(emoji, style = if (size > 44.dp) Type.Title else Type.Heading)
    }
}

@Composable
fun SplitBar(leftPct: Double, leftColor: Color, rightColor: Color, middlePct: Double = 0.0) {
    val l = (leftPct / 100.0).coerceIn(0.0, 1.0).toFloat()
    val m = (middlePct / 100.0).coerceIn(0.0, 1.0).toFloat()
    val r = (1f - l - m).coerceAtLeast(0f)
    Row(
        Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        if (l > 0f) Box(Modifier.weight(l).height(9.dp).clip(CircleShape).background(leftColor))
        if (m > 0f) Box(Modifier.weight(m).height(9.dp).clip(CircleShape).background(Palette.Faint))
        if (r > 0f) Box(Modifier.weight(r).height(9.dp).clip(CircleShape).background(rightColor))
    }
}

fun teamColor(hex: String, fallback: Color): Color {
    val h = hex.trim().removePrefix("#")
    if (h.length != 6) return fallback
    val c = runCatching { Color(0xFF000000 or h.toLong(16)) }.getOrDefault(fallback)
    val lum = 0.2126f * c.red + 0.7152f * c.green + 0.0722f * c.blue
    return if (lum < 0.06f) Palette.Raised2 else c
}

fun statusColors(status: String): Pair<Color, Color> {
    val s = status.lowercase()
    return when {
        s.contains("out") || s.contains("injured reserve") || s == "ir" || s.contains("suspen") -> Palette.Live to Color.White
        s.contains("doubt") -> Color(0xFFF97316) to Color.White
        s.contains("question") || s.contains("day-to-day") || s.contains("day to day") -> Palette.Gold to Color(0xFF231700)
        else -> Palette.BlueSoft to Color(0xFFDCE8FF)
    }
}

@Composable
fun DataTable(
    labels: List<String>,
    rows: List<Pair<String, List<String>>>,
    firstWidth: Dp = 128.dp,
    highlight: (Int) -> Boolean = { false },
    onRow: ((Int) -> Unit)? = null,
) {
    Row {
        Column(Modifier.width(firstWidth)) {
            Text(" ", style = Type.Label, modifier = Modifier.height(24.dp))
            rows.forEachIndexed { i, (name, _) ->
                val base = Modifier.height(32.dp)
                Box(if (onRow != null) base.clickable { onRow(i) } else base, contentAlignment = Alignment.CenterStart) {
                    Text(
                        name,
                        style = if (highlight(i)) Type.BodyStrong else Type.Body,
                        color = if (highlight(i)) Palette.Gold else Palette.Text,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            labels.forEachIndexed { c, label ->
                val wide = label.length > 4 || rows.any { (it.second.getOrNull(c) ?: "").length > 4 }
                Column(Modifier.width(if (wide) 60.dp else 42.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.height(24.dp), contentAlignment = Alignment.Center) {
                        Text(label, style = Type.Label, color = Palette.Faint, maxLines = 1)
                    }
                    rows.forEachIndexed { i, (_, values) ->
                        Box(Modifier.height(32.dp), contentAlignment = Alignment.Center) {
                            Text(
                                values.getOrNull(c) ?: "",
                                style = Type.Num,
                                color = if (highlight(i)) Palette.Gold else Palette.Text,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Hand a game to the phone's calendar app as a new event, three hours long, with the venue as the place. */
fun addToCalendar(context: Context, g: com.roki.sideline.data.Game) {
    val start = g.start ?: return
    val i = Intent(Intent.ACTION_INSERT)
        .setData(android.provider.CalendarContract.Events.CONTENT_URI)
        .putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.toEpochMilli())
        .putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, start.toEpochMilli() + 3 * 3600_000L)
        .putExtra(android.provider.CalendarContract.Events.TITLE, "${g.league.short}: ${g.away.team.shortName} at ${g.home.team.shortName}")
        .putExtra(android.provider.CalendarContract.Events.EVENT_LOCATION, g.venue)
        .putExtra(android.provider.CalendarContract.Events.DESCRIPTION, g.broadcasts.joinToString(", ") { it.network }.let { if (it.isBlank()) "" else "TV: $it" })
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No calendar app found.", Toast.LENGTH_SHORT).show()
    }
}

/** How many cards fit side by side: phones get one (or two for tiles), tablets more. */
@Composable
fun columns(tileWidth: Int = 360): Int {
    val w = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
    return (w / tileWidth).coerceAtLeast(1)
}

fun openUrl(context: Context, url: String) {
    if (url.isBlank()) return
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No browser found.", Toast.LENGTH_SHORT).show()
    }
}

/**
 * A grab handle for reordering fixed-height rows: drag up or down and the row moves one slot each time the finger
 * crosses a row. [rowHeight] must match the row's full height including list spacing.
 */
@Composable
fun DragHandle(index: Int, count: Int, rowHeight: Dp, onMove: (from: Int, to: Int) -> Unit) {
    val step = with(androidx.compose.ui.platform.LocalDensity.current) { rowHeight.toPx() }
    var at by remember(index) { mutableIntStateOf(index) }
    var acc by remember(index) { mutableStateOf(0f) }
    Text(
        "☰",
        Modifier
            .pointerInput(index, count) {
                detectDragGestures(
                    onDragStart = { at = index; acc = 0f },
                    onDrag = { change, drag ->
                        change.consume()
                        acc += drag.y
                        while (acc > step / 2 && at < count - 1) { onMove(at, at + 1); at++; acc -= step }
                        while (acc < -step / 2 && at > 0) { onMove(at, at - 1); at--; acc += step }
                    },
                )
            }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        style = Type.Heading,
        color = Palette.Faint
    )
}

@Composable
fun Sub(text: String, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) {
    Text(text, modifier, style = Type.Small, color = Palette.Sub, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}
