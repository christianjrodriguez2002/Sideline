@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Article
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorite
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Injury
import com.roki.sideline.data.Predict
import com.roki.sideline.data.Settings
import com.roki.sideline.data.TeamDetail
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private data class FavBundle(
    val detail: TeamDetail?,
    val live: Game?,
    val next: Game?,
    val last: Game?,
    val injuries: List<Injury>,
    val news: List<Article>,
    val prediction: Pair<Double, String>?,
)

private suspend fun loadBundle(f: Favorite, force: Boolean): FavBundle = coroutineScope {
    val league = f.league
    val id = f.team.id
    val scheduleD = async { runCatching { Espn.schedule(league, id, force) }.getOrDefault(emptyList()) }
    val todayD = async {
        runCatching {
            if (league.weekly) Espn.week(league, null, force = force).games
            else Espn.day(league, LocalDate.now(Fmt.zone()), force = force)
        }.getOrDefault(emptyList()).filter { it.involves(id) }
    }
    val detailD = async { runCatching { Espn.team(league, id, force) }.getOrNull() }
    val injD = async { runCatching { Espn.injuries(league, force).filter { it.teamId == id } }.getOrDefault(emptyList()) }
    val newsD = async { runCatching { Espn.news(league, id, force).take(3) }.getOrDefault(emptyList()) }
    val schedule = scheduleD.await()
    val todays = todayD.await()
    val live = todays.firstOrNull { it.state == GameState.IN } ?: schedule.firstOrNull { it.state == GameState.IN }
    val next = (todays.filter { it.state == GameState.PRE } + schedule.filter { it.state == GameState.PRE })
        .distinctBy { it.id }.minByOrNull { it.start ?: Instant.MAX }
    val last = (todays.filter { it.state == GameState.POST } + schedule.filter { it.state == GameState.POST })
        .distinctBy { it.id }.maxByOrNull { it.start ?: Instant.MIN }
    val prediction = next?.let { g ->
        val d = runCatching { Espn.game(league, g.id, force) }.getOrNull()
        val homeIsMe = g.home.team.id == id
        d?.let { dd -> dd.homeWinPct?.let { h -> (if (homeIsMe) h else 100 - h - (dd.drawPct ?: 0.0)) to dd.predictorName } }
            ?: Predict.homeWinProb(league, g.home.record, g.away.record)?.let { h ->
                (if (homeIsMe) h * 100 else 100 - h * 100) to "estimate from records"
            }
    }
    FavBundle(detailD.await(), live, next, last, injD.await(), newsD.await(), prediction)
}

private suspend fun loadToday(force: Boolean): List<Game> = coroutineScope {
    val leagues = (Favorites.list.map { it.league } + Settings.pinnedLeagues()).filter { it.teamBased }.distinctBy { it.key }.take(6)
    val today = LocalDate.now(Fmt.zone())
    val all = leagues.map { l ->
        async {
            runCatching {
                if (l.weekly) Espn.week(l, null, force = force).games.filter { it.start?.atZone(Fmt.zone())?.toLocalDate() == today }
                else Espn.day(l, today, force = force)
            }.getOrDefault(emptyList())
        }
    }.awaitAll().flatten()
    all.sortedWith(
        compareBy(
            { g -> if (Favorites.list.any { it.league.key == g.league.key && g.involves(it.team.id) }) 0 else 1 },
            { g -> when (g.state) { GameState.IN -> 0; GameState.PRE -> 1; GameState.POST -> 2 } },
            { g -> g.start },
        )
    ).take(24).also { runCatching { com.roki.sideline.work.SidelineWidget.update(appContext) } }
}

/** Set once by the Application so background loads can reach the widget. */
internal lateinit var appContext: android.content.Context

private val TODAY_FMT = DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.getDefault())

@Composable
fun HomeScreen(onBrowse: () -> Unit, onSettings: () -> Unit) {
    val nav = LocalNav.current
    var reload by remember { mutableIntStateOf(0) }
    var refreshing by remember { mutableStateOf(false) }
    val favs = Favorites.list.toList()
    val name = Settings.name.value
    LaunchedEffect(reload) {
        if (reload > 0) {
            refreshing = true
            delay(1500)
            refreshing = false
        }
    }
    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { Espn.clear(); reload++ }, modifier = Modifier.fillMaxSize()) {
    LazyColumn(contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            val lead = favs.firstOrNull()?.league ?: Settings.pinnedLeagues().firstOrNull() ?: com.roki.sideline.data.Leagues.all.first()
            PhotoHero(com.roki.sideline.data.Art.photoFor(lead), Palette.BlueSoft, height = 236.dp) {
                Column(Modifier.align(Alignment.BottomStart).padding(start = 20.dp, end = 20.dp, bottom = 14.dp)) {
                    Text(
                        TODAY_FMT.format(LocalDate.now(Fmt.zone())).uppercase(),
                        style = Type.Label,
                        color = Color.White.copy(alpha = 0.82f)
                    )
                    Text(
                        Fmt.greeting() + if (name.isNotBlank()) ", $name" else "",
                        style = Type.Display,
                        color = Color.White
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val place = com.roki.sideline.data.Where.place.value
                        Box(
                            Modifier
                                .clip(ChipShape)
                                .background(Color.Black.copy(alpha = 0.38f))
                                .border(0.5.dp, Color.White.copy(alpha = 0.22f), ChipShape)
                                .clickable(onClick = onSettings)
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "📍 " + (place?.label ?: "Set location") + " · ${Fmt.zoneShort()}",
                                style = Type.Small,
                                color = Color.White
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Box(
                            Modifier
                                .clip(ChipShape)
                                .background(Color.Black.copy(alpha = 0.38f))
                                .border(0.5.dp, Color.White.copy(alpha = 0.22f), ChipShape)
                                .clickable { Espn.clear(); reload++ }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("↻ Refresh", style = Type.Small, color = Color.White)
                        }
                    }
                }
            }
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(Settings.pinnedLeagues()) { l ->
                    Column(
                        Modifier.width(64.dp).clickable { nav.league(l) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LeagueMark(l, 52.dp)
                        Spacer(Modifier.height(4.dp))
                        Text(l.short, style = Type.Small, color = Palette.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                item {
                    Column(
                        Modifier.width(64.dp).clickable(onClick = onBrowse),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .width(52.dp)
                                .height(52.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Palette.Raised)
                                .border(1.dp, Palette.Line, RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("+", style = Type.Title, color = Palette.Sub) }
                        Spacer(Modifier.height(4.dp))
                        Text("More", style = Type.Small, color = Palette.Sub)
                    }
                }
            }
        }
        item {
            Loaded(
                key = "today:$reload:${favs.size}:${Settings.pins.size}",
                load = { force -> loadToday(force || reload > 0) },
                skeletonRows = 1
            ) { games, refresh ->
                LaunchedEffect(games) {
                    if (games.any { it.state == GameState.IN }) {
                        delay(45_000)
                        refresh()
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeader(
                        if (games.any { it.state == GameState.IN }) "Live & today" else "Today",
                        Modifier.padding(horizontal = 20.dp)
                    )
                    if (games.isEmpty()) {
                        Sub("No games today in your leagues.", Modifier.padding(horizontal = 20.dp))
                    } else {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(games) { g -> GameTile(g) }
                        }
                    }
                }
            }
        }
        if (favs.isEmpty()) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                Text("Build your lineup", style = Type.Title, color = Palette.Text)
                Text(
                    "Follow teams from any league to get live scores, the next game, TV, injuries and headlines here.",
                    style = Type.Body,
                    color = Palette.Sub
                )
                PillButton("Find teams", onBrowse)
            }
        } else {
            item { SectionHeader("Your teams", Modifier.padding(horizontal = 20.dp)) }
            items(favs.size) { i -> FavoriteCard(favs[i], reload) }
        }
    }
    }
}

@Composable
private fun FavoriteCard(f: Favorite, reload: Int) {
    val nav = LocalNav.current
    val context = LocalContext.current
    val color = teamColor(f.team.color, Color(f.league.accent))
    Column(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .clip(CardShape)
            .background(Palette.Surface)
            .border(1.dp, Palette.Line, CardShape)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.42f), Palette.Surface)))
                .clickable { nav.team(f.league, f.team) }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Logo(f.team.logo, 48.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "${f.league.emoji} ${f.league.short}".uppercase(),
                        style = Type.Label,
                        color = Color.White.copy(alpha = 0.82f)
                    )
                    Text(
                        f.team.name,
                        style = Type.Title,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    "★",
                    Modifier.clickable { Favorites.toggle(context, f.league, f.team) }.padding(6.dp),
                    style = Type.Title,
                    color = Palette.Gold
                )
            }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Loaded(key = "${f.key}:$reload", load = { force -> loadBundle(f, force || reload > 0) }, skeletonRows = 1) { b, _ ->
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    b.detail?.let { d ->
                        val line = listOf(d.record, d.standingSummary).filter { it.isNotBlank() }.joinToString(" · ")
                        if (line.isNotBlank()) Text(line, style = Type.BodyStrong, color = Palette.Text)
                    }
                    b.live?.let { g ->
                        SectionHeader("Live now")
                        GameCard(g)
                    }
                    b.next?.takeIf { it.id != b.live?.id }?.let { g ->
                        SectionHeader("Next up")
                        GameCard(g, showDate = true)
                        com.roki.sideline.data.Tv.plan(g, com.roki.sideline.data.Where.place.value)
                            .firstOrNull { it.reach != com.roki.sideline.data.Reach.LOCAL_ELSEWHERE }?.let { w ->
                                Sub((if (w.reach == com.roki.sideline.data.Reach.LOCAL_YOURS) "📍 " else "📺 ") + w.text)
                            }
                        b.prediction?.let { (pct, source) ->
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row {
                                    Text("${f.team.abbr} win chance", Modifier.weight(1f), style = Type.Small, color = Palette.Sub)
                                    Text(Predict.pctText(pct), style = Type.BodyStrong, color = Palette.Text)
                                }
                                SplitBar(pct, color, Palette.Raised2)
                                Text(source, style = Type.Label, color = Palette.Faint)
                            }
                        }
                    }
                    b.last?.let { g ->
                        val me = g.sideOf(f.team.id)
                        val opp = g.opponentOf(f.team.id)
                        val res = if (me.winner) "W" else if (opp.winner) "L" else "D"
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Palette.Raised)
                                .border(1.dp, Palette.Line, RoundedCornerShape(12.dp))
                                .clickable { nav.game(f.league, g.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Tag(
                                res,
                                if (res == "W") Palette.Win else if (res == "L") Palette.Loss else Palette.Raised2,
                                Color(0xFF0B0F14)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "${me.score}–${opp.score} ${if (me.home) "vs" else "at"} ${opp.team.shortName}",
                                Modifier.weight(1f),
                                style = Type.BodyStrong,
                                color = Palette.Text,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Sub(Fmt.dayShort(g.start))
                        }
                    }
                    if (f.league.injuries) {
                        if (b.injuries.isNotEmpty()) {
                            SectionHeader("Injury report · ${b.injuries.size}")
                            b.injuries.take(4).forEach { inj ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        inj.athleteName + if (inj.position.isNotBlank()) "  ${inj.position}" else "",
                                        Modifier.weight(1f),
                                        style = Type.Body,
                                        color = Palette.Text,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val (bg, fg) = statusColors(inj.status)
                                    if (inj.status.isNotBlank()) Tag(inj.status, bg, fg)
                                }
                            }
                            if (b.injuries.size > 4) Sub("+${b.injuries.size - 4} more on the team page")
                        } else {
                            Sub("💪 Nobody on the injury report")
                        }
                    }
                    if (b.news.isNotEmpty()) {
                        SectionHeader("Headlines")
                        b.news.take(2).forEach { a ->
                            Text(
                                a.headline,
                                Modifier.clickable { openUrl(context, a.url) },
                                style = Type.Body,
                                color = Palette.Text,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
