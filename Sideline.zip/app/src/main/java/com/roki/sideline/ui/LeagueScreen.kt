package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Article
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Injury
import com.roki.sideline.data.Kind
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.Settings
import com.roki.sideline.data.StandingTable
import com.roki.sideline.data.TeamRef
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun tabsFor(l: League): List<String> = when (l.kind) {
    Kind.TEAM, Kind.SOCCER, Kind.RUGBY -> listOfNotNull(
        "Scores", if (l.standings) "Standings" else null, if (l.rankings) "Rankings" else null, "Teams",
        if (l.injuries) "Injuries" else null, "News", if (l.moves) "Moves" else null,
    )
    Kind.RACE -> listOf("This week", "Calendar", "Standings", "News")
    Kind.FIGHT -> listOf("Fight cards", "Calendar", "News")
    Kind.GOLF -> listOf("Leaderboard", "Calendar", "News")
    Kind.TENNIS -> listOf("Tournaments", "Calendar", "News")
    Kind.CRICKET -> listOf("Matches")
}

@Composable
fun LeagueScreen(league: League) {
    val context = LocalContext.current
    val tabs = tabsFor(league)
    var tab by rememberSaveable(league.key) { mutableIntStateOf(0) }
    val pinned = league.key in Settings.pins
    Column(Modifier.fillMaxSize()) {
        PhotoHero(com.roki.sideline.data.Art.photoFor(league), Color(league.accent), height = 168.dp) {
            Row(Modifier.fillMaxWidth().align(Alignment.BottomStart).padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically) {
                LeagueMark(league, 56.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(league.category.title.uppercase(), style = Type.Label, color = Color.White.copy(alpha = 0.75f))
                    Text(league.label, style = Type.Title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Times in ${Fmt.zoneShort()}", style = Type.Small, color = Color.White.copy(alpha = 0.75f))
                }
                Box(
                    Modifier.clip(ChipShape).background(if (pinned) Palette.Gold else Color.White.copy(alpha = 0.18f))
                        .clickable { Settings.togglePin(context, league.key) }.padding(horizontal = 12.dp, vertical = 6.dp),
                ) {
                    Text(if (pinned) "★ Pinned" else "☆ Pin", style = Type.BodyStrong, color = if (pinned) Color(0xFF231700) else Color.White)
                }
            }
        }
        PillTabs(tabs, tab) { tab = it }
        when (tabs.getOrNull(tab)) {
            "Scores" -> LeagueScores(league)
            "Standings" -> StandingsTab(league)
            "Rankings" -> RankingsTab(league)
            "Teams" -> TeamsTab(league)
            "Injuries" -> InjuriesTab(league)
            "News" -> NewsList(league, null)
            "Moves" -> MovesTab(league)
            "This week", "Fight cards", "Leaderboard", "Tournaments", "Matches" -> EventsNow(league)
            "Calendar" -> CalendarTab(league)
            else -> {}
        }
    }
}

// ---------- scores ----------

private val DOW = DateTimeFormatter.ofPattern("EEE", Locale.getDefault())
private val DOM = DateTimeFormatter.ofPattern("d", Locale.getDefault())
private val LONG_DAY = DateTimeFormatter.ofPattern("EEEE, MMMM d", Locale.getDefault())

/** Scores for any league: event sports get their own views; team sports get a day (or week) slate in your time zone. */
@Composable
fun LeagueScores(league: League) {
    if (!league.teamBased) {
        EventsNow(league)
        return
    }
    if (league.weekly) WeekScores(league) else DayScores(league)
}

@Composable
private fun DayScores(league: League) {
    val today = LocalDate.now(Fmt.zone())
    var date by rememberSaveable(league.key) { mutableStateOf(today.toString()) }
    var all by rememberSaveable(league.key) { mutableStateOf(false) }
    val day = LocalDate.parse(date)
    Column(Modifier.fillMaxSize()) {
        DateStrip(day) { date = it.toString() }
        if (league.allGroups != null) TopToggle(all) { all = it }
        Loaded(key = "day:${league.key}:$date:$all", load = { force -> Espn.day(league, day, all, force) }, pull = true) { games, refresh ->
            LaunchedEffect(games) {
                if (games.any { it.state == GameState.IN }) {
                    delay(30_000)
                    refresh()
                }
            }
            val sorted = sortForMe(league, games)
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Sub(LONG_DAY.format(day) + " · times in ${Fmt.zoneShort()}", Modifier.padding(top = 4.dp)) }
                if (sorted.isEmpty()) {
                    item { EmptyState(league.emoji, "No ${league.short} games on this day", "Here's what's coming up next.") }
                    item { ComingUp(league) }
                }
                items(sorted) { g -> GameCard(g) }
            }
        }
    }
}

@Composable
private fun ComingUp(league: League) {
    Loaded(key = "cur:${league.key}", load = { force -> Espn.current(league, force) }, skeletonRows = 2) { games, _ ->
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (games.isEmpty()) Sub("The season hasn't started yet, or ESPN hasn't posted the schedule.")
            games.groupBy { it.start?.atZone(Fmt.zone())?.toLocalDate() }.forEach { (d, list) ->
                SectionHeader(d?.let { LONG_DAY.format(it) } ?: "TBD")
                list.forEach { GameCard(it) }
            }
        }
    }
}

@Composable
private fun WeekScores(league: League) {
    var week by remember(league.key) { mutableStateOf<Pair<Int, Int>?>(null) }
    var shown by remember(league.key) { mutableStateOf<Pair<Int, Int>?>(null) }
    var all by rememberSaveable(league.key) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundButton("‹") { shown?.let { (w, t) -> week = if (w > 1) (w - 1) to t else if (t == 3) 18 to 2 else 1 to t } }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(shown?.let { (w, t) -> when (t) { 3 -> "Postseason · Round $w"; 1 -> "Preseason · Week $w"; else -> "Week $w" } } ?: "This week",
                    style = Type.Heading, color = Palette.Text)
                Sub("Times in ${Fmt.zoneShort()}")
            }
            if (week != null) {
                Text("This week", Modifier.clickable { week = null }.padding(8.dp), style = Type.Small, color = Palette.Blue, fontWeight = FontWeight.Bold)
            }
            RoundButton("›") { shown?.let { (w, t) -> week = if (t == 2 && w >= 18) 1 to 3 else (w + 1) to t } }
        }
        if (league.allGroups != null) TopToggle(all) { all = it }
        Loaded(key = "wk:${league.key}:$week:$all", load = { force -> Espn.week(league, week, all, force) }, pull = true) { board, refresh ->
            LaunchedEffect(board) {
                shown = board.week
                if (board.games.any { it.state == GameState.IN }) {
                    delay(30_000)
                    refresh()
                }
            }
            val byDay = sortForMe(league, board.games).groupBy { it.start?.atZone(Fmt.zone())?.toLocalDate() }.toSortedMap(compareBy { it ?: LocalDate.MAX })
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (board.games.isEmpty()) item { EmptyState(league.emoji, "No games this week", "Use the arrows to look around the schedule.") }
                byDay.forEach { (d, list) ->
                    item { SectionHeader(d?.let { LONG_DAY.format(it) } ?: "TBD") }
                    items(list) { g -> GameCard(g) }
                }
            }
        }
    }
}

private fun sortForMe(league: League, games: List<com.roki.sideline.data.Game>) = games.sortedWith(compareBy(
    { g -> if (Favorites.list.any { it.league.key == league.key && g.involves(it.team.id) }) 0 else 1 },
    { g -> when (g.state) { GameState.IN -> 0; GameState.PRE -> 1; GameState.POST -> 2 } },
    { g -> g.start },
))

@Composable
private fun TopToggle(all: Boolean, onChange: (Boolean) -> Unit) {
    PillTabs(listOf("Top 25", "All games"), if (all) 1 else 0) { onChange(it == 1) }
}

@Composable
fun RoundButton(text: String, onClick: () -> Unit) {
    Box(Modifier.size(38.dp).clip(ChipShape).background(Palette.Raised).border(1.dp, Palette.Line, ChipShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center) {
        Text(text, style = Type.Title, color = Palette.Text)
    }
}

/** A week of day chips around the chosen date, plus arrows. */
@Composable
fun DateStrip(selected: LocalDate, onPick: (LocalDate) -> Unit) {
    val today = LocalDate.now(Fmt.zone())
    val days = (-3..3).map { selected.plusDays(it.toLong()) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        RoundButton("‹") { onPick(selected.minusDays(7)) }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
            days.forEach { d ->
                val on = d == selected
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) Palette.Blue else Color.Transparent)
                        .clickable { onPick(d) }.padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(if (d == today) "TODAY" else DOW.format(d).uppercase(), style = Type.Label,
                        color = if (on) Color.White else if (d == today) Palette.Blue else Palette.Faint, maxLines = 1)
                    Text(DOM.format(d), style = Type.Heading, color = if (on) Color.White else Palette.Text)
                }
            }
        }
        RoundButton("›") { onPick(selected.plusDays(7)) }
    }
}

// ---------- standings & rankings ----------

@Composable
private fun StandingsTab(league: League) {
    Loaded(key = "st:${league.key}", load = { force -> Espn.standings(league, force) }, pull = true) { tables, _ ->
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (tables.isEmpty()) item { EmptyState(league.emoji, "Standings aren't posted yet") }
            items(tables) { t -> StandingCard(league, t) }
        }
    }
}

@Composable
fun StandingCard(league: League, t: StandingTable, highlight: String? = null) {
    val nav = LocalNav.current
    Panel {
        Text(t.title, style = Type.Heading, color = Palette.Text)
        val rows = t.rows.mapIndexed { i, r -> "${i + 1}  ${r.team.abbr}" to t.columns.map { (k, _) -> r.stats[k].orEmpty() } }
        Row {
            Column(Modifier.width(30.dp).padding(top = 24.dp)) {
                t.rows.forEach { r ->
                    Box(Modifier.height(32.dp), contentAlignment = Alignment.CenterStart) { Logo(r.team.logo, 20.dp) }
                }
            }
            Box(Modifier.weight(1f)) {
                DataTable(
                    t.columns.map { it.second }, rows, firstWidth = 96.dp,
                    highlight = { i -> t.rows[i].team.id == highlight || Favorites.isFavorite(league, t.rows[i].team.id) },
                    onRow = if (league.teamBased) { i -> nav.team(league, t.rows[i].team) } else null,
                )
            }
        }
        val notes = t.rows.filter { it.note.isNotBlank() }.map { it.note to it.noteColor }.distinctBy { it.first }
        notes.forEach { (n, c) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(ChipShape).background(teamColor(c, Palette.Win)))
                Spacer(Modifier.width(6.dp))
                Sub(n)
            }
        }
    }
}

@Composable
private fun RankingsTab(league: League) {
    val nav = LocalNav.current
    var which by remember(league.key) { mutableIntStateOf(0) }
    Loaded(key = "rk:${league.key}", load = { force -> Espn.rankings(league, force) }, pull = true) { polls, _ ->
        Column {
            if (polls.size > 1) PillTabs(polls.map { it.name }, which) { which = it }
            val poll = polls.getOrNull(which)
            LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (poll == null) item { EmptyState(league.emoji, "No rankings posted yet") }
                else items(poll.rows) { r ->
                    Panel(onClick = { nav.team(league, r.team) }, padding = 12.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${r.rank}", Modifier.width(34.dp), style = Type.Title, color = Palette.Text)
                            Logo(r.team.logo, 32.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.team.name, style = Type.BodyStrong, color = if (Favorites.isFavorite(league, r.team.id)) Palette.Gold else Palette.Text,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Sub(listOf(r.record, if (r.points.isNotBlank()) "${r.points} pts" else "",
                                    if (r.firstPlace.isNotBlank()) "${r.firstPlace} first-place" else "").filter { it.isNotBlank() }.joinToString(" · "))
                            }
                            val move = r.previous?.let { it - r.rank }
                            when {
                                move == null -> Tag("NEW", Palette.BlueSoft, Color.White)
                                move > 0 -> Text("▲$move", style = Type.BodyStrong, color = Palette.Win)
                                move < 0 -> Text("▼${-move}", style = Type.BodyStrong, color = Palette.Loss)
                                else -> Text("–", style = Type.BodyStrong, color = Palette.Faint)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- teams ----------

@Composable
private fun TeamsTab(league: League) {
    val context = LocalContext.current
    val nav = LocalNav.current
    var query by rememberSaveable(league.key) { mutableStateOf("") }
    Loaded(key = "teams:${league.key}", load = { Espn.teams(league) }, pull = true) { teams, _ ->
        val q = query.trim().lowercase()
        val shown = teams.filter { q.isEmpty() || it.name.lowercase().contains(q) || it.abbr.lowercase().contains(q) }
            .sortedBy { if (Favorites.isFavorite(league, it.id)) 0 else 1 }
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (teams.size > 12) item {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Find a team") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            item { Sub("Tap ☆ to follow a team. Followed teams live on your Home screen.") }
            items(shown) { t ->
                val fav = Favorites.isFavorite(league, t.id)
                Panel(onClick = { nav.team(league, t) }, padding = 12.dp) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(4.dp).height(32.dp).clip(ChipShape).background(teamColor(t.color, Palette.Line)))
                        Spacer(Modifier.width(12.dp))
                        Logo(t.logo, 34.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(t.name, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (fav) "★" else "☆", Modifier.clickable { Favorites.toggle(context, league, t) }.padding(8.dp),
                            style = Type.Title, color = if (fav) Palette.Gold else Palette.Faint)
                    }
                }
            }
        }
    }
}

// ---------- injuries ----------

@Composable
private fun InjuriesTab(league: League) {
    var mine by rememberSaveable(league.key) { mutableStateOf(Favorites.list.any { it.league.key == league.key }) }
    var query by rememberSaveable(league.key + "q") { mutableStateOf("") }
    Loaded(key = "inj:${league.key}", load = { force -> Espn.injuries(league, force) }, pull = true) { list, _ ->
        val favIds = Favorites.list.filter { it.league.key == league.key }.map { it.team.id }.toSet()
        val q = query.trim().lowercase()
        val shown = list.filter { (!mine || it.teamId in favIds) && (q.isEmpty() || it.athleteName.lowercase().contains(q) || it.teamName.lowercase().contains(q)) }
        val groups = shown.groupBy { it.teamName.ifBlank { "Other" } }.toList()
            .sortedWith(compareBy({ (_, l) -> if (l.first().teamId in favIds) 0 else 1 }, { it.first }))
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search player or team") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            if (favIds.isNotEmpty()) item { PillTabs(listOf("All teams", "My teams"), if (mine) 1 else 0, Modifier.padding(0.dp)) { mine = it == 1 } }
            if (groups.isEmpty()) item { EmptyState("🩹", if (list.isEmpty()) "No injuries reported right now" else "Nothing matches") }
            groups.forEach { (team, injuries) ->
                item {
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Logo(injuries.first().teamLogo, 22.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(team, style = Type.Heading, color = Palette.Text)
                        Spacer(Modifier.width(8.dp))
                        Tag("${injuries.size}")
                    }
                }
                items(injuries) { inj -> InjuryRow(league, inj, showTeam = false) }
            }
        }
    }
}

@Composable
fun InjuryRow(league: League, inj: Injury, showTeam: Boolean) {
    val nav = LocalNav.current
    val (bg, fg) = statusColors(inj.status)
    Panel(onClick = {
        if (inj.athleteId.isNotBlank()) nav.player(league, Player(inj.athleteId, inj.athleteName, position = inj.position,
            headshot = inj.headshot, injuryStatus = inj.status, teamId = inj.teamId, teamName = inj.teamName))
    }, padding = 12.dp) {
        Row(verticalAlignment = Alignment.Top) {
            Headshot(inj.headshot, 44.dp, ring = bg, name = inj.athleteName)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(inj.athleteName, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (inj.status.isNotBlank()) Tag(inj.status, bg, fg)
                }
                Sub(listOf(inj.position, if (showTeam) inj.teamName else "", inj.type).filter { it.isNotBlank() }.joinToString(" · "))
                if (inj.comment.isNotBlank()) Text(inj.comment, style = Type.Small, color = Palette.Text)
                val dates = listOfNotNull(
                    inj.returnDate.takeIf { it.isNotBlank() }?.let { "Est. return ${it.take(10)}" },
                    inj.date?.let { "Updated ${Fmt.ago(it)}" },
                ).joinToString(" · ")
                if (dates.isNotBlank()) Sub(dates)
            }
        }
    }
}

// ---------- news & moves ----------

@Composable
fun NewsList(league: League, team: TeamRef?) {
    Loaded(key = "news:${league.key}:${team?.id}", load = { force -> Espn.news(league, team?.id, force) }, pull = true) { list, _ ->
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (list.isEmpty()) item { EmptyState("📰", "No news right now") }
            list.firstOrNull()?.let { lead -> item { LeadStory(lead) } }
            items(list.drop(1)) { a -> ArticleRow(a) }
        }
    }
}

@Composable
fun LeadStory(a: Article) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(CardShape).background(Palette.Surface).border(1.dp, Palette.Line, CardShape)
        .clickable { openUrl(context, a.url) }) {
        if (a.image.isNotBlank()) coil.compose.AsyncImage(model = a.image, contentDescription = null,
            modifier = Modifier.fillMaxWidth().height(190.dp))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(a.headline, style = Type.Title, color = Palette.Text)
            if (a.description.isNotBlank()) Sub(a.description, maxLines = 3)
            if (a.published != null) Text(Fmt.ago(a.published).uppercase(), style = Type.Label, color = Palette.Faint)
        }
    }
}

@Composable
fun ArticleRow(a: Article) {
    val context = LocalContext.current
    Panel(onClick = { openUrl(context, a.url) }, padding = 12.dp) {
        Row {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(a.headline, style = Type.BodyStrong, color = Palette.Text, maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (a.published != null) Text(Fmt.ago(a.published).uppercase(), style = Type.Label, color = Palette.Faint)
            }
            if (a.image.isNotBlank()) {
                Spacer(Modifier.width(12.dp))
                Box(Modifier.size(width = 104.dp, height = 70.dp).clip(RoundedCornerShape(12.dp))) {
                    coil.compose.AsyncImage(model = a.image, contentDescription = null, modifier = Modifier.size(width = 104.dp, height = 70.dp))
                }
            }
        }
    }
}

@Composable
private fun MovesTab(league: League) {
    val nav = LocalNav.current
    Loaded(key = "tx:${league.key}", load = { force -> Espn.transactions(league, force) }, pull = true) { list, _ ->
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Sub("Signings, trades, waivers and call-ups.") }
            if (list.isEmpty()) item { EmptyState("📝", "No recent moves") }
            items(list) { t ->
                Panel(onClick = { t.team?.let { nav.team(league, it) } }, padding = 12.dp) {
                    Row(verticalAlignment = Alignment.Top) {
                        Logo(t.team?.logo.orEmpty(), 30.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(t.description, style = Type.Body, color = Palette.Text)
                            Text(listOfNotNull(t.team?.abbr, t.date?.let { Fmt.dayShort(it) }).joinToString(" · ").uppercase(),
                                style = Type.Label, color = Palette.Faint)
                        }
                    }
                }
            }
        }
    }
}
