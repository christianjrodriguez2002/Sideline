package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.CricketSeries
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Fight
import com.roki.sideline.data.FightCard
import com.roki.sideline.data.Fighter
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Kind
import com.roki.sideline.data.League
import com.roki.sideline.data.RaceWeekend
import com.roki.sideline.data.Session
import com.roki.sideline.data.Streaming
import com.roki.sideline.data.TennisEvent
import com.roki.sideline.data.TennisMatch
import com.roki.sideline.data.Tournament
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate

/** Anything event-shaped we can show for a league: fight cards, race weekends, tournaments, cricket series. */
private sealed class Ev {
    data class Fights(val list: List<FightCard>) : Ev()
    data class Races(val list: List<RaceWeekend>) : Ev()
    data class Golf(val list: List<Tournament>) : Ev()
    data class Tennis(val list: List<TennisEvent>) : Ev()
    data class Cricket(val list: List<CricketSeries>) : Ev()

    val isEmpty: Boolean
        get() = when (this) {
            is Fights -> list.isEmpty()
            is Races -> list.isEmpty()
            is Golf -> list.isEmpty()
            is Tennis -> list.isEmpty()
            is Cricket -> list.isEmpty()
        }
    val live: Boolean
        get() = when (this) {
            is Fights -> list.any { it.state == GameState.IN }
            is Races -> list.any { it.state == GameState.IN }
            is Golf -> list.any { it.state == GameState.IN }
            is Tennis -> list.any { e -> e.draws.any { d -> d.second.any { it.state == GameState.IN } } }
            is Cricket -> list.any { s -> s.matches.any { it.state == GameState.IN } }
        }
}

private suspend fun loadEvents(league: League, date: LocalDate?, force: Boolean): Ev = when (league.kind) {
    Kind.FIGHT -> Ev.Fights(Espn.fights(league, date, force))
    Kind.RACE -> Ev.Races(Espn.races(league, date, force))
    Kind.GOLF -> Ev.Golf(Espn.golf(league, date, force))
    Kind.TENNIS -> Ev.Tennis(Espn.tennis(league, date, force))
    Kind.CRICKET -> Ev.Cricket(Espn.cricket(force))
    else -> throw IllegalStateException("Not an event sport")
}

/** What's on now / next for an event sport. */
@Composable
fun EventsNow(league: League, date: LocalDate? = null) {
    Loaded(key = "ev:${league.key}:$date", load = { force -> loadEvents(league, date, force) }) { ev, refresh ->
        LaunchedEffect(ev) {
            if (ev.live) {
                delay(45_000)
                refresh()
            }
        }
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Sub("All times in ${Fmt.zoneLong()} (${Fmt.zoneShort()})") }
            if (ev.isEmpty) item {
                EmptyState(league.emoji, "Nothing scheduled right now",
                    if (league.kind == Kind.CRICKET) "No cricket series are active today." else "Open the Calendar tab to see the whole season.")
            }
            when (ev) {
                is Ev.Fights -> items(ev.list) { FightCardView(league, it) }
                is Ev.Races -> items(ev.list) { RaceView(league, it) }
                is Ev.Golf -> items(ev.list) { TournamentView(league, it) }
                is Ev.Tennis -> items(ev.list) { TennisView(it) }
                is Ev.Cricket -> items(ev.list) { CricketView(it) }
            }
        }
    }
}

/** The season list from ESPN's calendar; tap one to open it. */
@Composable
fun CalendarTab(league: League) {
    val nav = LocalNav.current
    Loaded(key = "cal:${league.key}", load = { Espn.calendar(league) }) { items, _ ->
        val now = Instant.now()
        val upcoming = items.filter { (it.end ?: it.start ?: now) >= now }
        val done = items.filter { (it.end ?: it.start ?: now) < now }.reversed()
        LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (items.isEmpty()) item { EmptyState("🗓️", "No calendar posted yet") }
            if (upcoming.isNotEmpty()) item { SectionHeader("Upcoming") }
            items(upcoming) { c ->
                CalendarRow(league, c.label, Fmt.dateRange(c.start, c.end), upcoming.firstOrNull() === c) {
                    Espn.espnDate(c.start)?.let { nav.event(league, c.label, it) }
                }
            }
            if (done.isNotEmpty()) item { SectionHeader("Completed") }
            items(done) { c ->
                CalendarRow(league, c.label, Fmt.dateRange(c.start, c.end), false) {
                    Espn.espnDate(c.start)?.let { nav.event(league, c.label, it) }
                }
            }
        }
    }
}

@Composable
private fun CalendarRow(league: League, label: String, dates: String, next: Boolean, onClick: () -> Unit) {
    Panel(onClick = onClick, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LeagueMark(league, 36.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(label, style = Type.BodyStrong, color = Palette.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Sub(dates)
            }
            if (next) Tag("NEXT", Palette.Blue, Color.White)
            Text("›", Modifier.padding(start = 8.dp), style = Type.Title, color = Palette.Faint)
        }
    }
}

@Composable
fun EventScreen(league: League, date: LocalDate) = EventsNow(league, date)

// ---------- UFC ----------

@Composable
private fun FightCardView(league: League, card: FightCard) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(card.name, style = Type.Title, color = Palette.Text)
                Sub(listOf(Fmt.dayTime(card.start), card.venue).filter { it.isNotBlank() }.joinToString(" · "))
                val vz = com.roki.sideline.data.Places.zoneFromPlace(card.venue)
                if (com.roki.sideline.data.Places.differs(vz, card.start)) Sub("Starts ${Fmt.timeIn(card.start, vz!!)} local")
            }
            StateBadge(card.state)
        }
        if (card.broadcasts.isNotEmpty()) WatchLine(league, card.broadcasts)
        var all by remember(card.id) { mutableStateOf(false) }
        val shown = if (all) card.fights else card.fights.take(5)
        shown.forEachIndexed { i, f ->
            if (i > 0) HorizontalDivider(color = Palette.Line, thickness = 1.dp)
            FightRow(f, main = i == 0)
        }
        if (card.fights.size > 5) Text(if (all) "Show main card only" else "Show all ${card.fights.size} fights",
            Modifier.clickable { all = !all }.padding(top = 4.dp), style = Type.BodyStrong, color = Palette.Blue)
    }
}

@Composable
private fun FightRow(f: Fight, main: Boolean) {
    Column(Modifier.padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text((if (main) "MAIN EVENT · " else "") + f.weightClass.uppercase(), Modifier.weight(1f), style = Type.Label,
                color = if (main) Palette.Gold else Palette.Faint, maxLines = 1)
            when (f.state) {
                GameState.IN -> LiveBadge()
                GameState.POST -> Text(f.status, style = Type.Small, color = Palette.Sub, maxLines = 1)
                GameState.PRE -> if (f.start != null) Text(Fmt.time(f.start), style = Type.Small, color = Palette.Sub)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            FighterSide(f.a, Modifier.weight(1f), main, alignEnd = false)
            Text("VS", Modifier.padding(horizontal = 8.dp), style = Type.Label, color = Palette.Faint)
            FighterSide(f.b, Modifier.weight(1f), main, alignEnd = true)
        }
    }
}

@Composable
private fun FighterSide(x: Fighter, modifier: Modifier, big: Boolean, alignEnd: Boolean) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = if (alignEnd) Arrangement.End else Arrangement.Start) {
        if (!alignEnd && big) { Headshot(x.headshot, 44.dp, ring = if (x.winner) Palette.Gold else Palette.Line); Spacer(Modifier.width(8.dp)) }
        Column(horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!alignEnd) { Flag(x.flag, 12.dp); Spacer(Modifier.width(4.dp)) }
                Text(x.name, style = if (big) Type.Heading else Type.BodyStrong,
                    color = if (x.winner) Palette.Gold else Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    textAlign = if (alignEnd) TextAlign.End else TextAlign.Start)
                if (alignEnd) { Spacer(Modifier.width(4.dp)); Flag(x.flag, 12.dp) }
            }
            Sub(listOf(x.record, if (x.winner) "WIN" else "").filter { it.isNotBlank() }.joinToString(" · "))
        }
        if (alignEnd && big) { Spacer(Modifier.width(8.dp)); Headshot(x.headshot, 44.dp, ring = if (x.winner) Palette.Gold else Palette.Line) }
    }
}

// ---------- racing ----------

@Composable
private fun RaceView(league: League, w: RaceWeekend) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(w.name, style = Type.Title, color = Palette.Text)
                Sub(listOf(w.circuit, w.location, Fmt.dateRange(w.start, w.end)).filter { it.isNotBlank() }.joinToString(" · "))
            }
            StateBadge(w.state)
        }
        val vz = com.roki.sideline.data.Places.zoneFromPlace(w.location)
        w.sessions.forEach { s -> SessionRow(league, s, defaultOpen = s.name.contains("Race", true) && s.state != GameState.PRE, venueZone = vz) }
    }
}

@Composable
private fun SessionRow(league: League, s: Session, defaultOpen: Boolean, venueZone: java.time.ZoneId? = null) {
    var open by remember(s.name + s.start) { mutableStateOf(defaultOpen) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Palette.Raised)
        .clickable { open = !open }.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.name, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text)
            when (s.state) {
                GameState.IN -> LiveBadge()
                else -> Text(Fmt.whenText(s.start), style = Type.Small, color = Palette.Sub)
            }
            if (s.results.isNotEmpty()) Text(if (open) "  ▴" else "  ▾", style = Type.Small, color = Palette.Faint)
        }
        if (s.state == GameState.PRE && com.roki.sideline.data.Places.differs(venueZone, s.start)) {
            Sub("${Fmt.timeIn(s.start, venueZone!!)} at the track")
        }
        if (s.broadcasts.isNotEmpty() && s.state != GameState.POST) WatchLine(league, s.broadcasts)
        if (open && s.results.isNotEmpty()) {
            s.results.take(if (s.state == GameState.POST) 20 else 10).forEach { r ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (r.position > 0) "${r.position}" else "–", Modifier.width(28.dp), style = Type.Num,
                        color = if (r.position in 1..3) Palette.Gold else Palette.Sub)
                    Flag(r.flag, 12.dp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text((if (r.number.isNotBlank()) "#${r.number} " else "") + r.name, style = Type.BodyStrong, color = Palette.Text,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (r.team.isNotBlank()) Sub(r.team, maxLines = 1)
                    }
                    Text(r.detail, style = Type.Num, color = Palette.Sub)
                }
            }
        }
    }
}

// ---------- golf ----------

@Composable
private fun TournamentView(league: League, t: Tournament) {
    var all by remember(t.id) { mutableStateOf(false) }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.name, style = Type.Title, color = Palette.Text)
                Sub(listOf(t.venue, Fmt.dateRange(t.start, t.end)).filter { it.isNotBlank() }.joinToString(" · "))
            }
            StateBadge(t.state)
        }
        if (t.status.isNotBlank()) Text(t.status, style = Type.Small, color = Palette.Sub)
        if (t.broadcasts.isNotEmpty() && t.state != GameState.POST) WatchLine(league, t.broadcasts)
        if (t.players.isEmpty()) Sub("The field and tee times post closer to the start.")
        else {
            Row {
                Text("POS", Modifier.width(40.dp), style = Type.Label, color = Palette.Faint)
                Text("PLAYER", Modifier.weight(1f), style = Type.Label, color = Palette.Faint)
                Text("TO PAR", Modifier.width(58.dp), style = Type.Label, color = Palette.Faint, textAlign = TextAlign.End)
                Text("THRU", Modifier.width(52.dp), style = Type.Label, color = Palette.Faint, textAlign = TextAlign.End)
            }
            (if (all) t.players else t.players.take(20)).forEach { p ->
                Row(Modifier.height(30.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.position, Modifier.width(40.dp), style = Type.Num, color = Palette.Sub)
                    Flag(p.flag, 11.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(p.name, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(p.toPar.ifBlank { "–" }, Modifier.width(58.dp), style = Type.Num, textAlign = TextAlign.End,
                        color = if (p.toPar.startsWith("-")) Palette.Loss else Palette.Text, fontWeight = FontWeight.Bold)
                    Text(p.thru, Modifier.width(52.dp), style = Type.Num, color = Palette.Sub, textAlign = TextAlign.End, maxLines = 1)
                }
            }
            if (t.players.size > 20) Text(if (all) "Show top 20" else "Show full field (${t.players.size})",
                Modifier.clickable { all = !all }, style = Type.BodyStrong, color = Palette.Blue)
            Sub("Red numbers are under par.")
        }
    }
}

// ---------- tennis ----------

@Composable
private fun TennisView(e: TennisEvent) {
    var draw by remember(e.id) { mutableIntStateOf(0) }
    Panel {
        Text(e.name, style = Type.Title, color = Palette.Text)
        Sub(listOf(e.venue, Fmt.dateRange(e.start, e.end)).filter { it.isNotBlank() }.joinToString(" · "))
        if (e.draws.size > 1) PillTabs(e.draws.map { it.first }, draw, Modifier.padding(0.dp)) { draw = it }
        val matches = e.draws.getOrNull(draw)?.second.orEmpty()
            .sortedWith(compareBy({ when (it.state) { GameState.IN -> 0; GameState.PRE -> 1; GameState.POST -> 2 } },
                { if (it.state == GameState.POST) -(it.start?.epochSecond ?: 0) else (it.start?.epochSecond ?: Long.MAX_VALUE) }))
        if (matches.isEmpty()) Sub("No matches posted yet.")
        var all by remember(e.id + draw) { mutableStateOf(false) }
        (if (all) matches else matches.take(12)).forEach { m -> TennisMatchRow(m) }
        if (matches.size > 12) Text(if (all) "Show fewer" else "Show all ${matches.size} matches",
            Modifier.clickable { all = !all }, style = Type.BodyStrong, color = Palette.Blue)
    }
}

@Composable
private fun TennisMatchRow(m: TennisMatch) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Palette.Raised).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(m.round.uppercase(), Modifier.weight(1f), style = Type.Label, color = Palette.Faint, maxLines = 1)
            when (m.state) {
                GameState.IN -> LiveBadge()
                GameState.PRE -> Text(Fmt.whenText(m.start), style = Type.Small, color = Palette.Sub)
                GameState.POST -> Text(m.status.ifBlank { "Final" }, style = Type.Small, color = Palette.Sub)
            }
        }
        m.players.forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Flag(p.flag, 12.dp)
                Spacer(Modifier.width(8.dp))
                Text(p.name + if (p.seed.isNotBlank()) " (${p.seed})" else "", Modifier.weight(1f), style = Type.BodyStrong,
                    color = if (p.winner) Palette.Text else if (m.state == GameState.POST) Palette.Sub else Palette.Text,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (p.winner) Text("✓ ", style = Type.BodyStrong, color = Palette.Win)
                p.sets.forEach { s -> Text(s, Modifier.width(30.dp), style = Type.Num, color = Palette.Text, textAlign = TextAlign.End) }
            }
        }
    }
}

// ---------- cricket ----------

@Composable
private fun CricketView(s: CricketSeries) {
    val context = LocalContext.current
    Panel {
        Text(s.name, style = Type.Title, color = Palette.Text)
        s.matches.forEach { m ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Palette.Raised)
                .clickable { openUrl(context, m.link) }.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.name.uppercase(), Modifier.weight(1f), style = Type.Label, color = Palette.Faint, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    when (m.state) {
                        GameState.IN -> LiveBadge()
                        GameState.PRE -> Text(Fmt.whenText(m.start), style = Type.Small, color = Palette.Sub)
                        GameState.POST -> Text("FINAL", style = Type.Label, color = Palette.Sub)
                    }
                }
                m.sides.forEach { side ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Logo(side.logo, 24.dp)
                        Spacer(Modifier.width(10.dp))
                        Text(side.name, Modifier.weight(1f), style = Type.BodyStrong, color = if (side.winner) Palette.Gold else Palette.Text,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(side.score, style = Type.Num, color = Palette.Text)
                    }
                }
                if (m.status.isNotBlank()) Sub(m.status, maxLines = 2)
            }
        }
    }
}

// ---------- shared ----------

@Composable
fun StateBadge(state: GameState) {
    when (state) {
        GameState.IN -> LiveBadge()
        GameState.POST -> Tag("FINAL")
        GameState.PRE -> Tag("UPCOMING", Palette.BlueSoft, Color.White)
    }
}

@Composable
private fun WatchLine(league: League, b: List<com.roki.sideline.data.Broadcast>) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { b.take(3).forEach { Tag(it.network, Palette.BlueSoft, Color.White) } }
        Streaming.describe(league, b).firstOrNull()?.let { Sub(it) }
    }
}
