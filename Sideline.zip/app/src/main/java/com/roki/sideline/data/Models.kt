package com.roki.sideline.data

import java.time.Instant

enum class Kind { TEAM, SOCCER, RUGBY, FIGHT, RACE, GOLF, TENNIS, CRICKET }

enum class Category(val title: String) {
    US_PRO("US Pro"),
    SOCCER("Soccer"),
    TOURNAMENTS("International Soccer"),
    COLLEGE("College"),
    COMBAT("Combat"),
    MOTOR("Motorsports"),
    INDIVIDUAL("Golf & Tennis"),
    WORLD("Cricket & Rugby"),
}

data class League(
    val key: String,
    val label: String,
    val short: String,
    val sport: String,
    val slug: String,
    val kind: Kind,
    val category: Category,
    val emoji: String,
    val accent: Long,
    val periodShort: String = "Q",
    val regularPeriods: Int = 4,
    val homeEdge: Double = 0.0,
    val outOfMarket: String? = null,
    val weekly: Boolean = false,
    val injuries: Boolean = false,
    val moves: Boolean = false,
    val standings: Boolean = true,
    val rankings: Boolean = false,
    val allGroups: String? = null,
    val playerStats: Boolean = true,
) {
    val site get() = "https://site.api.espn.com/apis/site/v2/sports/$sport/$slug"
    val standingsUrl get() = "https://site.api.espn.com/apis/v2/sports/$sport/$slug/standings"
    val athleteBase get() = "https://site.web.api.espn.com/apis/common/v3/sports/$sport/$slug/athletes"
    val teamBased get() = kind == Kind.TEAM || kind == Kind.SOCCER || kind == Kind.RUGBY
    val draws get() = kind == Kind.SOCCER || kind == Kind.RUGBY
    /** ESPN keeps a headshot for most athletes even when a feed omits the link; this is where it lives. */
    fun headshotUrl(athleteId: String): String {
        if (athleteId.isBlank()) return ""
        val folder = when (sport) { "soccer" -> "soccer"; "mma" -> "mma"; else -> slug }
        return "https://a.espncdn.com/i/headshots/$folder/players/full/$athleteId.png"
    }
}

object Leagues {
    private const val BLUE = 0xFF2563EB
    val all: List<League> = listOf(
        League("NFL", "NFL", "NFL", "football", "nfl", Kind.TEAM, Category.US_PRO, "🏈", 0xFF1E40AF,
            homeEdge = 0.05, outOfMarket = "NFL Sunday Ticket", weekly = true, injuries = true, moves = true),
        League("NBA", "NBA", "NBA", "basketball", "nba", Kind.TEAM, Category.US_PRO, "🏀", 0xFFDC2626,
            homeEdge = 0.06, outOfMarket = "NBA League Pass", injuries = true, moves = true),
        League("MLB", "MLB", "MLB", "baseball", "mlb", Kind.TEAM, Category.US_PRO, "⚾", 0xFF1D4ED8,
            periodShort = "", regularPeriods = 9, homeEdge = 0.04, outOfMarket = "MLB.TV", injuries = true, moves = true),
        League("NHL", "NHL", "NHL", "hockey", "nhl", Kind.TEAM, Category.US_PRO, "🏒", 0xFF0284C7,
            periodShort = "P", regularPeriods = 3, homeEdge = 0.05, outOfMarket = "ESPN+", injuries = true, moves = true),
        League("WNBA", "WNBA", "WNBA", "basketball", "wnba", Kind.TEAM, Category.US_PRO, "🏀", 0xFFEA580C,
            homeEdge = 0.06, outOfMarket = "WNBA League Pass", injuries = true, moves = true),
        League("UFL", "UFL", "UFL", "football", "ufl", Kind.TEAM, Category.US_PRO, "🏈", 0xFF0369A1,
            homeEdge = 0.04, weekly = true),
        League("EPL", "Premier League", "EPL", "soccer", "eng.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFF6D28D9,
            periodShort = "H", regularPeriods = 2),
        League("MLS", "MLS", "MLS", "soccer", "usa.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFF1E3A8A,
            periodShort = "H", regularPeriods = 2, outOfMarket = "Apple TV (MLS)"),
        League("UCL", "Champions League", "UCL", "soccer", "uefa.champions", Kind.SOCCER, Category.SOCCER, "⭐", 0xFF1D4ED8,
            periodShort = "H", regularPeriods = 2),
        League("LALIGA", "LaLiga", "LaLiga", "soccer", "esp.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFFEF4444,
            periodShort = "H", regularPeriods = 2),
        League("BUNDESLIGA", "Bundesliga", "BUN", "soccer", "ger.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFFDC2626,
            periodShort = "H", regularPeriods = 2),
        League("SERIEA", "Serie A", "Serie A", "soccer", "ita.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFF0284C7,
            periodShort = "H", regularPeriods = 2),
        League("LIGUE1", "Ligue 1", "Ligue 1", "soccer", "fra.1", Kind.SOCCER, Category.SOCCER, "⚽", 0xFF2563EB,
            periodShort = "H", regularPeriods = 2),
        League("WORLDCUP", "FIFA World Cup", "World Cup", "soccer", "fifa.world", Kind.SOCCER, Category.TOURNAMENTS, "🏆", 0xFF9F1239,
            periodShort = "H", regularPeriods = 2),
        League("EURO", "UEFA Euro", "Euro", "soccer", "uefa.euro", Kind.SOCCER, Category.TOURNAMENTS, "🏆", 0xFF1D4ED8,
            periodShort = "H", regularPeriods = 2),
        League("COPA", "Copa América", "Copa", "soccer", "conmebol.america", Kind.SOCCER, Category.TOURNAMENTS, "🏆", 0xFF059669,
            periodShort = "H", regularPeriods = 2),
        League("CFB", "College Football", "CFB", "football", "college-football", Kind.TEAM, Category.COLLEGE, "🏈", 0xFFB45309,
            homeEdge = 0.06, weekly = true, rankings = true, allGroups = "80"),
        League("MCBB", "Men's College Basketball", "NCAAM", "basketball", "mens-college-basketball", Kind.TEAM, Category.COLLEGE, "🏀", 0xFF1D4ED8,
            periodShort = "H", regularPeriods = 2, homeEdge = 0.07, rankings = true, allGroups = "50"),
        League("WCBB", "Women's College Basketball", "NCAAW", "basketball", "womens-college-basketball", Kind.TEAM, Category.COLLEGE, "🏀", 0xFFBE185D,
            homeEdge = 0.07, rankings = true, allGroups = "50"),
        League("UFC", "UFC", "UFC", "mma", "ufc", Kind.FIGHT, Category.COMBAT, "🥊", 0xFFDC2626, standings = false, playerStats = false),
        League("F1", "Formula 1", "F1", "racing", "f1", Kind.RACE, Category.MOTOR, "🏎️", 0xFFEF4444, playerStats = false),
        League("NASCAR", "NASCAR Cup Series", "NASCAR", "racing", "nascar-premier", Kind.RACE, Category.MOTOR, "🏁", 0xFFEAB308, playerStats = false),
        League("INDYCAR", "IndyCar", "IndyCar", "racing", "irl", Kind.RACE, Category.MOTOR, "🏁", BLUE, playerStats = false),
        League("PGA", "PGA Tour", "PGA", "golf", "pga", Kind.GOLF, Category.INDIVIDUAL, "⛳", 0xFF047857, standings = false, playerStats = false),
        League("ATP", "ATP Tour", "ATP", "tennis", "atp", Kind.TENNIS, Category.INDIVIDUAL, "🎾", 0xFF0284C7, standings = false, playerStats = false),
        League("WTA", "WTA Tour", "WTA", "tennis", "wta", Kind.TENNIS, Category.INDIVIDUAL, "🎾", 0xFF7C3AED, standings = false, playerStats = false),
        League("CRICKET", "Cricket (IPL & more)", "Cricket", "cricket", "ipl", Kind.CRICKET, Category.WORLD, "🏏", 0xFF1D4ED8,
            standings = false, playerStats = false),
        League("SIXNATIONS", "Six Nations", "6N", "rugby", "180659", Kind.RUGBY, Category.WORLD, "🏉", 0xFF059669,
            periodShort = "H", regularPeriods = 2, standings = false, playerStats = false),
        League("RWC", "Rugby World Cup", "RWC", "rugby", "164205", Kind.RUGBY, Category.WORLD, "🏉", 0xFF15803D,
            periodShort = "H", regularPeriods = 2, standings = false, playerStats = false),
    )

    val defaultPins = listOf("NFL", "NBA", "MLB", "NHL", "EPL", "UFC", "F1", "CFB")

    fun of(key: String): League? = all.firstOrNull { it.key == key }
}

data class TeamRef(val id: String, val abbr: String, val name: String, val shortName: String = name, val logo: String = "", val color: String = "")
data class Competitor(val team: TeamRef, val home: Boolean, val score: String = "", val winner: Boolean = false, val record: String = "", val linescores: List<String> = emptyList(), val leaders: List<Leader> = emptyList(), val rank: String = "")
data class Leader(val category: String, val athleteId: String, val athleteName: String, val value: String, val headshot: String = "")
data class Broadcast(val network: String, val market: String = "") { val national get() = market.isBlank() || market.equals("national", true) }
data class Odds(val provider: String = "", val details: String = "", val overUnder: String = "", val homeMoneyline: String = "", val awayMoneyline: String = "", val drawMoneyline: String = "")
enum class GameState { PRE, IN, POST }
data class Game(val id: String, val league: League, val start: Instant?, val name: String, val shortName: String, val state: GameState, val statusDetail: String, val statusShort: String, val home: Competitor, val away: Competitor, val venue: String = "", val broadcasts: List<Broadcast> = emptyList(), val odds: Odds? = null, val lastPlay: String = "", val situation: String = "", val note: String = "", val clock: String = "") {
    fun involves(teamId: String) = home.team.id == teamId || away.team.id == teamId
    fun opponentOf(teamId: String) = if (home.team.id == teamId) away else home
    fun sideOf(teamId: String) = if (home.team.id == teamId) home else away
}
data class StandingRow(val team: TeamRef, val stats: Map<String, String>, val note: String = "", val noteColor: String = "")
data class StandingTable(val title: String, val columns: List<Pair<String, String>>, val rows: List<StandingRow>)
data class RankRow(val rank: Int, val previous: Int?, val team: TeamRef, val record: String, val points: String, val firstPlace: String)
data class Ranking(val name: String, val rows: List<RankRow>)
data class Player(val id: String, val name: String, val jersey: String = "", val position: String = "", val positionName: String = "", val group: String = "", val age: String = "", val height: String = "", val weight: String = "", val birthPlace: String = "", val college: String = "", val experience: String = "", val headshot: String = "", val status: String = "", val injuryStatus: String = "", val teamId: String = "", val teamName: String = "", val flag: String = "")
data class Injury(val athleteId: String, val athleteName: String, val position: String, val status: String, val comment: String, val type: String, val returnDate: String, val date: Instant?, val teamId: String, val teamName: String, val teamLogo: String = "", val headshot: String = "")
data class Article(val headline: String, val description: String, val published: Instant?, val image: String, val url: String)
data class Transaction(val date: Instant?, val description: String, val team: TeamRef?)
data class TeamDetail(val team: TeamRef, val record: String, val standingSummary: String, val recordDetails: List<Pair<String, String>>)
data class StatLine(val label: String, val away: String, val home: String)
data class BoxTable(val teamName: String, val title: String, val labels: List<String>, val rows: List<Pair<String, List<String>>>)
data class LineupPlayer(val name: String, val position: String, val jersey: String, val starter: Boolean)
data class GameDetail(val game: Game, val homeWinPct: Double?, val awayWinPct: Double?, val drawPct: Double?, val predictorName: String, val teamStats: List<StatLine>, val leaders: List<Pair<String, List<Leader>>>, val injuries: List<Injury>, val box: List<BoxTable>, val scoringPlays: List<String>, val attendance: String, val seasonSeries: String, val odds: Odds?, val broadcasts: List<Broadcast>, val articleHeadline: String, val lineups: List<Pair<String, List<LineupPlayer>>> = emptyList())
data class StatRow(val label: String, val values: List<String>)
data class PlayerOverview(val labels: List<String>, val rows: List<StatRow>, val news: List<Article>, val injuryNote: String, val nextGame: String)
data class Fighter(val name: String, val record: String, val flag: String, val headshot: String, val winner: Boolean, val id: String = "")
data class Fight(val id: String, val weightClass: String, val state: GameState, val status: String, val start: Instant?, val a: Fighter, val b: Fighter)
data class FightCard(val id: String, val name: String, val start: Instant?, val venue: String, val state: GameState, val broadcasts: List<Broadcast>, val fights: List<Fight>)
data class Finisher(val position: Int, val name: String, val team: String, val number: String, val flag: String, val detail: String, val winner: Boolean)
data class Session(val name: String, val start: Instant?, val state: GameState, val status: String, val results: List<Finisher>, val broadcasts: List<Broadcast>)
data class RaceWeekend(val id: String, val name: String, val circuit: String, val location: String, val start: Instant?, val end: Instant?, val state: GameState, val sessions: List<Session>)
data class GolfPlayer(val position: String, val name: String, val flag: String, val toPar: String, val today: String, val thru: String, val rounds: List<String>)
data class Tournament(val id: String, val name: String, val start: Instant?, val end: Instant?, val venue: String, val state: GameState, val status: String, val players: List<GolfPlayer>, val broadcasts: List<Broadcast>)
data class TennisPlayer(val name: String, val flag: String, val seed: String, val winner: Boolean, val sets: List<String>)
data class TennisMatch(val id: String, val round: String, val start: Instant?, val state: GameState, val status: String, val players: List<TennisPlayer>)
data class TennisEvent(val id: String, val name: String, val start: Instant?, val end: Instant?, val venue: String, val draws: List<Pair<String, List<TennisMatch>>>)
data class CricketSide(val name: String, val abbr: String, val logo: String, val score: String, val winner: Boolean)
data class CricketMatch(val id: String, val name: String, val start: Instant?, val state: GameState, val status: String, val sides: List<CricketSide>, val link: String)
data class CricketSeries(val id: String, val name: String, val matches: List<CricketMatch>)
