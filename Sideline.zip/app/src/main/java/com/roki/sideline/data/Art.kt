package com.roki.sideline.data

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A real, freely licensed photo from Wikimedia Commons (no AI images), with where to find its author and license. */
data class Photo(val file: String, val subject: String) {
    /** Commons serves a resized copy at this address. */
    val url get() = "https://commons.wikimedia.org/wiki/Special:FilePath/" + file.replace(" ", "_") + "?width=1280"
    val page get() = "https://commons.wikimedia.org/wiki/File:" + file.replace(" ", "_")
}

object Art {
    private val football = Photo("Neyland Stadium night.jpg", "Neyland Stadium at night, Knoxville")
    private val collegeFootball = Photo("Kinnick Night.jpg", "Kinnick Stadium at night, Iowa City")
    private val basketball = Photo("NBA basketball, Raptors in Phoenix.jpg", "Raptors at the Suns, Phoenix")
    private val collegeHoops = Photo("Gonzaga McCarthy Athletic Center Arena.jpg", "McCarthey Athletic Center, Spokane")
    private val baseball = Photo("Citi Field Night Game.jpg", "Night game at Citi Field, New York")
    private val hockey = Photo("Ice Hockey Game - Madison Square Garden - Boston vs New York.jpg", "Bruins at Rangers, Madison Square Garden")
    private val soccer = Photo("Etihad Stadium, Manchester City Football Club (Ank Kumar, Infosys) 16.jpg", "Etihad Stadium, Manchester")
    private val mls = Photo("Snapdragon Stadium interior-Night panorama view 1.jpg", "Snapdragon Stadium at night, San Diego")
    private val f1 = Photo("F1 Circuit Zandvoort motorsport race track in the Netherlands (47980288626).jpg", "Circuit Zandvoort, Netherlands")
    private val nascar = Photo("Nascar Green Flag and Sonoma Raceway 2 photo Don Ramey Logan.jpg", "Green flag at Sonoma Raceway")
    private val golf = Photo("Putting green at the Royal Canberra Golf Club 4.JPG", "Putting green, Royal Canberra Golf Club")
    private val tennis = Photo("Roland Garros Stadium in 2007.jpg", "Roland Garros, Paris")
    private val cricket = Photo("Wankhede stadium.jpg", "Wankhede Stadium, Mumbai")
    private val rugby = Photo("Scotland vs Wales 2015 Six Nations.jpg", "Scotland v Wales, Six Nations 2015")
    private val ufc = Photo("UFC-Octagon-USMCPhoto.jpg", "The UFC octagon (U.S. Marine Corps photo)")

    val all = listOf(football, collegeFootball, basketball, collegeHoops, baseball, hockey, soccer, mls, f1, nascar, golf,
        tennis, cricket, rugby, ufc)

    fun photoFor(l: League): Photo = when {
        l.key == "CFB" -> collegeFootball
        l.key == "MCBB" || l.key == "WCBB" -> collegeHoops
        l.key == "MLS" -> mls
        l.key == "F1" || l.key == "INDYCAR" -> f1
        l.key == "NASCAR" -> nascar
        l.sport == "football" -> football
        l.sport == "basketball" -> basketball
        l.sport == "baseball" -> baseball
        l.sport == "hockey" -> hockey
        l.sport == "soccer" -> soccer
        l.sport == "golf" -> golf
        l.sport == "tennis" -> tennis
        l.sport == "cricket" -> cricket
        l.sport == "rugby" -> rugby
        l.sport == "mma" -> ufc
        else -> football
    }

    fun photoFor(c: Category): Photo = when (c) {
        Category.US_PRO -> football
        Category.SOCCER -> soccer
        Category.TOURNAMENTS -> soccer
        Category.COLLEGE -> collegeFootball
        Category.COMBAT -> ufc
        Category.MOTOR -> f1
        Category.INDIVIDUAL -> golf
        Category.WORLD -> cricket
    }

    // ---------- official league logos, from ESPN's league records ----------

    val logos = mutableStateMapOf<String, String>()
    private val asked = HashSet<String>()

    suspend fun logo(context: Context, l: League): String? {
        logos[l.key]?.let { return it }
        val prefs = context.applicationContext.getSharedPreferences("sideline_logos", Context.MODE_PRIVATE)
        prefs.getString(l.key, null)?.let { withContext(Dispatchers.Main) { logos[l.key] = it }; return it }
        synchronized(asked) { if (!asked.add(l.key)) return null }
        if (l.kind == Kind.CRICKET) return null
        fun pick(logos: org.json.JSONArray?): String? {
            logos ?: return null
            val list = (0 until logos.length()).mapNotNull { logos.optJSONObject(it) }
            fun rels(o: org.json.JSONObject) = o.optJSONArray("rel")?.let { r -> (0 until r.length()).map { r.optString(it) } } ?: emptyList()
            return (list.firstOrNull { "dark" in rels(it) } ?: list.firstOrNull { "default" in rels(it) } ?: list.firstOrNull())
                ?.optString("href")?.takeIf { it.isNotBlank() }
        }
        val week = 7 * 24 * 3600_000L
        // 1. ESPN's league record. 2. The league's scoreboard header (racing, golf and tennis keep their logo there).
        val url = runCatching {
            pick(Espn.get("https://sports.core.api.espn.com/v2/sports/${l.sport}/leagues/${l.slug}", week).optJSONArray("logos"))
        }.getOrNull() ?: runCatching {
            pick(Espn.get(l.site + "/scoreboard", week).optJSONArray("leagues")?.optJSONObject(0)?.optJSONArray("logos"))
        }.getOrNull()
        if (url == null) {
            // 3. ESPN's static league-logo folder; not saved, so a real link can still replace it later.
            val fallback = "https://a.espncdn.com/i/teamlogos/leagues/500/${l.slug}.png"
            withContext(Dispatchers.Main) { logos[l.key] = fallback }
            return fallback
        }
        prefs.edit().putString(l.key, url).apply()
        withContext(Dispatchers.Main) { logos[l.key] = url }
        return url
    }
}
