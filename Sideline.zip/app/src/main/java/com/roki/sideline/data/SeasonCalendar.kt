package com.roki.sideline.data

import android.Manifest
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Puts a team's upcoming games into the phone's own calendar. Each game's event id is remembered, so running it
 * again moves events whose time changed instead of adding copies, and "remove" deletes exactly what Sideline added.
 * Nothing leaves the phone.
 */
object SeasonCalendar {
    val permissions = arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)
    private const val THREE_HOURS = 3 * 3600_000L

    fun allowed(context: Context) = permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }

    private fun key(league: League, team: TeamRef) = "cal:${league.key}:${team.id}"

    private fun saved(context: Context, league: League, team: TeamRef): MutableMap<String, Long> {
        val raw = Favorites.prefs(context).getString(key(league, team), null) ?: return mutableMapOf()
        val out = mutableMapOf<String, Long>()
        runCatching {
            val o = JSONObject(raw)
            o.keys().forEach { k -> o.optLong(k, -1L).takeIf { it >= 0 }?.let { out[k] = it } }
        }
        return out
    }

    private fun save(context: Context, league: League, team: TeamRef, map: Map<String, Long>) {
        val e = Favorites.prefs(context).edit()
        if (map.isEmpty()) e.remove(key(league, team))
        else e.putString(key(league, team), JSONObject().also { o -> map.forEach { (k, v) -> o.put(k, v) } }.toString())
        e.apply()
    }

    fun isAdded(context: Context, league: League, team: TeamRef) = Favorites.prefs(context).contains(key(league, team))

    /** The calendar to write to: the phone's primary one if it can be written, otherwise the first writable, visible one. */
    private fun calendarId(context: Context): Long? {
        val cols = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
        val sel = "${CalendarContract.Calendars.VISIBLE} = 1 AND ${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ${CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR}"
        val found = ArrayList<Pair<Long, Boolean>>()
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, cols, sel, null, null)?.use { c ->
            while (c.moveToNext()) found.add(c.getLong(0) to (c.getInt(1) == 1))
        }
        return (found.firstOrNull { it.second } ?: found.firstOrNull())?.first
    }

    /** Event title from the team's point of view: "Suns vs Lakers" at home, "Suns at Lakers" away. */
    fun title(g: Game, team: TeamRef): String {
        val me = g.sideOf(team.id)
        val opp = g.opponentOf(team.id)
        return "${g.league.short}: ${me.team.shortName} ${if (me.home) "vs" else "at"} ${opp.team.shortName}"
    }

    /** Games worth adding: not finished, with a known start. */
    fun upcoming(games: List<Game>) = games.filter { it.state == GameState.PRE && it.start != null }

    data class Result(val added: Int, val updated: Int)

    /** Add or update every upcoming game. Returns how many were added and how many moved or refreshed. */
    fun sync(context: Context, league: League, team: TeamRef, games: List<Game>): Result {
        val cal = calendarId(context) ?: error("No calendar on this phone can be written to.")
        val map = saved(context, league, team)
        var added = 0
        var updated = 0
        upcoming(games).forEach { g ->
            val start = g.start!!.toEpochMilli()
            val tv = g.broadcasts.joinToString(", ") { it.network }
            val v = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, cal)
                put(CalendarContract.Events.DTSTART, start)
                put(CalendarContract.Events.DTEND, start + THREE_HOURS)
                put(CalendarContract.Events.EVENT_TIMEZONE, "UTC")
                put(CalendarContract.Events.TITLE, title(g, team))
                put(CalendarContract.Events.EVENT_LOCATION, g.venue)
                put(CalendarContract.Events.DESCRIPTION, listOf(if (tv.isNotBlank()) "TV: $tv" else "", "Added by Sideline").filter { it.isNotBlank() }.joinToString("\n"))
            }
            val existing = map[g.id]
            val changed = existing != null &&
                context.contentResolver.update(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, existing), v, null, null) > 0
            if (changed) updated++ else {
                // Not added yet, or the user deleted it from the calendar: add it fresh.
                context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v)?.let { uri ->
                    map[g.id] = ContentUris.parseId(uri)
                    added++
                }
            }
        }
        save(context, league, team, map)
        Favorites.prefs(context).edit().putLong(key(league, team) + ":at", System.currentTimeMillis()).apply()
        return Result(added, updated)
    }

    /** True when the team was added more than a day ago, so the schedule page can refresh times quietly. */
    fun stale(context: Context, league: League, team: TeamRef): Boolean =
        isAdded(context, league, team) && System.currentTimeMillis() - Favorites.prefs(context).getLong(key(league, team) + ":at", 0) > 24 * 3600_000L

    /** Delete every event Sideline added for this team. */
    fun remove(context: Context, league: League, team: TeamRef): Int {
        var n = 0
        saved(context, league, team).values.forEach { id ->
            n += runCatching { context.contentResolver.delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), null, null) }.getOrDefault(0)
        }
        save(context, league, team, emptyMap())
        return n
    }
}
