package com.roki.sideline.data

import java.time.Instant
import java.time.ZoneId
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** A pro sports metro area: where it is, its time zone, and how team names start there. */
data class Metro(val key: String, val name: String, val lat: Double, val lon: Double, val zone: String, val keys: List<String>)

/**
 * Geography for TV markets and venue clocks. Team TV territories are approximated as a radius around the team's
 * metro; real territories vary, so the app says "area" rather than promising a channel.
 */
object Places {
    val metros = listOf(
        Metro("PHX", "Phoenix", 33.45, -112.07, "America/Phoenix", listOf("Arizona", "Phoenix")),
        Metro("LA", "Los Angeles", 34.05, -118.24, "America/Los_Angeles", listOf("Los Angeles", "LAFC", "Anaheim", "LA")),
        Metro("SD", "San Diego", 32.72, -117.16, "America/Los_Angeles", listOf("San Diego")),
        Metro("SF", "San Francisco Bay Area", 37.77, -122.42, "America/Los_Angeles", listOf("San Francisco", "Golden State", "Oakland", "San Jose", "Bay Area")),
        Metro("SAC", "Sacramento", 38.58, -121.49, "America/Los_Angeles", listOf("Sacramento")),
        Metro("LV", "Las Vegas", 36.17, -115.14, "America/Los_Angeles", listOf("Las Vegas", "Vegas")),
        Metro("SEA", "Seattle", 47.61, -122.33, "America/Los_Angeles", listOf("Seattle")),
        Metro("POR", "Portland", 45.52, -122.68, "America/Los_Angeles", listOf("Portland")),
        Metro("SLC", "Salt Lake City", 40.76, -111.89, "America/Denver", listOf("Utah", "Salt Lake")),
        Metro("DEN", "Denver", 39.74, -104.99, "America/Denver", listOf("Denver", "Colorado")),
        Metro("DAL", "Dallas–Fort Worth", 32.78, -96.80, "America/Chicago", listOf("Dallas", "Texas", "Arlington", "Fort Worth")),
        Metro("HOU", "Houston", 29.76, -95.37, "America/Chicago", listOf("Houston")),
        Metro("AUS", "Austin", 30.27, -97.74, "America/Chicago", listOf("Austin")),
        Metro("SA", "San Antonio", 29.42, -98.49, "America/Chicago", listOf("San Antonio")),
        Metro("OKC", "Oklahoma City", 35.47, -97.52, "America/Chicago", listOf("Oklahoma City")),
        Metro("KC", "Kansas City", 39.10, -94.58, "America/Chicago", listOf("Kansas City")),
        Metro("MIN", "Minneapolis–St. Paul", 44.98, -93.27, "America/Chicago", listOf("Minnesota", "Minneapolis")),
        Metro("CHI", "Chicago", 41.88, -87.63, "America/Chicago", listOf("Chicago")),
        Metro("MIL", "Milwaukee", 43.04, -87.91, "America/Chicago", listOf("Milwaukee")),
        Metro("GB", "Green Bay", 44.51, -88.02, "America/Chicago", listOf("Green Bay")),
        Metro("STL", "St. Louis", 38.63, -90.20, "America/Chicago", listOf("St. Louis", "St Louis")),
        Metro("NSH", "Nashville", 36.16, -86.78, "America/Chicago", listOf("Nashville", "Tennessee")),
        Metro("MEM", "Memphis", 35.15, -90.05, "America/Chicago", listOf("Memphis")),
        Metro("NO", "New Orleans", 29.95, -90.07, "America/Chicago", listOf("New Orleans")),
        Metro("BHM", "Birmingham", 33.52, -86.80, "America/Chicago", listOf("Birmingham")),
        Metro("WPG", "Winnipeg", 49.90, -97.14, "America/Winnipeg", listOf("Winnipeg")),
        Metro("DET", "Detroit", 42.33, -83.05, "America/Detroit", listOf("Detroit", "Michigan")),
        Metro("IND", "Indianapolis", 39.77, -86.16, "America/Indiana/Indianapolis", listOf("Indiana", "Indianapolis")),
        Metro("CLE", "Cleveland", 41.50, -81.69, "America/New_York", listOf("Cleveland")),
        Metro("CIN", "Cincinnati", 39.10, -84.51, "America/New_York", listOf("Cincinnati")),
        Metro("CBUS", "Columbus", 39.96, -83.00, "America/New_York", listOf("Columbus")),
        Metro("PIT", "Pittsburgh", 40.44, -79.99, "America/New_York", listOf("Pittsburgh")),
        Metro("ATL", "Atlanta", 33.75, -84.39, "America/New_York", listOf("Atlanta")),
        Metro("CHA", "Charlotte", 35.23, -80.84, "America/New_York", listOf("Charlotte", "Carolina")),
        Metro("JAX", "Jacksonville", 30.33, -81.66, "America/New_York", listOf("Jacksonville")),
        Metro("TB", "Tampa Bay", 27.95, -82.46, "America/New_York", listOf("Tampa Bay", "Tampa")),
        Metro("ORL", "Orlando", 28.54, -81.38, "America/New_York", listOf("Orlando")),
        Metro("MIA", "Miami", 25.76, -80.19, "America/New_York", listOf("Miami", "Florida")),
        Metro("WAS", "Washington, D.C.", 38.91, -77.04, "America/New_York", listOf("Washington", "D.C.", "DC")),
        Metro("BAL", "Baltimore", 39.29, -76.61, "America/New_York", listOf("Baltimore")),
        Metro("PHI", "Philadelphia", 39.95, -75.17, "America/New_York", listOf("Philadelphia")),
        Metro("NY", "New York", 40.71, -74.01, "America/New_York", listOf("New York", "Brooklyn", "New Jersey")),
        Metro("CT", "Hartford", 41.76, -72.67, "America/New_York", listOf("Connecticut")),
        Metro("BOS", "Boston", 42.36, -71.06, "America/New_York", listOf("Boston", "New England")),
        Metro("BUF", "Buffalo", 42.89, -78.88, "America/New_York", listOf("Buffalo")),
        Metro("TOR", "Toronto", 43.65, -79.38, "America/Toronto", listOf("Toronto")),
        Metro("OTT", "Ottawa", 45.42, -75.70, "America/Toronto", listOf("Ottawa")),
        Metro("MTL", "Montréal", 45.50, -73.57, "America/Toronto", listOf("Montréal", "Montreal")),
        Metro("CGY", "Calgary", 51.05, -114.07, "America/Edmonton", listOf("Calgary")),
        Metro("EDM", "Edmonton", 53.55, -113.49, "America/Edmonton", listOf("Edmonton")),
        Metro("VAN", "Vancouver", 49.28, -123.12, "America/Vancouver", listOf("Vancouver")),
    )

    private val prefixes = listOf("FC ", "CF ", "Inter ", "Sporting ", "Real ")

    /** The metro a (North American pro) team plays in, from how its name starts. */
    fun metroFor(team: TeamRef, league: League): Metro? {
        if (league.category != Category.US_PRO && league.key != "MLS") return null
        var n = team.name.trim()
        prefixes.forEach { if (n.startsWith(it)) n = n.removePrefix(it) }
        return metros.flatMap { m -> m.keys.map { k -> k.trim() to m } }
            .sortedByDescending { it.first.length }
            .firstOrNull { (k, _) -> n.startsWith(k) && (n.length == k.length || !n[k.length].isLetter()) }?.second
    }

    fun km(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    /** Roughly how far a team's local TV reaches. Baseball territories are the biggest. */
    fun marketRadiusKm(league: League): Double = when (league.sport) {
        "baseball" -> 450.0
        else -> 320.0
    }

    fun inMarket(place: UserPlace?, team: TeamRef, league: League): Boolean? {
        place ?: return null
        val m = metroFor(team, league) ?: return null
        return km(place.lat, place.lon, m.lat, m.lon) <= marketRadiusKm(league)
    }

    fun nearestMetro(lat: Double, lon: Double): Metro? = metros.minByOrNull { km(lat, lon, it.lat, it.lon) }

    private val leagueZones = mapOf(
        "EPL" to "Europe/London", "LALIGA" to "Europe/Madrid", "BUNDESLIGA" to "Europe/Berlin",
        "SERIEA" to "Europe/Rome", "LIGUE1" to "Europe/Paris", "SIXNATIONS" to "Europe/London",
    )

    private val countryZones = mapOf(
        "england" to "Europe/London", "united kingdom" to "Europe/London", "uk" to "Europe/London", "great britain" to "Europe/London",
        "scotland" to "Europe/London", "wales" to "Europe/London", "ireland" to "Europe/Dublin", "spain" to "Europe/Madrid",
        "germany" to "Europe/Berlin", "italy" to "Europe/Rome", "france" to "Europe/Paris", "netherlands" to "Europe/Amsterdam",
        "portugal" to "Europe/Lisbon", "belgium" to "Europe/Brussels", "austria" to "Europe/Vienna", "hungary" to "Europe/Budapest",
        "monaco" to "Europe/Monaco", "switzerland" to "Europe/Zurich", "sweden" to "Europe/Stockholm", "turkey" to "Europe/Istanbul",
        "mexico" to "America/Mexico_City", "brazil" to "America/Sao_Paulo", "argentina" to "America/Argentina/Buenos_Aires",
        "japan" to "Asia/Tokyo", "china" to "Asia/Shanghai", "singapore" to "Asia/Singapore", "india" to "Asia/Kolkata",
        "qatar" to "Asia/Qatar", "saudi arabia" to "Asia/Riyadh", "bahrain" to "Asia/Bahrain", "azerbaijan" to "Asia/Baku",
        "united arab emirates" to "Asia/Dubai", "uae" to "Asia/Dubai", "abu dhabi" to "Asia/Dubai", "australia" to "Australia/Melbourne",
        "new zealand" to "Pacific/Auckland", "south africa" to "Africa/Johannesburg", "korea" to "Asia/Seoul", "south korea" to "Asia/Seoul",
        "canada" to "America/Toronto", "chile" to "America/Santiago", "colombia" to "America/Bogota",
    )

    /** Time zone from a free-text place like "Mexico City, Mexico" or "Chiba, Japan". */
    fun zoneFromPlace(text: String): ZoneId? {
        val parts = text.split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }
        parts.asReversed().forEach { p -> countryZones[p]?.let { return runCatching { ZoneId.of(it) }.getOrNull() } }
        metros.firstOrNull { m -> parts.any { it.contains(m.name.lowercase()) } }?.let { return ZoneId.of(it.zone) }
        return null
    }

    /** The clock at the venue: the league's home country, the home team's metro, or the venue's address. */
    fun venueZone(g: Game): ZoneId? {
        leagueZones[g.league.key]?.let { return ZoneId.of(it) }
        metroFor(g.home.team, g.league)?.let { return ZoneId.of(it.zone) }
        return if (g.venue.isNotBlank()) zoneFromPlace(g.venue) else null
    }

    /** True when the venue's clock reads differently from yours at that moment. */
    fun differs(zone: ZoneId?, at: Instant?): Boolean {
        if (zone == null || at == null) return false
        return zone.rules.getOffset(at) != Fmt.zone().rules.getOffset(at)
    }
}
