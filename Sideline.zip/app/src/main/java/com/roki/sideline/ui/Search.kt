package com.roki.sideline.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Espn
import com.roki.sideline.data.FollowedPlayer
import com.roki.sideline.data.League
import com.roki.sideline.data.Leagues
import com.roki.sideline.data.More
import com.roki.sideline.data.Player
import com.roki.sideline.data.PlayerHit
import com.roki.sideline.data.TeamRef
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay

/** Every team in every team-sport league, loaded once per session (ESPN's team lists are cached a day). */
private object TeamIndex {
    @Volatile var teams: List<Pair<League, TeamRef>> = emptyList()

    suspend fun load(): List<Pair<League, TeamRef>> {
        if (teams.isNotEmpty()) return teams
        teams = coroutineScope {
            Leagues.all.filter { it.teamBased }.map { l ->
                async { runCatching { Espn.teams(l).map { l to it } }.getOrDefault(emptyList()) }
            }.awaitAll().flatten()
        }
        return teams
    }
}

/** One box for leagues, teams and players. */
@Composable
fun SearchScreen() {
    val nav = LocalNav.current
    var q by rememberSaveable { mutableStateOf("") }
    var teams by remember { mutableStateOf(TeamIndex.teams) }
    var players by remember { mutableStateOf<List<PlayerHit>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { teams = TeamIndex.load() }
    LaunchedEffect(q) {
        players = emptyList()
        if (q.trim().length < 3) return@LaunchedEffect
        delay(350) // wait for typing to pause
        searching = true
        players = runCatching { Espn.searchPlayers(q) }.getOrDefault(emptyList())
        searching = false
    }
    val t = q.trim()
    val leagueHits = if (t.length < 2) emptyList() else Leagues.all.filter {
        it.label.contains(t, true) || it.short.contains(t, true) || it.key.contains(t, true)
    }
    val teamHits = More.matchTeams(t, teams)
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            label = { Text("Search teams, players, leagues") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (t.length < 2) item { Sub("Type at least two letters. Try a team, a city, a player or a league.") }
            if (leagueHits.isNotEmpty()) {
                item { SectionHeader("Leagues") }
                items(leagueHits) { l ->
                    Panel(padding = 12.dp, onClick = { nav.league(l) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LeagueMark(l, 34.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(l.label, style = Type.BodyStrong, color = Palette.Text)
                        }
                    }
                }
            }
            if (teamHits.isNotEmpty()) {
                item { SectionHeader("Teams") }
                items(teamHits) { (l, team) ->
                    Panel(padding = 12.dp, onClick = { nav.team(l, team) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Logo(team.logo, 32.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(team.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Sub(l.label)
                            }
                        }
                    }
                }
            }
            val usable = players.filter { it.league != null }
            if (usable.isNotEmpty()) {
                item { SectionHeader("Players") }
                items(usable) { h ->
                    Panel(padding = 12.dp, onClick = { nav.player(h.league!!, Player(h.id, h.name, headshot = h.headshot, teamName = h.detail)) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Headshot(h.headshot, 40.dp, name = h.name)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(h.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Sub(listOf(h.detail, h.league!!.short).filter { it.isNotBlank() }.joinToString(" · "), maxLines = 1)
                            }
                        }
                    }
                }
            } else if (searching) item { Sub("Looking up players…") }
            if (t.length >= 2 && leagueHits.isEmpty() && teamHits.isEmpty() && usable.isEmpty() && !searching) {
                if (teams.isEmpty()) item { Sub("Loading teams…") }
                else if (t.length >= 3) item { EmptyState("🔎", "Nothing found for \"$t\"") }
            }
        }
    }
}

private object PlayerCards { val map = java.util.concurrent.ConcurrentHashMap<String, com.roki.sideline.data.PlayerOverview>() }

/** A card for a followed player on Home: photo, team, season line and the latest news. */
@Composable
fun PlayerCard(fp: FollowedPlayer, reload: Int, modifier: Modifier = Modifier) {
    val nav = LocalNav.current
    val p = fp.player
    Panel(modifier, onClick = { nav.player(fp.league, p) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Headshot(p.headshot, 48.dp, name = p.name)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${fp.league.emoji} ${fp.league.short}".uppercase(), style = Type.Label, color = Palette.Sub)
                Text(p.name, style = Type.Heading, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (p.teamName.isNotBlank()) Sub(p.teamName, maxLines = 1)
            }
            Text("★", Modifier.padding(6.dp), style = Type.Title, color = Palette.Gold)
        }
        Loaded(
            key = "pc:${fp.key}:$reload",
            load = { Espn.athlete(fp.league, p.id).also { PlayerCards.map[fp.key] = it } },
            skeletonRows = 0,
            cached = { PlayerCards.map[fp.key] },
        ) { o, _ ->
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                o.rows.firstOrNull()?.let { r ->
                    val pairs = o.labels.zip(r.values).take(5)
                    if (pairs.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        pairs.forEach { (k, v) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(v, style = Type.BodyStrong, color = Palette.Text)
                                Text(k, style = Type.Label, color = Palette.Faint)
                            }
                        }
                    }
                    Sub(r.label, maxLines = 1)
                }
                if (o.injuryNote.isNotBlank()) Sub("🩹 " + o.injuryNote, maxLines = 2)
                if (o.nextGame.isNotBlank()) Sub("Next: " + o.nextGame, maxLines = 1)
                o.news.firstOrNull()?.let { a ->
                    Text(
                        a.headline,
                        style = Type.Body,
                        color = Palette.Text,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
