package com.roki.sideline.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.BaseballLive
import com.roki.sideline.data.FootballLive
import com.roki.sideline.data.Formation
import com.roki.sideline.data.Game
import com.roki.sideline.data.LivePlayer
import com.roki.sideline.data.Pitch
import com.roki.sideline.data.PitchKind
import com.roki.sideline.data.Shot

private val Grass = Color(0xFF1E5631)
private val GrassDark = Color(0xFF184A29)
private val Chalk = Color.White.copy(alpha = 0.75f)
private val BallColor = Color(0xFF34D399)
private val StrikeColor = Color(0xFFF87171)
private val InPlayColor = Color(0xFF60A5FA)

private fun kindColor(k: PitchKind) = when (k) {
    PitchKind.BALL -> BallColor
    PitchKind.STRIKE -> StrikeColor
    PitchKind.IN_PLAY -> InPlayColor
}

// ---------- baseball ----------

@Composable
private fun CountDots(label: String, filled: Int, total: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(18.dp), style = Type.Label, color = Palette.Sub)
        repeat(total) { i ->
            Box(
                Modifier
                    .padding(end = 5.dp)
                    .size(11.dp)
                    .clip(CircleShape)
                    .background(if (i < filled) color else Color.Transparent)
                    .border(1.5.dp, if (i < filled) color else Palette.Faint, CircleShape)
            )
        }
    }
}

/** The infield from above: three bases, gold when a runner is on. */
@Composable
private fun Diamond(first: Boolean, second: Boolean, third: Boolean) {
    val on = Palette.Gold
    val off = Palette.Raised2
    val line = Palette.Faint
    Canvas(Modifier.size(64.dp)) {
        val w = size.width
        val b = w * 0.17f
        fun base(cx: Float, cy: Float, filled: Boolean) {
            // a square turned 45 degrees
            val path = Path().apply {
                moveTo(cx, cy - b); lineTo(cx + b, cy); lineTo(cx, cy + b); lineTo(cx - b, cy); close()
            }
            drawPath(path, if (filled) on else off)
            drawPath(path, if (filled) on else line, style = Stroke(width = 3f))
        }
        base(w / 2, b + 2, second)
        base(w - b - 2, w / 2, first)
        base(b + 2, w / 2, third)
    }
}

@Composable
private fun MatchupRow(p: LivePlayer, role: String, alignEnd: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = if (alignEnd) Arrangement.End else Arrangement.Start) {
        if (!alignEnd) { Headshot(p.headshot, 40.dp, name = p.name); Spacer(Modifier.width(8.dp)) }
        Column(horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start) {
            Text(p.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(listOf(role, p.pos, p.line).filter { it.isNotBlank() }.joinToString(" · "), style = Type.Small, color = Palette.Sub, maxLines = 1)
        }
        if (alignEnd) { Spacer(Modifier.width(8.dp)); Headshot(p.headshot, 40.dp, name = p.name) }
    }
}

/** Where to draw the strike zone, in ESPN's pitch coordinates, and whether it came from this game's called strikes. */
private data class Zone(val left: Double, val right: Double, val top: Double, val bottom: Double, val calibrated: Boolean)

private fun zoneFor(b: BaseballLive): Zone {
    fun pct(v: List<Double>, p: Double) = v.sorted()[((v.size - 1) * p).toInt()]
    val called = b.calledStrikes
    if (called.size >= 6) {
        val xs = called.map { it.first }
        val ys = called.map { it.second }
        return Zone(pct(xs, 0.1), pct(xs, 0.9), pct(ys, 0.1), pct(ys, 0.9), true)
    }
    // Not enough called strikes yet: centre a typical-size zone on this game's pitches.
    val pts = called + b.pitches.map { it.x to it.y }
    val cx = if (pts.isEmpty()) 117.5 else pts.map { it.first }.sorted()[pts.size / 2]
    val cy = if (pts.isEmpty()) 170.0 else pts.map { it.second }.sorted()[pts.size / 2]
    return Zone(cx - 20, cx + 20, cy - 24, cy + 24, false)
}

/** The live at-bat: count, outs, runners, pitcher against batter, and every pitch so far on the strike zone. */
fun countSummary(b: BaseballLive): String {
    val runners = listOfNotNull("first".takeIf { b.first }, "second".takeIf { b.second }, "third".takeIf { b.third })
    val on = when (runners.size) {
        0 -> "Bases empty"
        3 -> "Bases loaded"
        else -> "Runner" + (if (runners.size > 1) "s" else "") + " on " + runners.joinToString(" and ")
    }
    fun n(k: Int, word: String) = "$k $word" + if (k == 1) "" else "s"
    return "${n(b.balls, "ball")}, ${n(b.strikes, "strike")}, ${n(b.outs, "out")}. $on."
}

fun pitchSummary(pitches: List<Pitch>): String =
    "Pitches this at bat: " + pitches.joinToString("; ") { p ->
        listOf("${p.n}", p.type, p.mph.takeIf { it.isNotBlank() }?.let { "$it mph" }, p.result).filterNot { it.isNullOrBlank() }.joinToString(", ")
    }

@Composable
fun BaseballLiveView(g: Game, b: BaseballLive) {
    if (b.betweenInnings) { InningBreakView(g, b); return }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("At bat")
        Row(Modifier.clearAndSetSemantics { contentDescription = countSummary(b) }, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                CountDots("B", b.balls, 3, BallColor)
                CountDots("S", b.strikes, 2, StrikeColor)
                CountDots("O", b.outs, 2, Palette.Gold)
            }
            Diamond(b.first, b.second, b.third)
        }
        b.pitcher?.let { MatchupRow(it, "Pitching", alignEnd = false) }
        b.batter?.let { MatchupRow(it, "At bat", alignEnd = true) }
        if (b.fielders.isNotEmpty()) {
            val team = if (b.fieldingTeamId == g.home.team.id) g.home.team else g.away.team
            FieldView(b.fielders, team.abbr)
        }
        if (b.pitches.isNotEmpty()) {
            val zone = zoneFor(b)
            val zw = zone.right - zone.left
            val zh = zone.bottom - zone.top
            // Show a margin around the zone, widened if any pitch landed further out.
            val minX = minOf(zone.left - zw * 0.9, b.pitches.minOf { it.x } - 6)
            val maxX = maxOf(zone.right + zw * 0.9, b.pitches.maxOf { it.x } + 6)
            val minY = minOf(zone.top - zh * 0.6, b.pitches.minOf { it.y } - 6)
            val maxY = maxOf(zone.bottom + zh * 0.6, b.pitches.maxOf { it.y } + 6)
            val boxW = 180f
            val boxH = 200f
            fun px(x: Double) = ((x - minX) / (maxX - minX) * boxW).toFloat()
            fun py(y: Double) = ((y - minY) / (maxY - minY) * boxH).toFloat()
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(boxW.dp, boxH.dp).clip(RoundedCornerShape(12.dp)).background(Palette.Raised)
                        .clearAndSetSemantics { contentDescription = pitchSummary(b.pitches) }
                ) {
                    val line = Palette.Sub
                    Canvas(Modifier.fillMaxSize()) {
                        val sx = size.width / boxW
                        val l = px(zone.left) * sx
                        val r = px(zone.right) * sx
                        val t = py(zone.top) * sx
                        val bt = py(zone.bottom) * sx
                        drawRect(line, topLeft = Offset(l, t), size = Size(r - l, bt - t), style = Stroke(width = 3f))
                        for (k in 1..2) {
                            val x = l + (r - l) * k / 3
                            val y = t + (bt - t) * k / 3
                            drawLine(line.copy(alpha = 0.35f), Offset(x, t), Offset(x, bt), strokeWidth = 1.5f)
                            drawLine(line.copy(alpha = 0.35f), Offset(l, y), Offset(r, y), strokeWidth = 1.5f)
                        }
                    }
                    b.pitches.forEach { p ->
                        Box(
                            Modifier
                                .offset((px(p.x) - 11).dp, (py(p.y) - 11).dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(kindColor(p.kind))
                                .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text("${p.n}", style = Type.Caption, color = Color(0xFF0B0F14)) }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    b.pitches.asReversed().forEach { p ->
                        Row(verticalAlignment = Alignment.Top) {
                            Box(Modifier.padding(top = 3.dp).size(10.dp).clip(CircleShape).background(kindColor(p.kind)))
                            Spacer(Modifier.width(6.dp))
                            Column {
                                Text("${p.n}. ${p.result}", style = Type.Small, color = Palette.Text, maxLines = 2)
                                val info = listOf(p.type, if (p.mph.isNotBlank()) "${p.mph} mph" else "").filter { it.isNotBlank() }.joinToString(" · ")
                                if (info.isNotBlank()) Text(info, style = Type.Small, color = Palette.Faint, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
        if (b.onDeck.isNotBlank()) Text("On deck: ${b.onDeck}", style = Type.Small, color = Palette.Sub)
        if (g.lastPlay.isNotBlank()) Text(g.lastPlay, style = Type.Body, color = Palette.Text)
    }
}

/** Between half innings: who's taking the field, where everyone stands, and the next three batters. */
@Composable
private fun InningBreakView(g: Game, b: BaseballLive) {
    val fielding = if (b.fieldingTeamId == g.home.team.id) g.home.team else g.away.team
    val batting = if (fielding.id == g.home.team.id) g.away.team else g.home.team
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("${fielding.shortName} taking the field")
        if (b.fielders.isNotEmpty()) FieldView(b.fielders, fielding.abbr)
        if (b.dueUp.isNotEmpty()) {
            Row(Modifier.semantics { heading() }, verticalAlignment = Alignment.CenterVertically) {
                Logo(batting.logo, 24.dp)
                Spacer(Modifier.width(8.dp))
                Text("Due up", style = Type.Title, color = Palette.Text)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                b.dueUp.forEach { p ->
                    Column(
                        Modifier.weight(1f).clearAndSetSemantics {
                            contentDescription = listOf(p.name, p.pos, p.line).filter { it.isNotBlank() }.joinToString(", ")
                        }
                    ) {
                        Text(
                            p.name + if (p.pos.isNotBlank()) " ${p.pos}" else "",
                            style = Type.Label, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        if (p.line.isNotBlank()) Text(p.line, style = Type.Small, color = Palette.Sub, maxLines = 1)
                    }
                }
            }
        }
        if (g.lastPlay.isNotBlank()) Text(g.lastPlay, style = Type.Body, color = Palette.Text)
    }
}

// ---------- football ----------

@Composable
private fun Timeouts(n: Int?) {
    if (n == null) return
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(3) { i -> Box(Modifier.size(width = 12.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(if (i < n) Palette.Gold else Palette.Raised2)) }
    }
}

/** The field with the ball spot, line of scrimmage, line to gain, down and distance, and the current drive. */
@Composable
fun FootballLiveView(g: Game, f: FootballLive, awayC: Color, homeC: Color) {
    val possTeam = when (f.possessionId) {
        g.away.team.id -> g.away.team
        g.home.team.id -> g.home.team
        else -> null
    }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            possTeam?.let { Logo(it.logo, 30.dp); Spacer(Modifier.width(10.dp)) }
            Text(f.downText.ifBlank { "Live" }, Modifier.weight(1f), style = Type.Title, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (f.redZone) Tag("RED ZONE", Palette.Live, Color.White)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((if (f.possessionId == g.away.team.id) "🏈 " else "") + g.away.team.abbr, style = Type.Label,
                    color = if (f.possessionId == g.away.team.id) Palette.Text else Palette.Sub)
                Timeouts(f.awayTimeouts)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(g.home.team.abbr + (if (f.possessionId == g.home.team.id) " 🏈" else ""), style = Type.Label,
                    color = if (f.possessionId == g.home.team.id) Palette.Text else Palette.Sub)
                Timeouts(f.homeTimeouts)
            }
        }
        Canvas(
            Modifier.fillMaxWidth().height(92.dp).clip(RoundedCornerShape(10.dp)).semantics {
                contentDescription = listOfNotNull(
                    possTeam?.let { "${it.name} ball" },
                    f.downText.takeIf { it.isNotBlank() },
                    "Red zone".takeIf { f.redZone },
                ).joinToString(". ").ifBlank { "Field" }
            }
        ) {
            val w = size.width
            val h = size.height
            val ez = w * 0.08f                       // each end zone
            val field = w - 2 * ez
            fun x(yd: Double) = (ez + field * (yd / 100.0)).toFloat()
            drawRect(awayC, topLeft = Offset(0f, 0f), size = Size(ez, h))
            drawRect(homeC, topLeft = Offset(w - ez, 0f), size = Size(ez, h))
            for (i in 0 until 10) drawRect(if (i % 2 == 0) Grass else GrassDark, topLeft = Offset(x(i * 10.0), 0f), size = Size(field / 10, h))
            for (yd in 0..100 step 10) drawLine(Chalk, Offset(x(yd.toDouble()), 0f), Offset(x(yd.toDouble()), h), strokeWidth = if (yd == 50) 3f else 2f)
            for (yd in 5..95 step 10) drawLine(Chalk.copy(alpha = 0.35f), Offset(x(yd.toDouble()), 0f), Offset(x(yd.toDouble()), h), strokeWidth = 1f)
            f.ballX?.let { bx ->
                drawLine(Color(0xFF60A5FA), Offset(x(bx), 0f), Offset(x(bx), h), strokeWidth = 5f)
                f.toGainX?.let { gx -> drawLine(Color(0xFFFACC15), Offset(x(gx), 0f), Offset(x(gx), h), strokeWidth = 5f) }
                drawCircle(Color(0xFF7C4A21), radius = h * 0.11f, center = Offset(x(bx), h / 2))
                drawCircle(Color.White, radius = h * 0.11f, center = Offset(x(bx), h / 2), style = Stroke(width = 2f))
            }
        }
        if (f.ballX == null) Sub("Field position isn't posted for this play yet.")
        if (f.drive.isNotBlank()) Text("Drive: ${f.drive}", style = Type.Small, color = Palette.Sub)
        if (f.lastPlay.isNotBlank()) Text(f.lastPlay, style = Type.Body, color = Palette.Text)
    }
}

// ---------- shot charts ----------

private fun DrawScope.basketballCourt(c: Color) {
    val sx = size.width / 50f
    val sy = size.height / 47f
    fun o(x: Float, y: Float) = Offset(x * sx, y * sy)
    val s = Stroke(width = 2.5f)
    drawRect(c, topLeft = o(0f, 0f), size = Size(50 * sx, 47 * sy), style = s)
    drawRect(c, topLeft = o(17f, 0f), size = Size(16 * sx, 19 * sy), style = s)                // the key
    drawCircle(c, radius = 6 * sx, center = o(25f, 19f), style = s)                             // free throw circle
    drawLine(c, o(22f, 4f), o(28f, 4f), strokeWidth = 4f)                                       // backboard
    drawCircle(c, radius = 0.75f * sx, center = o(25f, 5.25f), style = s)                       // rim
    drawLine(c, o(3f, 0f), o(3f, 14f), strokeWidth = 2.5f)                                      // corner threes
    drawLine(c, o(47f, 0f), o(47f, 14f), strokeWidth = 2.5f)
    drawArc(c, startAngle = 22f, sweepAngle = 136f, useCenter = false,
        topLeft = o(25f - 23.75f, 5.25f - 23.75f), size = Size(47.5f * sx, 47.5f * sy), style = s)  // three-point arc
    drawArc(c, startAngle = 180f, sweepAngle = 180f, useCenter = false,
        topLeft = o(19f, 41f), size = Size(12 * sx, 12 * sy), style = s)                        // half-court circle
}

private fun DrawScope.hockeyRink(c: Color, red: Color, blue: Color) {
    val sx = size.width / 200f
    val sy = size.height / 85f
    fun o(x: Float, y: Float) = Offset((x + 100) * sx, (42.5f - y) * sy)
    drawRoundRect(c, topLeft = Offset(0f, 0f), size = size, cornerRadius = CornerRadius(28 * sx, 28 * sy), style = Stroke(width = 3f))
    drawLine(red, o(0f, 42.5f), o(0f, -42.5f), strokeWidth = 4f)
    for (bx in listOf(-25f, 25f)) drawLine(blue, o(bx, 42.5f), o(bx, -42.5f), strokeWidth = 4f)
    for (gx in listOf(-89f, 89f)) drawLine(red, o(gx, 40f), o(gx, -40f), strokeWidth = 2f)
    drawCircle(blue, radius = 15 * sx, center = o(0f, 0f), style = Stroke(width = 2f))
    for (fx in listOf(-69f, 69f)) for (fy in listOf(-22f, 22f)) drawCircle(red.copy(alpha = 0.7f), radius = 15 * sx, center = o(fx, fy), style = Stroke(width = 2f))
    for (gx in listOf(-89f, 89f)) drawCircle(Color(0xFF60A5FA).copy(alpha = 0.5f), radius = 6 * sx, center = o(gx, 0f))
}

/** Every shot so far: filled for makes and goals, rings for misses and saves, colored by team. */
fun shotSummary(g: Game, shots: List<Shot>, hockey: Boolean): String =
    listOf(g.away.team, g.home.team).mapNotNull { t ->
        val mine = shots.filter { it.teamId == t.id }
        if (mine.isEmpty()) null
        else if (hockey) "${t.abbr} ${mine.size} shots, ${mine.count { it.made }} goals"
        else "${t.abbr} ${mine.count { it.made }} of ${mine.size} shots made"
    }.joinToString(". ").ifBlank { "No shots yet" }

@Composable
fun ShotChart(g: Game, shots: List<Shot>, awayC: Color, homeC: Color) {
    val hockey = g.league.sport == "hockey"
    var pick by remember(g.id) { mutableIntStateOf(0) }
    val teams = listOf(null, g.away.team.id, g.home.team.id)
    val shown = shots.filter { teams[pick] == null || it.teamId == teams[pick] }
    fun colorOf(s: Shot) = if (s.teamId == g.home.team.id) homeC else awayC
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(if (hockey) "Shot map" else "Shot chart")
        PillTabs(listOf("Both", g.away.team.abbr, g.home.team.abbr), pick, Modifier.padding(0.dp)) { pick = it }
        val lines = Palette.Sub.copy(alpha = 0.6f)
        Canvas(
            Modifier
                .fillMaxWidth()
                .aspectRatio(if (hockey) 200f / 85f else 50f / 47f)
                .clip(RoundedCornerShape(if (hockey) 22.dp else 8.dp))
                .background(if (hockey) Color(0xFFE8EEF5) else Color(0xFF3B2A1C))
                .semantics { contentDescription = shotSummary(g, shown, hockey) }
        ) {
            if (hockey) hockeyRink(Color(0xFF94A3B8), Color(0xFFDC2626), Color(0xFF2563EB)) else basketballCourt(lines)
            val r = size.width / (if (hockey) 75f else 60f)
            shown.forEach { s ->
                val c = if (hockey) Offset(((s.x + 100) / 200 * size.width).toFloat(), ((42.5 - s.y) / 85 * size.height).toFloat())
                else Offset((s.x / 50 * size.width).toFloat(), (s.y / 47 * size.height).toFloat())
                val col = colorOf(s)
                if (s.made) {
                    drawCircle(col, radius = r * 1.15f, center = c)
                    drawCircle(Color.White, radius = r * 1.15f, center = c, style = Stroke(width = 2f))
                } else drawCircle(col, radius = r, center = c, style = Stroke(width = 3f))
            }
        }
        listOf(g.away, g.home).forEach { side ->
            val mine = shots.filter { it.teamId == side.team.id }
            if (mine.isNotEmpty()) {
                val made = mine.count { it.made }
                Text(
                    if (hockey) "${side.team.abbr}: ${mine.size} shots, $made goals"
                    else "${side.team.abbr}: $made of ${mine.size} from the field (${100 * made / mine.size}%)",
                    style = Type.Small, color = Palette.Sub
                )
            }
        }
    }
}

// ---------- soccer ----------

private fun DrawScope.halfPitch(c: Color) {
    val w = size.width
    val h = size.height
    val s = Stroke(width = 2.5f)
    for (i in 0 until 8) drawRect(if (i % 2 == 0) Grass else GrassDark, topLeft = Offset(0f, h * i / 8), size = Size(w, h / 8))
    drawRect(c, topLeft = Offset(4f, 4f), size = Size(w - 8, h - 8), style = s)
    drawArc(c, startAngle = 0f, sweepAngle = 180f, useCenter = false, topLeft = Offset(w / 2 - w * 0.17f, 4f - w * 0.17f), size = Size(w * 0.34f, w * 0.34f), style = s)
    drawRect(c, topLeft = Offset(w * 0.2f, h - 4 - h * 0.17f), size = Size(w * 0.6f, h * 0.17f), style = s)      // penalty box
    drawRect(c, topLeft = Offset(w * 0.37f, h - 4 - h * 0.06f), size = Size(w * 0.26f, h * 0.06f), style = s)    // six-yard box
    drawArc(c, startAngle = 200f, sweepAngle = 140f, useCenter = false, topLeft = Offset(w / 2 - w * 0.13f, h - 4 - h * 0.17f - w * 0.09f), size = Size(w * 0.26f, w * 0.26f), style = s)
}

@Composable
private fun PitchPlayer(p: LivePlayer, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.BottomEnd) {
            Headshot(p.headshot, 40.dp, ring = Color.White.copy(alpha = 0.8f), name = p.name)
            if (p.jersey.isNotBlank()) Box(
                Modifier.clip(CircleShape).background(Color(0xFF0B0F14)).padding(horizontal = 4.dp, vertical = 1.dp)
            ) { Text(p.jersey, style = Type.Caption, color = Color.White) }
        }
        Text(p.name, style = Type.Caption, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

/** Each team's starting eleven in formation on a half pitch, attackers at the top. */
@Composable
fun FormationView(formations: List<Formation>) {
    var pick by remember(formations.size) { mutableIntStateOf(0) }
    val f = formations.getOrNull(pick) ?: return
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("Lineups" + if (f.shape.isNotBlank()) " · ${f.shape}" else "")
        if (formations.size > 1) PillTabs(formations.map { it.teamName }, pick, Modifier.padding(0.dp)) { pick = it }
        Box(
            Modifier.fillMaxWidth().height(420.dp).clip(RoundedCornerShape(12.dp)).clearAndSetSemantics {
                contentDescription = "${f.teamName} lineup" + (if (f.shape.isNotBlank()) ", ${f.shape}" else "") + ". " +
                    f.rows.joinToString(". ") { row -> row.joinToString(", ") { p -> p.name } }
            }
        ) {
            Canvas(Modifier.fillMaxSize()) { halfPitch(Chalk) }
            Column(Modifier.fillMaxSize().padding(vertical = 14.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                f.rows.asReversed().forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { p -> PitchPlayer(p, Modifier.width(72.dp)) }
                    }
                }
            }
        }
    }
}

// ---------- baseball field ----------

/** Polar spots for each position: degrees off the line to center field, and distance as a share of the fence. */
private val spots = mapOf(
    "LF" to (-30.0 to 0.74), "CF" to (0.0 to 0.84), "RF" to (30.0 to 0.74),
    "SS" to (-14.0 to 0.50), "2B" to (14.0 to 0.50), "3B" to (-34.0 to 0.40), "1B" to (34.0 to 0.40),
    "P" to (0.0 to 0.26), "C" to (0.0 to -0.07),
)

/** The defense from behind home plate: fence, infield, bases, and each fielder's name at their spot. */
@Composable
fun FieldView(fielders: Map<String, LivePlayer>, teamAbbr: String) {
    Text("In the field: $teamAbbr", style = Type.Label, color = Palette.Sub)
    BoxWithConstraints(
        Modifier.fillMaxWidth().aspectRatio(1.35f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF0E2A1A))
            .clearAndSetSemantics {
                contentDescription = "Fielders: " + spots.keys.mapNotNull { pos -> fielders[pos]?.let { "$pos ${it.name}" } }.joinToString(", ")
            }
    ) {
        val w = maxWidth
        val h = maxHeight
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2
            val cy = size.height * 0.9f
            val r = size.height * 0.82f
            val dirt = Color(0xFF9A6B43)
            // outfield grass and warning track as wedges opening up from home plate
            drawArc(Color(0xFF7A5534), 225f, 90f, true, Offset(cx - r * 1.04f, cy - r * 1.04f), Size(r * 2.08f, r * 2.08f))
            drawArc(Grass, 225f, 90f, true, Offset(cx - r, cy - r), Size(r * 2, r * 2))
            val ir = r * 0.47f
            drawArc(dirt, 225f, 90f, true, Offset(cx - ir, cy - ir), Size(ir * 2, ir * 2))
            // infield grass inside the base paths
            val d = r * 0.30f
            val k = 0.7071f
            val home = Offset(cx, cy)
            val first = Offset(cx + d * k, cy - d * k)
            val second = Offset(cx, cy - 2 * d * k)
            val third = Offset(cx - d * k, cy - d * k)
            val inner = Path().apply {
                val s = 0.82f
                moveTo(cx, cy - d * 0.18f); lineTo(cx + d * k * s, cy - d * k); lineTo(cx, cy - 2 * d * k * s - d * 0.1f); lineTo(cx - d * k * s, cy - d * k); close()
            }
            drawPath(inner, GrassDark)
            // foul lines and base paths
            drawLine(Chalk, home, Offset(cx + r * k, cy - r * k), strokeWidth = 2f)
            drawLine(Chalk, home, Offset(cx - r * k, cy - r * k), strokeWidth = 2f)
            listOf(home to first, first to second, second to third, third to home).forEach { (a, b) -> drawLine(Chalk.copy(alpha = 0.5f), a, b, strokeWidth = 1.5f) }
            drawCircle(dirt, radius = d * 0.14f, center = Offset(cx, cy - d * k))                       // mound
            listOf(first, second, third).forEach { drawRect(Color.White, Offset(it.x - 5f, it.y - 5f), Size(10f, 10f)) }
            drawCircle(Color.White, radius = 6f, center = home)
        }
        spots.forEach { (pos, spot) ->
            val p = fielders[pos] ?: return@forEach
            val (deg, share) = spot
            val rad = Math.toRadians(deg)
            val rr = h.value * 0.82 * share
            val x = w.value / 2 + rr * kotlin.math.sin(rad)
            val y = h.value * 0.9 - rr * kotlin.math.cos(rad)
            Box(
                Modifier
                    .offset((x - 45).dp, (y - 10).dp)
                    .width(90.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    p.name.substringAfterLast(". ").substringAfterLast(' ').ifBlank { p.name },
                    Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 5.dp, vertical = 1.dp),
                    style = Type.Caption, color = Color.White, maxLines = 1
                )
            }
        }
    }
}

// ---------- highlights (experimental) ----------

/**
 * Leagues where ESPN holds US TV rights, so its clips are most likely to exist. Others are left out even if a stray
 * clip turns up, to keep the row dependable.
 */
val highlightLeagues = setOf("NFL", "NBA", "WNBA", "NHL", "CFB", "MCBB", "WCBB", "LALIGA", "BUNDESLIGA")

/**
 * The game's highlight clips as thumbnails. Nothing loads until one is tapped; then it plays in a small player that
 * releases itself when you leave the page.
 */
@Composable
fun Highlights(clips: List<com.roki.sideline.data.Clip>) {
    if (clips.isEmpty()) return
    var playing by remember(clips.firstOrNull()?.url) { mutableStateOf<com.roki.sideline.data.Clip?>(null) }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("HIGHLIGHTS", Modifier.weight(1f), style = Type.Label, color = Palette.Sub)
            Tag("EXPERIMENTAL", Palette.Raised2, Palette.Sub)
        }
        playing?.let { clip ->
            VideoPlayer(clip.url)
            Text(clip.title, style = Type.BodyStrong, color = Palette.Text)
        }
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(clips.size) { i ->
                val c = clips[i]
                Column(
                    Modifier
                        .width(160.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { playing = c }
                ) {
                    Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Palette.Raised2), contentAlignment = Alignment.Center) {
                        if (c.thumb.isNotBlank()) coil.compose.AsyncImage(model = c.thumb, contentDescription = c.title,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Text(if (playing == c) "▶ Playing" else "▶", style = Type.Heading, color = Color.White)
                        if (c.seconds > 0) Text(
                            "%d:%02d".format(c.seconds / 60, c.seconds % 60),
                            Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.6f)).padding(horizontal = 4.dp),
                            style = Type.Caption, color = Color.White
                        )
                    }
                    Text(c.title, Modifier.padding(top = 4.dp), style = Type.Small, color = Palette.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

/** A Media3 player for one clip. It starts when shown and is released when the clip changes or the page closes. */
@Composable
private fun VideoPlayer(url: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(url) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            setMediaItem(androidx.media3.common.MediaItem.fromUri(url))
            prepare()
            playWhenReady = true
        }
    }
    androidx.compose.runtime.DisposableEffect(player) { onDispose { player.release() } }
    androidx.compose.ui.viewinterop.AndroidView(
        factory = { ctx -> androidx.media3.ui.PlayerView(ctx).apply { this.player = player } },
        update = { it.player = player },
        modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)),
    )
}
