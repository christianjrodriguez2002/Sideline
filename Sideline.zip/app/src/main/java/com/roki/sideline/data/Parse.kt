package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.OffsetDateTime

/**
 * Turns ESPN's public JSON into app models. Every field is optional on ESPN's side and shapes differ a little by
 * league and endpoint, so everything here reads defensively and a bad item is skipped instead of failing the screen.
 */
object Parse {

    // ---------- tiny JSON helpers ----------

    fun JSONObject?.obj(key: String): JSONObject? = this?.optJSONObject(key)
    fun JSONObject?.arr(key: String): JSONArray? = this?.optJSONArray(key)
    fun JSONObject?.s(key: String): String {
        if (this == null || !has(key) || isNull(key)) return ""
        return when (val v = opt(key)) {
            is String -> v
            is Number, is Boolean -> v.toString()
            is JSONObject -> v.optString("displayValue", v.optString("summary", v.optString("value", "")))
            else -> ""
        }
    }

    fun JSONArray?.objects(): List<JSONObject> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { optJSONObject(it) }
    }

    fun JSONArray?.strings(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { i -> if (isNull(i)) null else opt(i)?.toString() }
    }

    fun instant(s: String): Instant? {
        if (s.isBlank()) return null
        return runCatching { OffsetDateTime.parse(s).toInstant() }.getOrNull()
            ?: runCatching { Instant.parse(s) }.getOrNull()
            ?: runCatching { OffsetDateTime.parse(s.replace("Z", ":00Z")).toInstant() }.getOrNull()
    }

    private inline fun <T> safe(block: () -> T): T? = try { block() } catch (e: Exception) { null }

    // ---------- teams ----------

    fun logoOf(team: JSONObject?): String {
        val direct = team.s("logo")
        if (direct.isNotBlank()) return direct
        val logos = team.arr("logos").objects()
        val dark = logos.firstOrNull { l -> l.arr("rel").strings().contains("dark") }
        return (logos.firstOrNull { l -> l.arr("rel").strings().contains("default") } ?: logos.firstOrNull() ?: dark).s("href")
    }

    fun team(t: JSONObject?): TeamRef? {
        if (t == null) return null
        val id = t.s("id")
        if (id.isBlank()) return null
        val name = t.s("displayName").ifBlank { listOf(t.s("location"), t.s("name")).filter { it.isNotBlank() }.joinToString(" ") }
        return TeamRef(
            id = id,
            abbr = t.s("abbreviation").ifBlank { t.s("shortDisplayName") },
            name = name.ifBlank { t.s("abbreviation") },
            shortName = t.s("shortDisplayName").ifBlank { t.s("name") }.ifBlank { name },
            logo = logoOf(t),
            color = t.s("color"),
        )
    }

    fun teams(root: JSONObject): List<TeamRef> =
        root.arr("sports").objects().flatMap { sp -> sp.arr("leagues").objects() }
            .flatMap { lg -> lg.arr("teams").objects() }
            .mapNotNull { safe { team(it.obj("team") ?: it) } }
            .sortedBy { it.name }

    private fun recordSummary(c: JSONObject): String {
        val recs = (c.arr("records") ?: c.arr("record")).objects()
        val pick = recs.firstOrNull { it.s("type") == "total" || it.s("name").equals("overall", true) || it.s("type") == "ytd" }
            ?: recs.firstOrNull()
        return pick?.let { it.s("summary").ifBlank { it.s("displayValue") } } ?: ""
    }

    private fun leaders(arr: JSONArray?, teamFallback: String = ""): List<Leader> =
        arr.objects().flatMap { cat ->
            val catName = cat.s("shortDisplayName").ifBlank { cat.s("displayName") }.ifBlank { cat.s("name") }
            cat.arr("leaders").objects().take(1).mapNotNull { l ->
                val a = l.obj("athlete") ?: return@mapNotNull null
                Leader(catName, a.s("id"), a.s("displayName").ifBlank { a.s("fullName") }, l.s("displayValue"),
                    a.obj("headshot").s("href").ifBlank { a.s("headshot") })
            }
        }

    private fun competitor(c: JSONObject): Competitor? {
        val team = team(c.obj("team")) ?: return null
        val score = c.s("score")
        return Competitor(
            team = team,
            home = c.s("homeAway") == "home",
            score = score.substringBefore(".0").let { if (it == "null") "" else it },
            winner = c.optBoolean("winner", false),
            record = recordSummary(c),
            linescores = c.arr("linescores").objects().map { it.s("displayValue").ifBlank { it.s("value").substringBefore(".0") } },
            leaders = leaders(c.arr("leaders")),
            rank = c.obj("curatedRank")?.optInt("current", 99)?.takeIf { it in 1..25 }?.toString() ?: "",
        )
    }

    fun broadcasts(comp: JSONObject?): List<Broadcast> {
        val out = LinkedHashMap<String, Broadcast>()
        comp.arr("geoBroadcasts").objects().forEach { g ->
            val n = g.obj("media").s("shortName")
            if (n.isNotBlank()) out.putIfAbsent(n, Broadcast(n, g.obj("market").s("type")))
        }
        comp.arr("broadcasts").objects().forEach { b ->
            val market = b.s("market").ifBlank { b.obj("market").s("type") }
            b.arr("names").strings().forEach { n -> out.putIfAbsent(n, Broadcast(n, market)) }
            val m = b.obj("media").s("shortName")
            if (m.isNotBlank()) out.putIfAbsent(m, Broadcast(m, market))
        }
        return out.values.toList()
    }

    fun odds(o: JSONObject?): Odds? {
        if (o == null) return null
        val details = o.s("details")
        val ou = o.s("overUnder")
        if (details.isBlank() && ou.isBlank()) return null
        return Odds(
            provider = o.obj("provider").s("name"),
            details = details,
            overUnder = ou,
            homeMoneyline = o.obj("homeTeamOdds").s("moneyLine"),
            awayMoneyline = o.obj("awayTeamOdds").s("moneyLine"),
            drawMoneyline = o.obj("drawOdds").s("moneyLine"),
        )
    }

    private fun situation(comp: JSONObject?, league: League): String {
        val sit = comp.obj("situation") ?: return ""
        return when (league.sport) {
            "baseball" -> {
                val outs = sit.s("outs")
                val bases = listOf("onFirst" to "1st", "onSecond" to "2nd", "onThird" to "3rd")
                    .filter { sit.optBoolean(it.first, false) }.joinToString(", ") { it.second }
                listOfNotNull(
                    if (sit.has("balls")) "${sit.s("balls")}-${sit.s("strikes")}" else null,
                    if (outs.isNotBlank()) "$outs out" else null,
                    if (bases.isNotBlank()) "on $bases" else null,
                ).joinToString(" · ")
            }
            "football" -> listOf(sit.s("downDistanceText"), sit.s("possessionText")).filter { it.isNotBlank() }.joinToString(" · ")
            else -> ""
        }
    }

    fun game(e: JSONObject, league: League): Game? {
        val comp = e.arr("competitions").objects().firstOrNull() ?: return null
        val comps = comp.arr("competitors").objects().mapNotNull { safe { competitor(it) } }
        val home = comps.firstOrNull { it.home } ?: comps.getOrNull(0) ?: return null
        val away = comps.firstOrNull { !it.home && it !== home } ?: comps.getOrNull(1) ?: return null
        val status = e.obj("status") ?: comp.obj("status")
        val type = status.obj("type")
        val state = when (type.s("state")) {
            "in" -> GameState.IN
            "post" -> GameState.POST
            else -> GameState.PRE
        }
        val venue = comp.obj("venue").let { v ->
            listOf(v.s("fullName"), v.obj("address").s("city")).filter { it.isNotBlank() }.joinToString(", ")
        }
        return Game(
            id = e.s("id").ifBlank { comp.s("id") },
            league = league,
            start = instant(e.s("date").ifBlank { comp.s("date") }),
            name = e.s("name"),
            shortName = e.s("shortName"),
            state = state,
            statusDetail = type.s("detail").ifBlank { type.s("description") },
            statusShort = type.s("shortDetail").ifBlank { type.s("detail") },
            home = home,
            away = away,
            venue = venue,
            broadcasts = broadcasts(comp),
            odds = odds(comp.arr("odds").objects().firstOrNull()),
            lastPlay = comp.obj("situation").obj("lastPlay").s("text"),
            situation = situation(comp, league),
            note = comp.arr("notes").objects().firstOrNull().s("headline"),
            clock = status.s("displayClock"),
        )
    }

    fun scoreboard(root: JSONObject, league: League): List<Game> =
        root.arr("events").objects().mapNotNull { safe { game(it, league) } }.sortedBy { it.start ?: Instant.MAX }

    /** NFL scoreboards say which week they are; other leagues return null. */
    fun week(root: JSONObject): Pair<Int, Int>? {
        val w = root.obj("week")?.optInt("number", -1) ?: -1
        val t = root.obj("season")?.optInt("type", -1) ?: -1
        return if (w > 0 && t > 0) w to t else null
    }

    fun schedule(root: JSONObject, league: League): List<Game> =
        root.arr("events").objects().mapNotNull { safe { game(it, league) } }.sortedBy { it.start ?: Instant.MAX }

    // ---------- standings ----------

    private data class Col(val header: String, val keys: List<String>)

    private fun columnsFor(league: League): List<Col>? = when {
        league.kind == Kind.SOCCER -> listOf(Col("GP", listOf("gamesplayed")), Col("W", listOf("wins")), Col("D", listOf("ties", "draws")),
            Col("L", listOf("losses")), Col("GF", listOf("pointsfor", "goalsfor")), Col("GA", listOf("pointsagainst", "goalsagainst")),
            Col("GD", listOf("pointdifferential", "differential", "goaldifference")), Col("PTS", listOf("points")))
        league.kind == Kind.RACE -> null
        league.sport == "hockey" -> listOf(Col("GP", listOf("gamesplayed")), Col("W", listOf("wins")), Col("L", listOf("losses")),
            Col("OTL", listOf("otlosses", "overtimelosses")), Col("PTS", listOf("points")), Col("GF", listOf("pointsfor", "goalsfor")),
            Col("GA", listOf("pointsagainst", "goalsagainst")), Col("DIFF", listOf("differential", "pointdifferential")),
            Col("STRK", listOf("streak")))
        league.sport == "football" -> listOf(Col("W", listOf("wins")), Col("L", listOf("losses")), Col("T", listOf("ties")),
            Col("PCT", listOf("winpercent")), Col("CONF", listOf("vsconf", "conference")), Col("PF", listOf("pointsfor")),
            Col("PA", listOf("pointsagainst")), Col("DIFF", listOf("differential", "pointdifferential")), Col("STRK", listOf("streak")))
        league.sport == "baseball" -> listOf(Col("W", listOf("wins")), Col("L", listOf("losses")), Col("PCT", listOf("winpercent")),
            Col("GB", listOf("gamesbehind")), Col("HOME", listOf("home")), Col("AWAY", listOf("road", "away")),
            Col("L10", listOf("lasttengames", "l10")), Col("STRK", listOf("streak")), Col("DIFF", listOf("differential", "pointdifferential")))
        else -> listOf(Col("W", listOf("wins")), Col("L", listOf("losses")), Col("PCT", listOf("winpercent")),
            Col("GB", listOf("gamesbehind")), Col("CONF", listOf("vsconf")), Col("HOME", listOf("home")), Col("AWAY", listOf("road", "away")),
            Col("L10", listOf("lasttengames", "l10")), Col("STRK", listOf("streak")))
    }

    /** For leagues without a fixed column set (racing): the first entry's stats, as ESPN labels them. */
    private fun dynamicColumns(entry: JSONObject): List<Col> =
        entry.arr("stats").objects().mapNotNull { st ->
            val h = st.s("abbreviation").ifBlank { st.s("shortDisplayName") }.ifBlank { st.s("displayName") }
            val k = st.s("name").lowercase().replace(" ", "")
            if (h.isBlank() || k.isBlank() || k == "rank") null else Col(h.uppercase().take(6), listOf(k))
        }.distinctBy { it.header }.take(6)

    private fun statMap(entry: JSONObject): Map<String, String> {
        val m = HashMap<String, String>()
        entry.arr("stats").objects().forEach { st ->
            val v = st.s("displayValue").ifBlank { st.s("summary") }.ifBlank { st.s("value") }
            listOf(st.s("name"), st.s("type"), st.s("abbreviation")).map { it.lowercase().replace(" ", "") }
                .filter { it.isNotBlank() }.forEach { k -> m.putIfAbsent(k, v) }
        }
        return m
    }

    fun standings(root: JSONObject, league: League): List<StandingTable> {
        val fixed = columnsFor(league)
        val tables = ArrayList<StandingTable>()
        fun walk(node: JSONObject) {
            val title = node.s("name").ifBlank { node.s("abbreviation") }
            val entries = node.obj("standings").arr("entries").objects()
            if (entries.isNotEmpty()) {
                val cols = fixed ?: dynamicColumns(entries.first())
                val rows = entries.mapNotNull { e ->
                    // racing standings list drivers (athlete) rather than teams
                    val t = team(e.obj("team")) ?: e.obj("athlete")?.let { a ->
                        val n = a.s("displayName").ifBlank { a.s("fullName") }
                        if (n.isBlank()) null else TeamRef(a.s("id").ifBlank { n }, a.s("shortName").ifBlank { n }, n, n,
                            a.obj("flag").s("href").ifBlank { a.obj("headshot").s("href") })
                    } ?: return@mapNotNull null
                    val raw = statMap(e)
                    val stats = cols.associate { c -> c.header to (c.keys.firstNotNullOfOrNull { k -> raw[k] } ?: "") }
                    val sortKey = when {
                        league.kind == Kind.SOCCER || league.sport == "hockey" -> raw["points"]
                        league.kind == Kind.RACE -> raw["championshippts"] ?: raw["points"]
                        else -> raw["winpercent"]
                    }.orEmpty()
                    StandingRow(t, stats + mapOf("_sort" to sortKey, "_gp" to raw["gamesplayed"].orEmpty(),
                        "_rank" to raw["rank"].orEmpty(), "_gd" to (raw["pointdifferential"] ?: raw["differential"]).orEmpty()),
                        e.obj("note").s("description"), e.obj("note").s("color"))
                }
                val ranked = rows.isNotEmpty() && rows.all { it.stats["_rank"]?.toIntOrNull() != null } && league.kind != Kind.TEAM
                val sorted = if (ranked) rows.sortedBy { it.stats["_rank"]!!.toInt() }
                else if (league.kind == Kind.RACE) rows
                else rows.sortedWith(compareByDescending<StandingRow> { it.stats["_sort"]?.toDoubleOrNull() ?: -1.0 }
                    .thenByDescending { it.stats["_gd"]?.replace("+", "")?.toDoubleOrNull() ?: 0.0 }
                    .thenBy { it.stats["_gp"]?.toDoubleOrNull() ?: 0.0 })
                val used = cols.filter { c -> sorted.any { it.stats[c.header].orEmpty().isNotBlank() } }
                tables.add(StandingTable(title, used.map { it.header to it.header }, sorted))
            }
            node.arr("children").objects().forEach { walk(it) }
        }
        walk(root)
        return tables
    }

    fun rankings(root: JSONObject): List<Ranking> =
        root.arr("rankings").objects().mapNotNull { r ->
            val rows = r.arr("ranks").objects().mapNotNull { x ->
                val t = team(x.obj("team")) ?: return@mapNotNull null
                RankRow(x.optInt("current", 0), x.optInt("previous", 0).takeIf { it > 0 }, t, x.s("recordSummary"),
                    x.s("points").substringBefore(".0"), x.s("firstPlaceVotes").let { if (it == "0") "" else it })
            }
            if (rows.isEmpty()) null else Ranking(r.s("name").ifBlank { r.s("shortName") }, rows)
        }

    // ---------- rosters & players ----------

    fun player(a: JSONObject, group: String = "", teamId: String = "", teamName: String = ""): Player? {
        val id = a.s("id")
        val name = a.s("displayName").ifBlank { a.s("fullName") }
        if (id.isBlank() || name.isBlank()) return null
        val pos = a.obj("position")
        val bp = a.obj("birthPlace")
        val inj = a.arr("injuries").objects().firstOrNull()
        val exp = a.obj("experience")
        return Player(
            id = id,
            name = name,
            jersey = a.s("jersey"),
            position = pos.s("abbreviation"),
            positionName = pos.s("displayName").ifBlank { pos.s("name") },
            group = group,
            age = a.s("age"),
            height = a.s("displayHeight"),
            weight = a.s("displayWeight"),
            birthPlace = listOf(bp.s("city"), bp.s("state").ifBlank { bp.s("country") }).filter { it.isNotBlank() }.joinToString(", "),
            college = a.obj("college").s("name").ifBlank { a.obj("college").s("shortName") },
            experience = exp?.let { val y = it.optInt("years", -1); if (y == 0) "Rookie" else if (y > 0) "$y yrs" else "" } ?: "",
            headshot = a.obj("headshot").s("href"),
            status = a.obj("status").s("name"),
            injuryStatus = inj?.s("status").orEmpty(),
            teamId = teamId,
            teamName = teamName,
        )
    }

    fun roster(root: JSONObject): List<Player> {
        val team = team(root.obj("team"))
        val out = ArrayList<Player>()
        root.arr("athletes").objects().forEach { a ->
            val items = a.arr("items")
            if (items != null) {
                val g = a.s("position").replaceFirstChar { it.uppercase() }
                items.objects().forEach { p -> safe { player(p, g, team?.id.orEmpty(), team?.name.orEmpty()) }?.let { out.add(it) } }
            } else safe { player(a, a.obj("position").s("displayName"), team?.id.orEmpty(), team?.name.orEmpty()) }?.let { out.add(it) }
        }
        return out
    }

    // ---------- injuries ----------

    private fun injury(i: JSONObject, teamId: String, teamName: String, teamLogo: String): Injury? {
        val a = i.obj("athlete") ?: return null
        val name = a.s("displayName").ifBlank { a.s("fullName") }
        if (name.isBlank()) return null
        val d = i.obj("details")
        val type = i.obj("type").let { t -> t.s("description").ifBlank { t.s("name") } }.ifBlank { i.s("type") }
            .ifBlank { listOf(d.s("side"), d.s("location"), d.s("type"), d.s("detail")).filter { it.isNotBlank() && it != "Not Specified" }.joinToString(" ") }
        val t = a.obj("team")
        return Injury(
            athleteId = a.s("id"),
            athleteName = name,
            position = a.obj("position").s("abbreviation"),
            status = i.s("status").ifBlank { d.s("fantasyStatus") },
            comment = i.s("shortComment").ifBlank { i.s("longComment") }.ifBlank { i.s("description") },
            type = type,
            returnDate = d.s("returnDate"),
            date = instant(i.s("date")),
            teamId = teamId.ifBlank { t.s("id") },
            teamName = teamName.ifBlank { t.s("displayName") },
            teamLogo = teamLogo.ifBlank { logoOf(t) },
            headshot = a.obj("headshot").s("href"),
        )
    }

    /** League-wide injuries come grouped by team; a flat list also works. */
    fun injuries(root: JSONObject): List<Injury> {
        val out = ArrayList<Injury>()
        root.arr("injuries").objects().forEach { g ->
            val inner = g.arr("injuries")
            if (inner != null) {
                val tid = g.s("id").ifBlank { g.obj("team").s("id") }
                val tname = g.s("displayName").ifBlank { g.obj("team").s("displayName") }
                val tlogo = logoOf(g).ifBlank { logoOf(g.obj("team")) }
                inner.objects().forEach { i -> safe { injury(i, tid, tname, tlogo) }?.let { out.add(it) } }
            } else safe { injury(g, "", "", "") }?.let { out.add(it) }
        }
        return out
    }

    // ---------- news & moves ----------

    fun articles(root: JSONObject): List<Article> =
        (root.arr("articles") ?: root.arr("feed") ?: root.obj("news").arr("articles")).objects().mapNotNull { a ->
            val h = a.s("headline").ifBlank { a.s("title") }
            if (h.isBlank()) return@mapNotNull null
            val img = a.arr("images").objects().firstOrNull()
            Article(h, a.s("description"), instant(a.s("published")),
                img.s("url").ifBlank { img.s("href") }, a.obj("links").obj("web").s("href").ifBlank { a.obj("links").obj("mobile").s("href") })
        }

    fun transactions(root: JSONObject): List<Transaction> =
        root.arr("transactions").objects().mapNotNull { t ->
            val d = t.s("description")
            if (d.isBlank()) null else Transaction(instant(t.s("date")), d, team(t.obj("team")))
        }

    // ---------- team ----------

    fun teamDetail(root: JSONObject): TeamDetail? {
        val t = root.obj("team") ?: return null
        val ref = team(t) ?: return null
        val items = t.obj("record").arr("items").objects()
        val total = items.firstOrNull { it.s("type") == "total" } ?: items.firstOrNull()
        val details = items.mapNotNull { i ->
            val label = i.s("description").ifBlank { i.s("type") }
            val sum = i.s("summary")
            if (sum.isBlank()) null else label to sum
        }
        return TeamDetail(ref, total.s("summary"), t.s("standingSummary"), details)
    }

    // ---------- game summary ----------

    fun gameDetail(root: JSONObject, league: League): GameDetail? {
        val header = root.obj("header") ?: return null
        val comp = header.arr("competitions").objects().firstOrNull()
        val e = JSONObject().put("id", header.s("id")).put("competitions", JSONArray().put(comp ?: JSONObject()))
        comp?.optJSONObject("status")?.let { e.put("status", it) }
        comp?.s("date")?.let { e.put("date", it) }
        header.arr("competitions").objects().firstOrNull()?.let { c ->
            root.obj("gameInfo")?.obj("venue")?.let { v -> c.put("venue", v) }
        }
        var game = game(e, league) ?: return null
        game = game.copy(name = "${game.away.team.name} at ${game.home.team.name}")

        // predictions: ESPN's model first, then live win probability
        val pred = root.obj("predictor")
        var homePct = pred.obj("homeTeam").s("gameProjection").toDoubleOrNull()
        var awayPct = pred.obj("awayTeam").s("gameProjection").toDoubleOrNull()
        var predName = pred.s("header")
        val wp = root.arr("winprobability").objects().lastOrNull()
        if (game.state != GameState.PRE && wp != null) {
            wp.s("homeWinPercentage").toDoubleOrNull()?.let { homePct = it * 100; awayPct = 100 - it * 100; predName = "Live win probability" }
        }
        if (homePct != null && awayPct == null) awayPct = 100 - homePct!!
        if (awayPct != null && homePct == null) homePct = 100 - awayPct!!
        val drawPct = if (league.draws && homePct != null && awayPct != null && homePct!! + awayPct!! < 99.0) 100 - homePct!! - awayPct!! else null

        // team stats, matched by team id
        val bTeams = root.obj("boxscore").arr("teams").objects()
        val homeBox = bTeams.firstOrNull { it.obj("team").s("id") == game.home.team.id }
        val awayBox = bTeams.firstOrNull { it.obj("team").s("id") == game.away.team.id }
        val awayStats = awayBox.arr("statistics").objects().associate { (it.s("label").ifBlank { it.s("name") }) to it.s("displayValue") }
        val teamStats = homeBox.arr("statistics").objects().mapNotNull { st ->
            val label = st.s("label").ifBlank { st.s("name") }
            if (label.isBlank()) null else StatLine(label, awayStats[label].orEmpty(), st.s("displayValue"))
        }

        // leaders: per team, or one flat list
        val leaderGroups = root.arr("leaders").objects().mapNotNull { g ->
            val inner = g.arr("leaders").objects()
            if (inner.any { it.has("leaders") }) {
                val t = g.obj("team").s("abbreviation").ifBlank { g.obj("team").s("displayName") }
                t to leaders(g.arr("leaders"))
            } else {
                val l = leaders(JSONArray().put(g))
                if (l.isEmpty()) null else (g.s("displayName").ifBlank { g.s("name") }) to l
            }
        }

        // player box scores
        val box = root.obj("boxscore").arr("players").objects().flatMap { tp ->
            val tName = tp.obj("team").s("abbreviation").ifBlank { tp.obj("team").s("displayName") }
            tp.arr("statistics").objects().mapNotNull { cat ->
                val labels = (cat.arr("labels") ?: cat.arr("names")).strings()
                val rows = cat.arr("athletes").objects().mapNotNull { a ->
                    val n = a.obj("athlete").s("shortName").ifBlank { a.obj("athlete").s("displayName") }
                    val stats = a.arr("stats").strings()
                    if (n.isBlank() || stats.isEmpty()) null else n to stats
                }
                if (labels.isEmpty() || rows.isEmpty()) null
                else BoxTable(tName, cat.s("text").ifBlank { cat.s("displayName") }.ifBlank { cat.s("name") }.replaceFirstChar { it.uppercase() }, labels, rows)
            }
        }

        val injuries = root.arr("injuries").objects().flatMap { g ->
            val t = g.obj("team")
            g.arr("injuries").objects().mapNotNull { safe { injury(it, t.s("id"), t.s("displayName"), logoOf(t)) } }
        }

        val keyEvents = root.arr("keyEvents").objects().filter { k ->
            k.optBoolean("scoringPlay", false) || k.obj("type").s("text").contains("Card", true) ||
                k.obj("type").s("text").contains("Penalty", true)
        }.map { k ->
            listOf(k.obj("clock").s("displayValue"), k.obj("type").s("text")).filter { it.isNotBlank() }.joinToString(" ") + " · " +
                k.obj("team").s("displayName").let { if (it.isBlank()) "" else "$it: " } + k.s("text").ifBlank { k.s("shortText") }
        }
        val scoring = if (keyEvents.isNotEmpty()) keyEvents else ((root.arr("scoringPlays")?.objects()
            ?: root.arr("plays").objects().filter { it.optBoolean("scoringPlay", false) })
            .takeLast(40).map { p ->
                val per = p.obj("period").s("displayValue").ifBlank { p.obj("period").s("number").let { if (it.isBlank()) "" else "${league.periodShort}$it" } }
                val clock = p.obj("clock").s("displayValue")
                val score = if (p.has("awayScore")) " (${p.s("awayScore")}-${p.s("homeScore")})" else ""
                listOf(per, clock).filter { it.isNotBlank() }.joinToString(" ") + " · " +
                    p.obj("team").s("abbreviation").let { if (it.isBlank()) "" else "$it: " } + p.s("text") + score
            })

        val lineups = root.arr("rosters").objects().mapNotNull { r ->
            val name = r.obj("team").s("displayName").ifBlank { r.obj("team").s("abbreviation") }
            val players = r.arr("roster").objects().mapNotNull { x ->
                val n = x.obj("athlete").s("displayName")
                if (n.isBlank()) null else LineupPlayer(n, x.obj("position").s("abbreviation"), x.s("jersey"), x.optBoolean("starter", false))
            }
            if (players.isEmpty()) null else name to players.sortedByDescending { it.starter }
        }

        val pick = root.arr("pickcenter").objects().firstOrNull()
        val bc = broadcasts(comp).ifEmpty { broadcasts(JSONObject().put("broadcasts", root.optJSONArray("broadcasts") ?: JSONArray())) }

        return GameDetail(
            game = game.copy(broadcasts = bc.ifEmpty { game.broadcasts }),
            homeWinPct = homePct,
            awayWinPct = awayPct,
            drawPct = drawPct,
            predictorName = predName.ifBlank { "ESPN matchup predictor" },
            teamStats = teamStats,
            leaders = leaderGroups,
            injuries = injuries,
            box = box,
            scoringPlays = scoring,
            attendance = root.obj("gameInfo").s("attendance").let { if (it == "0") "" else it },
            seasonSeries = root.arr("seasonseries").objects().firstOrNull().let { it.s("summary").ifBlank { it.s("description") } },
            odds = odds(pick),
            broadcasts = bc,
            articleHeadline = root.obj("article").s("headline"),
            lineups = lineups,
        )
    }

    // ---------- athlete ----------

    fun overview(root: JSONObject): PlayerOverview {
        val st = root.obj("statistics")
        val labels = st.arr("labels").strings()
        val rows = ArrayList<StatRow>()
        st.arr("splits").objects().forEach { sp ->
            val v = sp.arr("stats").strings()
            if (v.isNotEmpty()) rows.add(StatRow(sp.s("displayName"), v))
        }
        if (rows.isEmpty()) {
            val dv = st.arr("displayValues").strings()
            if (dv.isNotEmpty()) rows.add(StatRow("Season", dv))
        }
        val newsArr = root.opt("news").let { n ->
            when (n) {
                is JSONArray -> n
                is JSONObject -> n.optJSONArray("articles")
                else -> null
            }
        }
        val news = articles(JSONObject().put("articles", newsArr ?: JSONArray()))
        val roto = root.obj("rotowire")
        val inj = listOf(roto.s("headline"), roto.s("news"), roto.s("description")).firstOrNull { it.isNotBlank() } ?: ""
        val ng = root.obj("nextGame")
        val nextGame = listOf(ng.s("name").ifBlank { ng.s("shortName") }).filter { it.isNotBlank() }.joinToString()
        return PlayerOverview(labels, rows, news, inj, nextGame)
    }

    // ---------- events: shared helpers ----------

    fun state(status: JSONObject?): GameState {
        val t = status.obj("type")
        return when ((t.s("state").ifBlank { status.s("state") }).lowercase()) {
            "in" -> GameState.IN
            "post" -> GameState.POST
            else -> GameState.PRE
        }
    }

    private fun statusText(status: JSONObject?): String {
        val t = status.obj("type")
        return t.s("shortDetail").ifBlank { t.s("detail") }.ifBlank { t.s("description") }
    }

    private fun combined(states: List<GameState>): GameState = when {
        states.any { it == GameState.IN } -> GameState.IN
        states.isNotEmpty() && states.all { it == GameState.POST } -> GameState.POST
        states.any { it == GameState.POST } && states.any { it == GameState.PRE } -> GameState.IN
        else -> GameState.PRE
    }

    private fun place(v: JSONObject?): String =
        listOf(v.s("fullName"), v.obj("address").s("city"), v.obj("address").s("state").ifBlank { v.obj("address").s("country") })
            .filter { it.isNotBlank() }.distinct().joinToString(", ")

    private fun athleteName(c: JSONObject): String =
        c.obj("athlete").s("displayName").ifBlank { c.obj("athlete").s("fullName") }
            .ifBlank { c.obj("roster").s("displayName") }
            .ifBlank { c.obj("roster").arr("athletes").objects().joinToString(" / ") { it.s("shortName").ifBlank { it.s("displayName") } } }
            .ifBlank { c.obj("team").s("displayName") }

    private fun flagOf(c: JSONObject): String =
        c.obj("athlete").obj("flag").s("href").ifBlank { c.obj("roster").arr("athletes").objects().firstOrNull().obj("flag").s("href") }

    // ---------- UFC fight cards ----------

    fun fightCards(root: JSONObject): List<FightCard> =
        root.arr("events").objects().mapNotNull { e ->
            safe {
                val comps = e.arr("competitions").objects()
                val fights = comps.mapNotNull { c ->
                    val cs = c.arr("competitors").objects().sortedBy { it.optInt("order", 0) }
                    if (cs.size < 2) return@mapNotNull null
                    fun fighter(x: JSONObject) = Fighter(
                        athleteName(x), recordSummary(x), flagOf(x),
                        x.obj("athlete").obj("headshot").s("href"), x.optBoolean("winner", false),
                        id = x.obj("athlete").s("id"),
                    )
                    val type = c.obj("type")
                    Fight(
                        id = c.s("id"),
                        weightClass = type.s("text").ifBlank { type.s("abbreviation") }.ifBlank { c.arr("notes").objects().firstOrNull().s("headline") },
                        state = state(c.obj("status")),
                        status = statusText(c.obj("status")),
                        start = instant(c.s("date")),
                        a = fighter(cs[0]),
                        b = fighter(cs[1]),
                    )
                }.reversed() // ESPN lists the card from the first prelim to the main event
                val venue = place(e.arr("venues").objects().firstOrNull() ?: comps.firstOrNull().obj("venue"))
                FightCard(
                    id = e.s("id"),
                    name = e.s("name").ifBlank { e.s("shortName") },
                    start = instant(e.s("date")),
                    venue = venue,
                    state = combined(fights.map { it.state }.ifEmpty { listOf(state(e.obj("status"))) }),
                    broadcasts = comps.flatMap { broadcasts(it) }.distinctBy { it.network },
                    fights = fights,
                )
            }
        }.sortedBy { it.start ?: Instant.MAX }

    // ---------- racing ----------

    private val SESSION_NAMES = mapOf(
        "FP1" to "Practice 1", "FP2" to "Practice 2", "FP3" to "Practice 3", "QUAL" to "Qualifying", "Q" to "Qualifying",
        "SS" to "Sprint Qualifying", "SQ" to "Sprint Qualifying", "SR" to "Sprint", "SPRINT" to "Sprint", "RACE" to "Race",
        "PRAC" to "Practice",
    )

    fun raceWeekends(root: JSONObject): List<RaceWeekend> =
        root.arr("events").objects().mapNotNull { e ->
            safe {
                val sessions = e.arr("competitions").objects().map { c ->
                    val t = c.obj("type")
                    val abbr = t.s("abbreviation")
                    val name = t.s("text").ifBlank { SESSION_NAMES[abbr.uppercase()] ?: abbr }.ifBlank { "Session" }
                    val results = c.arr("competitors").objects().mapNotNull { x ->
                        val n = athleteName(x)
                        if (n.isBlank()) return@mapNotNull null
                        val stats = x.arr("statistics").objects().associate { it.s("name").lowercase() to it.s("displayValue") }
                        val detail = listOf("totaltime", "behindtime", "gap", "time", "laps", "lapsled")
                            .firstNotNullOfOrNull { k -> stats[k]?.takeIf { it.isNotBlank() } } ?: x.s("time")
                        val v = x.obj("vehicle")
                        Finisher(
                            position = x.optInt("order", 0),
                            name = n,
                            team = x.obj("team").s("displayName").ifBlank { v.s("manufacturer") }.ifBlank { v.s("team") },
                            number = v.s("number"),
                            flag = flagOf(x),
                            detail = detail,
                            winner = x.optBoolean("winner", false),
                        )
                    }.sortedBy { if (it.position > 0) it.position else 999 }
                    Session(name, instant(c.s("date")), state(c.obj("status")), statusText(c.obj("status")), results, broadcasts(c))
                }.sortedBy { it.start ?: Instant.MAX }
                val circuit = e.obj("circuit")
                RaceWeekend(
                    id = e.s("id"),
                    name = e.s("name").ifBlank { e.s("shortName") },
                    circuit = circuit.s("fullName").ifBlank { e.arr("venues").objects().firstOrNull().s("fullName") },
                    location = listOf(circuit.obj("address").s("city"), circuit.obj("address").s("country")).filter { it.isNotBlank() }.joinToString(", "),
                    start = instant(e.s("date")),
                    end = instant(e.s("endDate")),
                    state = combined(sessions.map { it.state }.ifEmpty { listOf(state(e.obj("status"))) }),
                    sessions = sessions,
                )
            }
        }.sortedBy { it.start ?: Instant.MAX }

    // ---------- golf ----------

    fun tournaments(root: JSONObject): List<Tournament> =
        root.arr("events").objects().mapNotNull { e ->
            safe {
                val comp = e.arr("competitions").objects().firstOrNull()
                val players = comp.arr("competitors").objects().mapNotNull { x ->
                    val n = athleteName(x)
                    if (n.isBlank()) return@mapNotNull null
                    val st = x.obj("status")
                    val rounds = x.arr("linescores").objects().map { it.s("displayValue").ifBlank { it.s("value").substringBefore(".0") } }
                        .filter { it.isNotBlank() }
                    GolfPlayer(
                        position = st.obj("position").s("displayName").ifBlank { x.s("order").takeIf { it != "0" } ?: "" },
                        name = n,
                        flag = flagOf(x),
                        toPar = x.s("score").ifBlank { x.obj("score").s("displayValue") },
                        today = x.arr("linescores").objects().lastOrNull()?.let { it.s("displayValue") } ?: "",
                        thru = st.s("thru").let { if (it == "18") "F" else it }.ifBlank { st.s("displayValue") }.ifBlank { st.obj("type").s("shortDetail") },
                        rounds = rounds,
                    )
                }.sortedBy { p -> p.position.removePrefix("T").toIntOrNull() ?: 999 }
                Tournament(
                    id = e.s("id"),
                    name = e.s("name").ifBlank { e.s("shortName") },
                    start = instant(e.s("date")),
                    end = instant(e.s("endDate")),
                    venue = place(comp.obj("venue")).ifBlank { e.arr("courses").objects().firstOrNull().s("name") },
                    state = state(e.obj("status") ?: comp.obj("status")),
                    status = statusText(e.obj("status") ?: comp.obj("status")),
                    players = players,
                    broadcasts = broadcasts(comp),
                )
            }
        }

    // ---------- tennis ----------

    private fun tennisMatch(c: JSONObject): TennisMatch? {
        val cs = c.arr("competitors").objects().sortedBy { it.optInt("order", 0) }
        if (cs.size < 2) return null
        val players = cs.map { x ->
            TennisPlayer(
                name = athleteName(x),
                flag = flagOf(x),
                seed = x.s("seed").ifBlank { x.obj("curatedRank").s("current").takeIf { it != "99" && it != "0" } ?: "" },
                winner = x.optBoolean("winner", false),
                sets = x.arr("linescores").objects().map { l ->
                    val v = l.s("value").substringBefore(".0")
                    val tb = l.s("tiebreak").substringBefore(".0")
                    if (tb.isNotBlank() && tb != "0") "$v($tb)" else v
                },
            )
        }
        return TennisMatch(
            id = c.s("id"),
            round = c.obj("round").s("displayName").ifBlank { c.arr("notes").objects().firstOrNull().s("headline") },
            start = instant(c.s("date")),
            state = state(c.obj("status")),
            status = statusText(c.obj("status")),
            players = players,
        )
    }

    fun tennisEvents(root: JSONObject): List<TennisEvent> =
        root.arr("events").objects().mapNotNull { e ->
            safe {
                val draws = ArrayList<Pair<String, List<TennisMatch>>>()
                e.arr("groupings").objects().forEach { g ->
                    val name = g.obj("grouping").s("displayName").ifBlank { g.obj("grouping").s("shortName") }.ifBlank { "Matches" }
                    val matches = g.arr("competitions").objects().mapNotNull { safe { tennisMatch(it) } }
                    if (matches.isNotEmpty()) draws.add(name to matches)
                }
                if (draws.isEmpty()) {
                    val matches = e.arr("competitions").objects().mapNotNull { safe { tennisMatch(it) } }
                    if (matches.isNotEmpty()) draws.add("Matches" to matches)
                }
                TennisEvent(
                    id = e.s("id"),
                    name = e.s("name").ifBlank { e.s("shortName") },
                    start = instant(e.s("date")),
                    end = instant(e.s("endDate")),
                    venue = place(e.obj("venue")),
                    draws = draws,
                )
            }
        }

    // ---------- cricket (personalized scoreboard header) ----------

    fun cricket(root: JSONObject): List<CricketSeries> {
        val leagues = root.arr("sports").objects().flatMap { it.arr("leagues").objects() }
        val series = leagues.mapNotNull { l ->
            val matches = l.arr("events").objects().mapNotNull { e ->
                safe {
                    val comp = e.arr("competitions").objects().firstOrNull()
                    val sides = (comp?.arr("competitors") ?: e.arr("competitors")).objects().map { c ->
                        val t = c.obj("team")
                        CricketSide(
                            name = c.s("displayName").ifBlank { t.s("displayName") }.ifBlank { c.s("name") },
                            abbr = c.s("abbreviation").ifBlank { t.s("abbreviation") },
                            logo = c.s("logo").ifBlank { logoOf(t) },
                            score = c.s("score").ifBlank { c.arr("linescores").objects().joinToString(" & ") { it.s("displayValue") } },
                            winner = c.optBoolean("winner", false),
                        )
                    }
                    val statusObj = e.obj("fullStatus") ?: comp?.obj("status") ?: e.obj("status")
                    val st = when {
                        statusObj != null -> state(statusObj)
                        else -> when (e.s("status")) { "in" -> GameState.IN; "post" -> GameState.POST; else -> GameState.PRE }
                    }
                    CricketMatch(
                        id = e.s("id"),
                        name = e.s("name").ifBlank { e.s("shortName") },
                        start = instant(e.s("date")),
                        state = st,
                        status = e.s("summary").ifBlank { statusText(statusObj) }.ifBlank { e.s("statusText") },
                        sides = sides,
                        link = e.s("link").ifBlank { e.arr("links").objects().firstOrNull().s("href") },
                    )
                }
            }
            if (matches.isEmpty()) null else CricketSeries(l.s("id"), l.s("name").ifBlank { l.s("shortName") }, matches)
        }
        return series.sortedWith(compareBy(
            { s -> if (s.name.contains("Indian Premier League", true) || s.name.contains("IPL")) 0 else 1 },
            { s -> if (s.matches.any { it.state == GameState.IN }) 0 else 1 },
        ))
    }
}
