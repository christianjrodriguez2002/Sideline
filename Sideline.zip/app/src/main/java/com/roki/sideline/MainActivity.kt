@file:OptIn(ExperimentalMaterial3Api::class)

package com.roki.sideline

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Settings
import com.roki.sideline.data.Where
import com.roki.sideline.ui.EventScreen
import com.roki.sideline.ui.GameScreen
import com.roki.sideline.ui.HomeScreen
import com.roki.sideline.ui.LeagueScreen
import com.roki.sideline.ui.LeaguesScreen
import com.roki.sideline.ui.LocalNav
import com.roki.sideline.ui.Nav
import com.roki.sideline.ui.Palette
import com.roki.sideline.ui.PlayerScreen
import com.roki.sideline.ui.Route
import com.roki.sideline.ui.ScoresScreen
import com.roki.sideline.ui.SettingsScreen
import com.roki.sideline.ui.SidelineTheme
import com.roki.sideline.ui.TeamScreen
import com.roki.sideline.ui.Type
import com.roki.sideline.work.Alerts
import okhttp3.OkHttpClient

class SidelineApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        com.roki.sideline.ui.appContext = this
        com.roki.sideline.data.Espn.diskDir = java.io.File(cacheDir, "feeds")
        com.roki.sideline.ui.Look.load(this)
        Favorites.load(this)
        Settings.load(this)
        com.roki.sideline.data.Players.load(this)
        Where.load(this)
        Alerts.createChannel(this)
        Alerts.sync(this)
    }

    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .okHttpClient {
            OkHttpClient.Builder().addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "Sideline/3.1 (personal Android sports app)")
                        .build()
                )
            }.build()
        }
        .crossfade(250)
        .build()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Favorites.load(this)
        Settings.load(this)
        Where.load(this)
        setContent { SidelineTheme { Root() } }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Home", Icons.Filled.Home),
    Tab("Scores", Icons.Filled.DateRange),
    Tab("Leagues", Icons.Filled.List),
    Tab("Settings", Icons.Filled.Settings),
)

@Composable
private fun Root() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Route>() }
    val nav = remember { Nav { stack.add(it) } }

    BackHandler(enabled = stack.isNotEmpty()) { stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = stack.isEmpty() && tab != 0) { tab = 0 }

    val context = LocalContext.current
    LaunchedEffect(Unit) {
        val p = Where.place.value
        if ((p == null || p.fromGps) && Where.hasPermission(context)) {
            runCatching { Where.refreshFromPhone(context) }
        }
    }

    CompositionLocalProvider(LocalNav provides nav) {
        Scaffold(
            containerColor = Palette.Bg,
            topBar = {
                val top = stack.lastOrNull()
                Column {
                    TopAppBar(
                        title = {
                            if (top == null) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Palette.Blue)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text("SIDE", style = Type.Title, color = Palette.Text)
                                    Text("LINE", style = Type.Title, color = Palette.Blue)
                                }
                            } else {
                                Text(
                                    when (top) {
                                        is Route.TeamR -> top.team.name
                                        is Route.GameR -> top.league.short
                                        is Route.PlayerR -> top.player.name
                                        is Route.LeagueR -> top.league.label
                                        is Route.EventR -> top.label
                                        Route.SearchR -> "Search"
                                    },
                                    style = Type.Heading,
                                    color = Palette.Text,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        },
                        navigationIcon = {
                            if (top != null) {
                                IconButton(onClick = { stack.removeAt(stack.lastIndex) }) {
                                    Icon(Icons.Filled.ArrowBack, "Back", tint = Palette.Text)
                                }
                            }
                        },
                        actions = {
                            if (top !is Route.SearchR) {
                                IconButton(onClick = { nav.search() }) {
                                    Icon(Icons.Filled.Search, "Search", tint = Palette.Text)
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Palette.Bg,
                            titleContentColor = Palette.Text
                        ),
                    )
                    HorizontalDivider(
                        modifier = Modifier.fillMaxWidth(),
                        thickness = 0.5.dp,
                        color = Palette.Border
                    )
                }
            },
            bottomBar = {
                Column {
                    HorizontalDivider(
                        modifier = Modifier.fillMaxWidth(),
                        thickness = 0.5.dp,
                        color = Palette.Border
                    )
                    NavigationBar(
                        containerColor = Palette.Surface,
                        tonalElevation = 0.dp
                    ) {
                        TABS.forEachIndexed { i, t ->
                            NavigationBarItem(
                                selected = tab == i && stack.isEmpty(),
                                onClick = { tab = i; stack.clear() },
                                icon = { Icon(t.icon, contentDescription = null) },
                                label = { Text(t.label, style = Type.Caption) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White,
                                    selectedTextColor = Palette.Text,
                                    indicatorColor = Palette.BlueSoft,
                                    unselectedIconColor = Palette.Faint,
                                    unselectedTextColor = Palette.Faint,
                                ),
                            )
                        }
                    }
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (val top = stack.lastOrNull()) {
                    is Route.TeamR -> key(top) { TeamScreen(top.league, top.team) }
                    is Route.GameR -> key(top) { GameScreen(top.league, top.id) }
                    is Route.PlayerR -> key(top) { PlayerScreen(top.league, top.player) }
                    is Route.LeagueR -> key(top) { LeagueScreen(top.league) }
                    is Route.EventR -> key(top) { EventScreen(top.league, top.date) }
                    Route.SearchR -> com.roki.sideline.ui.SearchScreen()
                    null -> Crossfade(targetState = tab, animationSpec = tween(180), label = "tab") { currentTab ->
                        when (currentTab) {
                            0 -> HomeScreen(onBrowse = { tab = 2 }, onSettings = { tab = 3 })
                            1 -> ScoresScreen(onEditPins = { tab = 2 })
                            2 -> LeaguesScreen()
                            else -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}
