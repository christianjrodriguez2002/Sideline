package com.roki.sideline.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Espn
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.PlayerHit
import com.roki.sideline.data.Players
import com.roki.sideline.data.StatRow
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay

/** On a player page: pick someone from the same league to compare with. */
@Composable
fun ComparePicker(league: League, p: Player) {
    val nav = LocalNav.current
    var open by remember(p.id) { mutableStateOf(false) }
    var q by remember(p.id) { mutableStateOf("") }
    var hits by remember(p.id) { mutableStateOf<List<PlayerHit>>(emptyList()) }
    LaunchedEffect(q) {
        hits = emptyList()
        if (q.trim().length < 3) return@LaunchedEffect
        delay(350)
        hits = runCatching { Espn.searchPlayers(q) }.getOrDefault(emptyList()).filter { it.league?.key == league.key && it.id != p.id }
    }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        Text(
            if (open) "Close comparison" else "Compare with another player ›",
            Modifier.clickable { open = !open },
            style = Type.BodyStrong,
            color = Palette.Blue
        )
        if (open) {
            val followed = Players.list.filter { it.league.key == league.key && it.player.id != p.id }.map { it.player }
            if (followed.isNotEmpty()) {
                Text("PLAYERS YOU FOLLOW", style = Type.Label, color = Palette.Sub)
                followed.forEach { o -> PickRow(o.name, o.teamName, o.headshot) { nav.compare(league, p, o) } }
            }
            OutlinedTextField(
                value = q, onValueChange = { q = it }, singleLine = true,
                label = { Text("Search ${league.short} players") }, modifier = Modifier.fillMaxWidth()
            )
            hits.take(8).forEach { h -> PickRow(h.name, h.detail, h.headshot) { nav.compare(league, p, Player(h.id, h.name, headshot = h.headshot, teamName = h.detail)) } }
        }
    }
}

@Composable
private fun PickRow(name: String, sub: String, headshot: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Headshot(headshot, 34.dp, name = name)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Sub(sub, maxLines = 1)
        }
    }
}

/** Lines up two players' rows by their shared stat columns. Rows they don't share are left out. */
fun compareRows(labelsA: List<String>, rowA: StatRow?, labelsB: List<String>, rowB: StatRow?): List<Triple<String, String, String>> {
    if (rowA == null || rowB == null) return emptyList()
    val b = labelsB.zip(rowB.values).toMap()
    return labelsA.zip(rowA.values).mapNotNull { (k, v) -> b[k]?.let { Triple(k, v, it) } }
}

/** Two players side by side on this season's line, with a bar for each shared stat. */
@Composable
fun CompareScreen(league: League, a: Player, b: Player) {
    Loaded(
        key = "cmp:${league.key}:${a.id}:${b.id}",
        load = { coroutineScope { val x = async { Espn.athlete(league, a.id) }; val y = async { Espn.athlete(league, b.id) }; x.await() to y.await() } },
        pull = true,
    ) { (oa, ob), _ ->
        val ra = oa.rows.firstOrNull()
        val rb = ob.rows.firstOrNull()
        val rows = compareRows(oa.labels, ra, ob.labels, rb)
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    listOf(a, b).forEachIndexed { i, p ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Headshot(p.headshot.ifBlank { league.headshotUrl(p.id) }, 72.dp, name = p.name)
                            Text(p.name, style = Type.Heading, color = Palette.Text, textAlign = TextAlign.Center, maxLines = 2)
                            if (p.teamName.isNotBlank()) Sub(p.teamName, maxLines = 1)
                        }
                        if (i == 0) Text("vs", style = Type.Label, color = Palette.Faint)
                    }
                }
            }
            item {
                Panel {
                    SectionHeader(ra?.label?.ifBlank { null } ?: "Season")
                    if (rows.isEmpty()) Sub("These two don't share stats to compare, like a pitcher and a hitter.")
                    rows.forEach { (k, x, y) -> StatCompareRow(k, x, y) }
                }
            }
        }
    }
}

/** One stat line: values on each side with a split bar. The bar shows size only, not which is better. */
@Composable
private fun StatCompareRow(label: String, a: String, b: String) {
    val x = Regex("""-?\d+(\.\d+)?""").find(a)?.value?.toDoubleOrNull()
    val y = Regex("""-?\d+(\.\d+)?""").find(b)?.value?.toDoubleOrNull()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row {
            Text(a, Modifier.weight(1f), style = Type.Num, color = Palette.Text)
            Text(label, Modifier.weight(2f), style = Type.Small, color = Palette.Sub, textAlign = TextAlign.Center)
            Text(b, Modifier.weight(1f), style = Type.Num, color = Palette.Text, textAlign = TextAlign.End)
        }
        if (x != null && y != null && x >= 0 && y >= 0 && x + y > 0) SplitBar(100 * x / (x + y), Palette.Blue, Palette.Gold)
    }
}
