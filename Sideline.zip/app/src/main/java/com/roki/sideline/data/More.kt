package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

// ---------- models for 3.0 ----------

/** One play in a game's play-by-play. */
data class Play(val period: String, val clock: String, val team: String, val text: String, val scoring: Boolean, val away: String, val home: String)

/** One row on a league leaders board. */
data class LeaderRow(val rank: Int, val athleteId: String, val name: String, val team: String, val headshot: String, val value: String)
data class LeaderBoard(val category: String, val rows: List<LeaderRow>)

/** One team season stat, with its league rank when ESPN gives it ("3rd"). */
data class TeamStat(val label: String, val value: String, val rank: String)

/** A playoff round: its name and the series or games in it. */
data class Round(val name: String, val series: List<Series>)
data class Series(val a: TeamRef, val b: TeamRef, val summary: String, val games: List<Game>)

/** A player found by search. [league] is null when the player's league isn't one Sideline covers. */
data class PlayerHit(val id: String, val name: String, val detail: String, val headshot: String, val league: League?)

/** A followed player, kept on the phone. */
data class FollowedPlayer(val league: League, val player: Player) {
    val key get() = "${league.key}:${player.id}"
}

// ---------- parsers ----------

object More {
    private fun JSONObject?.obj(k: String): JSONObject? = this?.optJSONObject(k)
    private fun JSONObject?.arr(k: String): JSONArray? = this?.optJSONArray(k)
    private fun JSONObject?.s(k: String): String {
        if (this == null || !has(k) || isNull(k)) return ""
        return when (val v = opt(k)) {
            is String -> v
            is Double -> if (v == Math.floor(v)) v.toLong().toString() else v.toString()
            null -> ""
            else -> v.toString()
        }
    }
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    /** Every play in a game summary, newest last. Soccer summaries call them commentary or keyEvents. */
    fun plays(root: JSONObject, league: League): List<Play> {
        val list = root.arr("plays").objects().ifEmpty { root.arr("commentary").objects().mapNotNull { it.obj("play") ?: it } }
        return list.mapNotNull { p ->
            val text = p.s("text").ifBlank { p.s("shortText") }
            if (text.isBlank()) return@mapNotNull null
            val num = p.obj("period").s("number")
            val per = p.obj("period").s("displayValue").ifBlank { if (num.isBlank()) "" else "${league.periodShort}$num" }
            Play(
                period = per,
                clock = p.obj("clock").s("displayValue"),
                team = p.obj("team").s("abbreviation"),
                text = text,
                scoring = p.optBoolean("scoringPlay", false),
                away = p.s("awayScore"),
                home = p.s("homeScore"),
            )
        }
    }

    /** MLB probable pitcher for one competitor: "Webb (12-8, 3.21)". */
    fun probable(c: JSONObject): String {
        val p = c.arr("probables").objects().firstOrNull() ?: return ""
        val a = p.obj("athlete")
        val name = a.s("shortName").ifBlank { a.s("displayName") }
        if (name.isBlank()) return ""
        val rec = p.s("record").ifBlank { p.arr("statistics").objects().firstOrNull { it.s("abbreviation") == "W-L" || it.s("name") == "record" }.s("displayValue") }
        val era = p.arr("statistics").objects().firstOrNull { it.s("abbreviation") == "ERA" || it.s("name") == "ERA" }.s("displayValue")
        val extra = listOf(rec, era).filter { it.isNotBlank() }.joinToString(", ")
        return if (extra.isBlank()) name else "$name ($extra)"
    }

    /**
     * League leaders. ESPN has two shapes: { leaders: { categories: [...] } } and { categories: [...] }, and leader rows
     * either inline the athlete or reference it.
     */
    fun leaders(root: JSONObject): List<LeaderBoard> {
        val cats = root.obj("leaders").arr("categories") ?: root.arr("categories") ?: root.arr("leaders")
        return cats.objects().mapNotNull { c ->
            val name = c.s("displayName").ifBlank { c.s("shortDisplayName") }.ifBlank { c.s("name") }
            val rows = c.arr("leaders").objects().take(10).mapIndexedNotNull { i, l ->
                val a = l.obj("athlete") ?: return@mapIndexedNotNull null
                val n = a.s("displayName").ifBlank { a.s("fullName") }
                if (n.isBlank()) null else LeaderRow(
                    rank = i + 1,
                    athleteId = a.s("id"),
                    name = n,
                    team = l.obj("team").s("abbreviation").ifBlank { a.obj("team").s("abbreviation") },
                    headshot = a.obj("headshot").s("href").ifBlank { a.s("headshot") },
                    value = l.s("displayValue").ifBlank { l.s("value") },
                )
            }
            if (name.isBlank() || rows.isEmpty()) null else LeaderBoard(name, rows)
        }
    }

    /** A team's season stats, grouped by category ("Offense", "Defense", ...). */
    fun teamStats(root: JSONObject): List<Pair<String, List<TeamStat>>> {
        val cats = root.obj("results").obj("stats").arr("categories") ?: root.obj("splits").arr("categories") ?: root.arr("categories")
        return cats.objects().mapNotNull { c ->
            val title = c.s("displayName").ifBlank { c.s("name").replaceFirstChar { it.uppercase() } }
            val stats = c.arr("stats").objects().mapNotNull { st ->
                val label = st.s("displayName").ifBlank { st.s("shortDisplayName") }.ifBlank { st.s("name") }
                val v = st.s("displayValue").ifBlank { st.s("value") }
                if (label.isBlank() || v.isBlank()) null else TeamStat(label, v, st.s("rankDisplayValue"))
            }
            if (stats.isEmpty()) null else title to stats.take(14)
        }
    }

    /**
     * Postseason rounds from a seasontype=3 scoreboard. Games are grouped by the round in their note ("East 1st Round -
     * Game 3" belongs to "East 1st Round"), then into series by matchup.
     */
    fun rounds(games: List<Game>): List<Round> {
        val byRound = LinkedHashMap<String, MutableList<Game>>()
        games.sortedBy { it.start ?: Instant.MAX }.forEach { g ->
            val round = g.note.substringBefore(" - ").trim().ifBlank { "Postseason" }
            byRound.getOrPut(round) { ArrayList() }.add(g)
        }
        return byRound.map { (name, list) ->
            val series = list.groupBy { setOf(it.home.team.id, it.away.team.id) }.values.map { gs ->
                val first = gs.first()
                val a = first.away.team
                val b = first.home.team
                val aw = gs.count { it.state == GameState.POST && it.sideOf(a.id).winner }
                val bw = gs.count { it.state == GameState.POST && it.sideOf(b.id).winner }
                val note = gs.last().note.substringAfter(" - ", "").trim()
                val summary = when {
                    gs.size == 1 && gs[0].state == GameState.POST -> "Final"
                    gs.size == 1 -> Fmt.whenText(gs[0].start)
                    aw == bw -> "Series tied $aw-$bw"
                    else -> "${if (aw > bw) a.abbr else b.abbr} leads ${maxOf(aw, bw)}-${minOf(aw, bw)}"
                }.let { if (note.isNotBlank() && gs.size > 1 && !note.startsWith("Game", true)) note else it }
                Series(a, b, summary, gs)
            }
            Round(name, series)
        }
    }

    /** ESPN's league ids inside search uids ("s:40~l:46~a:1966"), mapped to Sideline's leagues. */
    private val uidLeagues = mapOf(
        "28" to "NFL", "46" to "NBA", "10" to "MLB", "90" to "NHL", "59" to "WNBA", "23" to "CFB", "41" to "MCBB",
        "54" to "WCBB", "700" to "EPL", "770" to "MLS", "740" to "LALIGA", "720" to "BUNDESLIGA", "730" to "SERIEA",
        "710" to "LIGUE1", "775" to "UCL", "3321" to "UFC",
    )

    /**
     * Team stats for a game, away against home. Most sports send one flat list ({label, displayValue}); baseball and
     * some others group them ({name: "batting", stats: [...]}), which becomes a header line followed by that group's
     * stats. Lines with no value on either side are dropped, and long groups are cut to their first ten stats.
     */
    fun teamStatLines(awayBox: JSONObject?, homeBox: JSONObject?): List<StatLine> {
        fun label(st: JSONObject) = st.s("label").ifBlank { st.s("displayName") }.ifBlank { st.s("abbreviation") }.ifBlank { st.s("name") }
        fun key(group: String, st: JSONObject) = group + "/" + st.s("name").ifBlank { label(st) }
        fun flatten(box: JSONObject?): Map<String, String> {
            val out = HashMap<String, String>()
            box.arr("statistics").objects().forEach { st ->
                val inner = st.arr("stats")
                if (inner != null) inner.objects().forEach { s -> out[key(st.s("name").ifBlank { label(st) }, s)] = s.s("displayValue") }
                else out[key("", st)] = st.s("displayValue")
            }
            return out
        }
        val away = flatten(awayBox)
        val home = flatten(homeBox)
        val base = homeBox.arr("statistics").objects().ifEmpty { awayBox.arr("statistics").objects() }
        val lines = ArrayList<StatLine>()
        base.forEach { st ->
            val inner = st.arr("stats")
            if (inner != null) {
                val group = st.s("name").ifBlank { label(st) }
                val rows = inner.objects().mapNotNull { s ->
                    val k = key(group, s)
                    val a = away[k].orEmpty()
                    val h = home[k].orEmpty()
                    if (label(s).isBlank() || (a.isBlank() && h.isBlank())) null else StatLine(label(s), a, h)
                }.take(10)
                if (rows.isNotEmpty()) {
                    lines.add(StatLine(st.s("displayName").ifBlank { group.replaceFirstChar { it.uppercase() } }, "", "", header = true))
                    lines.addAll(rows)
                }
            } else {
                val k = key("", st)
                val a = away[k].orEmpty()
                val h = home[k].orEmpty()
                if (label(st).isNotBlank() && (a.isNotBlank() || h.isNotBlank())) lines.add(StatLine(label(st), a, h))
            }
        }
        return lines
    }

    /** Players from ESPN's search feed, with their league when Sideline covers it. */
    fun searchPlayers(root: JSONObject): List<PlayerHit> {
        val groups = root.arr("results").objects()
        val items = groups.filter { it.s("type").equals("player", true) }.flatMap { it.arr("contents").objects() }
            .ifEmpty { root.arr("items").objects().filter { it.s("type").equals("player", true) } }
        return items.mapNotNull { x ->
            val name = x.s("displayName").ifBlank { x.s("name") }
            val uid = x.s("uid")
            val id = Regex("""a:(\d+)""").find(uid)?.groupValues?.get(1) ?: x.s("id")
            if (name.isBlank() || id.isBlank()) return@mapNotNull null
            val lid = Regex("""l:(\d+)""").find(uid)?.groupValues?.get(1)
            val league = lid?.let { uidLeagues[it] }?.let { Leagues.of(it) }
            PlayerHit(
                id = id,
                name = name,
                detail = x.s("subtitle").ifBlank { x.s("description") },
                headshot = x.obj("image").s("default").ifBlank { x.obj("headshot").s("href") },
                league = league,
            )
        }.distinctBy { it.id }
    }

    /** Teams whose name, short name or abbreviation matches [q], best matches first. */
    fun matchTeams(q: String, teams: List<Pair<League, TeamRef>>): List<Pair<League, TeamRef>> {
        val t = q.trim().lowercase()
        if (t.length < 2) return emptyList()
        fun score(r: TeamRef): Int = when {
            r.abbr.equals(t, true) -> 0
            r.name.lowercase().startsWith(t) || r.shortName.lowercase().startsWith(t) -> 1
            r.name.lowercase().split(" ").any { it.startsWith(t) } -> 2
            r.name.lowercase().contains(t) -> 3
            else -> 9
        }
        return teams.map { it to score(it.second) }.filter { it.second < 9 }.sortedBy { it.second }.map { it.first }.take(30)
    }

    // ---------- backup ----------

    /** Everything the user set up, as one JSON document. */
    fun backup(): JSONObject {
        val favs = JSONArray()
        Favorites.list.forEach { f ->
            favs.put(JSONObject().put("league", f.league.key).put("id", f.team.id).put("abbr", f.team.abbr).put("name", f.team.name)
                .put("short", f.team.shortName).put("logo", f.team.logo).put("color", f.team.color))
        }
        val players = JSONArray()
        Players.list.forEach { fp ->
            players.put(JSONObject().put("league", fp.league.key).put("id", fp.player.id).put("name", fp.player.name)
                .put("headshot", fp.player.headshot).put("team", fp.player.teamName).put("teamId", fp.player.teamId).put("pos", fp.player.position))
        }
        return JSONObject()
            .put("app", "Sideline").put("format", 1)
            .put("favorites", favs)
            .put("players", players)
            .put("pins", JSONArray(Settings.pins.toList()))
            .put("name", Settings.name.value)
            .put("place", Where.place.value?.let { p -> JSONObject().put("lat", p.lat).put("lon", p.lon).put("label", p.label).put("gps", p.fromGps) })
    }
}
