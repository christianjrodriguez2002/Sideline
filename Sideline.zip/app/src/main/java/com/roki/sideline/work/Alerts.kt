package com.roki.sideline.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.roki.sideline.MainActivity
import com.roki.sideline.R
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Streaming
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** Game-time and final-score alerts for favorite teams. Checks every 30 minutes while on. */
object Alerts {
    const val CHANNEL = "sideline_games"
    private const val WORK = "sideline_alerts"

    fun startOn(context: Context) = Favorites.prefs(context).getBoolean("alertStart", false)
    fun finalOn(context: Context) = Favorites.prefs(context).getBoolean("alertFinal", false)

    fun set(context: Context, start: Boolean, final: Boolean) {
        Favorites.prefs(context).edit().putBoolean("alertStart", start).putBoolean("alertFinal", final).apply()
        sync(context)
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL, "Game alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Game-time reminders and final scores for your teams"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    fun sync(context: Context) {
        val wm = WorkManager.getInstance(context)
        if (startOn(context) || finalOn(context)) {
            val req = PeriodicWorkRequestBuilder<AlertWorker>(30, TimeUnit.MINUTES).build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        } else {
            wm.cancelUniqueWork(WORK)
        }
    }

    fun canNotify(context: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun notify(context: Context, id: Int, title: String, text: String) {
        if (!canNotify(context)) return
        val pi = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_sideline)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (e: SecurityException) {
            // notifications were turned off in the meantime
        }
    }

    fun scoreLine(g: Game): String = "${g.away.team.abbr} ${g.away.score}, ${g.home.team.abbr} ${g.home.score}"
}

class AlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        Favorites.load(ctx)
        com.roki.sideline.data.Settings.load(ctx)
        val favs = Favorites.list.toList()
        if (favs.isEmpty()) return Result.success()
        val prefs = Favorites.prefs(ctx)
        val sent = (prefs.getString("alertsSent", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
        val now = Instant.now()
        val today = LocalDate.now(Fmt.zone())

        for (league in favs.map { it.league }.distinctBy { it.key }) {
            val ids = favs.filter { it.league.key == league.key }.map { it.team.id }.toSet()
            if (!league.teamBased) continue
            val games = (if (league.weekly) runCatching { Espn.week(league, null, force = true).games }.getOrDefault(emptyList())
            else listOf(today.minusDays(1), today).flatMap { d ->
                runCatching { Espn.day(league, d, force = true) }.getOrDefault(emptyList())
            }).distinctBy { it.id }.filter { g -> ids.any { g.involves(it) } }

            for (g in games) {
                val start = g.start ?: continue
                if (Alerts.startOn(ctx) && g.state == GameState.PRE) {
                    val mins = Duration.between(now, start).toMinutes()
                    val key = "s${g.id}"
                    if (mins in 0..75 && key !in sent) {
                        val tv = g.broadcasts.joinToString(", ") { it.network }
                        val stream = Streaming.describe(league, g.broadcasts).firstOrNull()
                        val text = listOfNotNull(
                            "${g.away.team.name} at ${g.home.team.name}, ${Fmt.time(start)}",
                            if (tv.isNotBlank()) "On $tv" else null,
                            stream,
                        ).joinToString("\n")
                        Alerts.notify(ctx, g.id.hashCode(), "${league.label}: ${g.away.team.abbr} @ ${g.home.team.abbr} starts soon", text)
                        sent.add(key)
                    }
                }
                if (Alerts.finalOn(ctx) && g.state == GameState.POST) {
                    val key = "f${g.id}"
                    if (key !in sent && Duration.between(start, now).toHours() < 10) {
                        val fav = ids.first { g.involves(it) }
                        val mine = g.sideOf(fav)
                        val result = when {
                            mine.winner -> "W"
                            g.opponentOf(fav).winner -> "L"
                            else -> ""
                        }
                        Alerts.notify(ctx, g.id.hashCode() + 1, "Final${if (result.isNotEmpty()) " ($result)" else ""}: ${Alerts.scoreLine(g)}",
                            listOf(g.statusDetail, "${mine.team.name} ${mine.record}".trim()).filter { it.isNotBlank() }.joinToString("\n"))
                        sent.add(key)
                    } else if (key !in sent) {
                        sent.add(key) // old finals: remember silently so they never fire later
                    }
                }
            }
        }
        prefs.edit().putString("alertsSent", sent.takeLast(300).joinToString(",")).apply()
        return Result.success()
    }
}
