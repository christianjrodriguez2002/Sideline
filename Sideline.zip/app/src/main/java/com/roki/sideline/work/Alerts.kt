package com.roki.sideline.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.roki.sideline.MainActivity
import com.roki.sideline.R
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.League
import com.roki.sideline.data.Streaming
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** The kinds of alert, each with its own switch in Settings. */
enum class Alert(val pref: String, val title: String, val sub: String) {
    START("alertStart", "Starting soon", "An hour before your teams play"),
    LINEUP("alertLineup", "Lineups", "Starting lineups or probable pitchers, when posted"),
    SCORE("alertScore", "Your team scores", "Every time your team puts points on the board"),
    CLOSE("alertClose", "Close games", "Tight game late, once per game"),
    LIVE("alertLive", "Live score", "A quiet notification that updates while your team plays"),
    FINAL("alertFinal", "Final scores", "When your teams' games end"),
}

/**
 * Alerts for followed teams. A 30-minute check handles starts, lineups and finals; while one of your teams is playing
 * a faster loop (every 2 minutes) handles scores, close games, the live notification and quick finals.
 */
object Alerts {
    const val CHANNEL = "sideline_games"
    const val LIVE_CHANNEL = "sideline_live"
    private const val WORK = "sideline_alerts"
    private const val LIVE_WORK = "sideline_live"

    fun on(context: Context, a: Alert) = Favorites.prefs(context).getBoolean(a.pref, false)
    fun startOn(context: Context) = on(context, Alert.START)
    fun finalOn(context: Context) = on(context, Alert.FINAL)
    fun anyOn(context: Context) = Alert.entries.any { on(context, it) }
    private fun liveOn(context: Context) = on(context, Alert.SCORE) || on(context, Alert.CLOSE) || on(context, Alert.LIVE) || on(context, Alert.FINAL)

    fun set(context: Context, a: Alert, value: Boolean) {
        Favorites.prefs(context).edit().putBoolean(a.pref, value).apply()
        if (a == Alert.LIVE && !value) NotificationManagerCompat.from(context).cancel(LIVE_ID)
        sync(context)
    }

    /** Kept for older callers: start and final together. */
    fun set(context: Context, start: Boolean, final: Boolean) {
        Favorites.prefs(context).edit().putBoolean(Alert.START.pref, start).putBoolean(Alert.FINAL.pref, final).apply()
        sync(context)
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Game alerts", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Starts, scores, close games and finals for your teams"
            })
            nm.createNotificationChannel(NotificationChannel(LIVE_CHANNEL, "Live score", NotificationManager.IMPORTANCE_LOW).apply {
                description = "A silent score that updates while your team plays"
            })
        }
    }

    fun sync(context: Context) {
        val wm = WorkManager.getInstance(context)
        if (anyOn(context)) {
            val req = PeriodicWorkRequestBuilder<AlertWorker>(30, TimeUnit.MINUTES).build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        } else {
            wm.cancelUniqueWork(WORK)
            wm.cancelUniqueWork(LIVE_WORK)
        }
    }

    /** Start (or keep) the fast loop. Called when a followed game is live. */
    fun kickLive(context: Context, delayMinutes: Long = 0) {
        if (!liveOn(context)) return
        val req = OneTimeWorkRequestBuilder<LiveWorker>().setInitialDelay(delayMinutes, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniqueWork(LIVE_WORK, ExistingWorkPolicy.REPLACE, req)
    }

    fun canNotify(context: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(context).areNotificationsEnabled()

    private fun openApp(context: Context) = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    fun notify(context: Context, id: Int, title: String, text: String) {
        if (!canNotify(context)) return
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_sideline)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (e: SecurityException) {
            // notifications were turned off in the meantime
        }
    }

    const val LIVE_ID = 7_000_001

    /** The silent, updating live-score notification. One line per live game. */
    fun showLive(context: Context, games: List<Game>) {
        if (!canNotify(context)) return
        if (games.isEmpty()) { NotificationManagerCompat.from(context).cancel(LIVE_ID); return }
        val lines = games.joinToString("\n") { "${scoreLine(it)} · ${it.statusShort}" }
        val n = NotificationCompat.Builder(context, LIVE_CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_sideline)
            .setContentTitle(if (games.size == 1) scoreLine(games[0]) else "${games.size} of your games are live")
            .setContentText(if (games.size == 1) games[0].statusShort else lines)
            .setStyle(NotificationCompat.BigTextStyle().bigText(lines))
            .setContentIntent(openApp(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(LIVE_ID, n)
        } catch (e: SecurityException) {
        }
    }

    fun scoreLine(g: Game): String = "${g.away.team.abbr} ${g.away.score}, ${g.home.team.abbr} ${g.home.score}"

    /** The period a live game is in, from its line score (1-based), or 0 if unknown. */
    fun period(g: Game): Int = maxOf(g.home.linescores.size, g.away.linescores.size)

    /** Minutes on the clock ("4:12" is 4.2) or, for soccer, the match minute ("78'" is 78). Null when unknown. */
    fun clockMinutes(g: Game): Double? {
        val c = g.clock.trim().substringBefore("+").replace("'", "").trim()
        if (c.isBlank()) return null
        val parts = c.split(":")
        return if (parts.size == 2) (parts[0].toDoubleOrNull() ?: return null) + (parts[1].toDoubleOrNull() ?: 0.0) / 60.0
        else c.toDoubleOrNull()
    }

    /** True when a live game is tight and late enough to be worth a nudge. */
    fun isClose(g: Game): Boolean {
        if (g.state != GameState.IN) return false
        val a = g.away.score.toIntOrNull() ?: return false
        val h = g.home.score.toIntOrNull() ?: return false
        val margin = kotlin.math.abs(a - h)
        val p = period(g)
        val l = g.league
        val reg = l.regularPeriods
        val mins = clockMinutes(g)
        return when (l.sport) {
            "basketball" -> p > reg || (p == reg && margin <= 5 && (mins ?: 99.0) <= 5.0)
            "football" -> p > reg || (p == reg && margin <= 8 && (mins ?: 99.0) <= 8.0)
            "hockey" -> p > reg || (p == reg && margin <= 1)
            "baseball" -> p >= 8 && margin <= 2
            "soccer" -> (p >= 2 || (mins ?: 0.0) >= 46) && (mins ?: 0.0) >= 75 && margin <= 1
            "rugby" -> (mins ?: 0.0) >= 65 && margin <= 7
            else -> false
        }
    }
}

/** Load today's (and last night's) games for followed teams, grouped by league. */
private suspend fun followedGames(force: Boolean): List<Pair<Set<String>, Game>> {
    val favs = Favorites.list.toList()
    val today = LocalDate.now(Fmt.zone())
    val out = ArrayList<Pair<Set<String>, Game>>()
    for (league in favs.map { it.league }.distinctBy { it.key }) {
        if (!league.teamBased) continue
        val ids = favs.filter { it.league.key == league.key }.map { it.team.id }.toSet()
        val games = (if (league.weekly) runCatching { Espn.week(league, null, force = force).games }.getOrDefault(emptyList())
        else listOf(today.minusDays(1), today).flatMap { d -> runCatching { Espn.day(league, d, force = force) }.getOrDefault(emptyList()) })
            .distinctBy { it.id }.filter { g -> ids.any { g.involves(it) } }
        games.forEach { out.add(ids to it) }
    }
    return out
}

private class Sent(private val ctx: Context) {
    private val prefs = Favorites.prefs(ctx)
    val keys = (prefs.getString("alertsSent", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
    operator fun contains(k: String) = k in keys
    fun add(k: String) { if (k !in keys) keys.add(k) }
    fun save() = prefs.edit().putString("alertsSent", keys.takeLast(400).joinToString(",")).apply()
}

private fun finalAlert(ctx: Context, ids: Set<String>, g: Game, sent: Sent) {
    val start = g.start ?: return
    val key = "f${g.id}"
    if (key in sent) return
    sent.add(key)
    if (!Alerts.on(ctx, Alert.FINAL) || Duration.between(start, Instant.now()).toHours() >= 10) return
    val fav = ids.first { g.involves(it) }
    val mine = g.sideOf(fav)
    val result = when {
        mine.winner -> "W"
        g.opponentOf(fav).winner -> "L"
        else -> ""
    }
    Alerts.notify(ctx, g.id.hashCode() + 1, "Final${if (result.isNotEmpty()) " ($result)" else ""}: ${Alerts.scoreLine(g)}",
        listOf(g.statusDetail, "${mine.team.name} ${mine.record}".trim()).filter { it.isNotBlank() }.joinToString("\n"))
}

class AlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        Favorites.load(ctx)
        com.roki.sideline.data.Settings.load(ctx)
        if (Favorites.list.isEmpty()) return Result.success()
        val sent = Sent(ctx)
        val now = Instant.now()
        var anyLive = false

        for ((ids, g) in followedGames(force = true)) {
            val league = g.league
            val start = g.start ?: continue
            when (g.state) {
                GameState.IN -> anyLive = true
                GameState.POST -> finalAlert(ctx, ids, g, sent)
                GameState.PRE -> {
                    val mins = Duration.between(now, start).toMinutes()
                    if (Alerts.on(ctx, Alert.START) && mins in 0..75 && "s${g.id}" !in sent) {
                        val tv = g.broadcasts.joinToString(", ") { it.network }
                        val stream = Streaming.describe(league, g.broadcasts).firstOrNull()
                        val text = listOfNotNull(
                            "${g.away.team.name} at ${g.home.team.name}, ${Fmt.time(start)}",
                            if (tv.isNotBlank()) "On $tv" else null,
                            stream,
                        ).joinToString("\n")
                        Alerts.notify(ctx, g.id.hashCode(), "${league.label}: ${g.away.team.abbr} @ ${g.home.team.abbr} starts soon", text)
                        sent.add("s${g.id}")
                    }
                    if (Alerts.on(ctx, Alert.LINEUP) && mins in 0..150 && "l${g.id}" !in sent) lineupAlert(ctx, league, g, sent)
                    // Wake the fast loop for kickoff.
                    if (mins in 0..30) Alerts.kickLive(ctx, mins.coerceAtLeast(1))
                }
            }
        }
        sent.save()
        if (anyLive) Alerts.kickLive(ctx)
        return Result.success()
    }

    private suspend fun lineupAlert(ctx: Context, league: League, g: Game, sent: Sent) {
        val text = if (g.home.probable.isNotBlank() || g.away.probable.isNotBlank()) {
            "${g.away.team.abbr}: ${g.away.probable.ifBlank { "TBD" }}\n${g.home.team.abbr}: ${g.home.probable.ifBlank { "TBD" }}"
        } else {
            val d = runCatching { Espn.game(league, g.id, force = true) }.getOrNull() ?: return
            if (d.lineups.isEmpty()) return
            d.lineups.joinToString("\n") { (team, players) -> "$team: " + players.filter { it.starter }.take(11).joinToString(", ") { it.name.substringAfterLast(' ') } }
        }
        val title = if (g.home.probable.isNotBlank() || g.away.probable.isNotBlank()) "Probable pitchers: ${g.away.team.abbr} @ ${g.home.team.abbr}"
        else "Lineups are out: ${g.away.team.abbr} @ ${g.home.team.abbr}"
        Alerts.notify(ctx, g.id.hashCode() + 2, title, text)
        sent.add("l${g.id}")
    }
}

/** Runs every 2 minutes while a followed game is live, then stops on its own. */
class LiveWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        Favorites.load(ctx)
        if (Favorites.list.isEmpty()) return Result.success()
        val sent = Sent(ctx)
        val prefs = Favorites.prefs(ctx)
        val all = followedGames(force = true)
        val live = all.filter { it.second.state == GameState.IN }

        for ((ids, g) in all) {
            if (g.state == GameState.POST) finalAlert(ctx, ids, g, sent)
            if (g.state != GameState.IN) continue
            val fav = ids.first { g.involves(it) }
            val mine = g.sideOf(fav)
            // Your team scored: their score went up since the last look.
            val lastKey = "score:${g.id}"
            val before = prefs.getInt(lastKey, -1)
            val now = mine.score.toIntOrNull() ?: -1
            if (before in 0 until now && Alerts.on(ctx, Alert.SCORE)) {
                Alerts.notify(ctx, g.id.hashCode() + 3, "${mine.team.abbr} scores! ${Alerts.scoreLine(g)}", g.statusShort)
            }
            if (now >= 0) prefs.edit().putInt(lastKey, now).apply()
            if (Alerts.on(ctx, Alert.CLOSE) && Alerts.isClose(g) && "c${g.id}" !in sent) {
                Alerts.notify(ctx, g.id.hashCode() + 4, "Close game: ${Alerts.scoreLine(g)}", "${g.statusShort} · ${g.broadcasts.firstOrNull()?.network ?: g.league.short}")
                sent.add("c${g.id}")
            }
        }
        sent.save()
        if (Alerts.on(ctx, Alert.LIVE)) Alerts.showLive(ctx, live.map { it.second })
        else Alerts.showLive(ctx, emptyList())
        if (live.isNotEmpty()) Alerts.kickLive(ctx, 2)
        return Result.success()
    }
}
