package com.roki.sideline.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Drive
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Predict
import com.roki.sideline.data.Recap

/** How the home team's win chance moved through the game: above the middle line favors home, below favors away. */
@Composable
fun WinProbabilityChart(g: Game, points: List<Double>, awayC: Color, homeC: Color) {
    if (points.size < 5) return
    val now = points.last()
    val leader = if (now >= 50) g.home.team.abbr else g.away.team.abbr
    val lead = if (now >= 50) now else 100 - now
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(if (g.state == GameState.POST) "Win probability through the game" else "Win probability")
        Text("$leader ${Predict.pctText(lead)}", style = Type.Title, color = Palette.Text)
        Row {
            Column(Modifier.width(40.dp).height(130.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text(g.home.team.abbr, style = Type.Label, color = Palette.Sub)
                Text("50%", style = Type.Caption, color = Palette.Faint)
                Text(g.away.team.abbr, style = Type.Label, color = Palette.Sub)
            }
            val mid = Palette.Faint
            Canvas(
                Modifier
                    .weight(1f)
                    .height(130.dp)
                    .semantics { contentDescription = "Win probability chart. $leader now ${Predict.pctText(lead)}." }
            ) {
                val w = size.width
                val h = size.height
                fun x(i: Int) = w * i / (points.size - 1)
                fun y(v: Double) = (h * (1 - v / 100)).toFloat()
                drawLine(mid, Offset(0f, h / 2), Offset(w, h / 2), strokeWidth = 1.5f)
                // shade the space between the line and the middle: home color above, away color below
                for (i in 1 until points.size) {
                    val a = points[i - 1]
                    val b = points[i]
                    val area = Path().apply {
                        moveTo(x(i - 1), h / 2); lineTo(x(i - 1), y(a)); lineTo(x(i), y(b)); lineTo(x(i), h / 2); close()
                    }
                    drawPath(area, (if ((a + b) / 2 >= 50) homeC else awayC).copy(alpha = 0.35f))
                }
                val line = Path().apply {
                    moveTo(0f, y(points[0]))
                    for (i in 1 until points.size) lineTo(x(i), y(points[i]))
                }
                drawPath(line, Color.White.copy(alpha = 0.9f), style = Stroke(width = 3f))
                drawCircle(Color.White, radius = 5f, center = Offset(w, y(now)))
            }
        }
    }
}

private fun driveColors(d: Drive): Pair<Color, Color> {
    val r = d.result.lowercase()
    return when {
        r.contains("touchdown") || r == "td" -> Palette.Win to Color(0xFF0B0F14)
        r.contains("field goal") && !r.contains("missed") && !r.contains("block") || r == "fg" -> Palette.Gold to Color(0xFF231700)
        r.contains("interception") || r.contains("fumble") || r.contains("downs") || r.contains("safety") || r.contains("missed") || r.contains("block") ->
            Palette.Loss to Color(0xFF0B0F14)
        else -> Palette.Raised2 to Palette.Text
    }
}

/** Every drive, newest first: team, how it ended, plays, yards and time. */
@Composable
fun DrivesPanel(drives: List<Drive>) {
    if (drives.isEmpty()) return
    var all by remember { mutableStateOf(false) }
    val list = drives.asReversed()
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("Drives", action = if (list.size > 8) (if (all) "Less" else "All ${list.size}") else null, onAction = { all = !all })
        (if (all) list else list.take(8)).forEach { d ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(d.logo, 24.dp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        listOfNotNull(d.team.ifBlank { null }, d.start.ifBlank { null }?.let { "from $it" }).joinToString(" "),
                        style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    val line = d.description.ifBlank {
                        listOfNotNull(d.plays?.let { "$it plays" }, d.yards?.let { "$it yards" }, d.time.ifBlank { null }).joinToString(", ")
                    }
                    if (line.isNotBlank()) Sub(line, maxLines = 1)
                }
                val (bg, fg) = driveColors(d)
                Tag(d.result.uppercase(), bg, fg)
            }
        }
    }
}

/** ESPN's written recap: the first three paragraphs, then the rest on tap. */
@Composable
fun RecapPanel(recap: Recap) {
    var all by remember(recap.headline) { mutableStateOf(false) }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader("Recap")
        if (recap.headline.isNotBlank()) Text(recap.headline, style = Type.Heading, color = Palette.Text)
        (if (all) recap.paragraphs else recap.paragraphs.take(3)).forEach { p ->
            Text(p, style = Type.Body, color = Palette.Text)
        }
        if (recap.paragraphs.size > 3) {
            Text(
                if (all) "Show less" else "Read full recap",
                Modifier.clickable { all = !all }.padding(top = 2.dp),
                style = Type.BodyStrong,
                color = Palette.Blue
            )
        }
    }
}
