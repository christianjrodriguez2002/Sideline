package com.roki.sideline.data

import java.time.DayOfWeek
import java.time.ZoneId

/** How a broadcast relates to you. */
enum class Reach { NATIONAL, LOCAL_YOURS, LOCAL_UNKNOWN, LOCAL_ELSEWHERE }

data class Watch(
    val network: String,
    val reach: Reach,
    /** One plain sentence: where to watch it, from where you are. */
    val text: String,
    /** A web search that finds this channel on your TV lineup, for over-the-air networks. */
    val findUrl: String? = null,
)

/**
 * Turns ESPN's broadcast list into "what you can actually watch, where you are": national networks with the app they
 * usually stream on, the local channel if you're inside a team's TV area, or the out-of-market package if you're not.
 */
object Tv {
    private val ota = setOf("ABC", "CBS", "FOX", "NBC", "CW", "The CW", "ION", "Telemundo", "Univision")

    /** Regional sports networks and their streaming apps (first match wins, by name prefix). */
    private val rsnApps = listOf(
        "FanDuel" to "FanDuel Sports Network app", "FDSN" to "FanDuel Sports Network app", "Bally" to "FanDuel Sports Network app",
        "NBC Sports" to "NBC Sports app", "NBCS" to "NBC Sports app",
        "Spectrum SportsNet" to "Spectrum SportsNet app", "SportsNet LA" to "Spectrum SportsNet app",
        "MSG" to "Gotham Sports app", "YES" to "Gotham Sports app", "SNY" to "SNY app", "NESN" to "NESN 360",
        "Marquee" to "Marquee Sports Network app", "Monumental" to "Monumental+", "MASN" to "MASN+",
        "ROOT" to "ROOT SPORTS+", "Root Sports" to "ROOT SPORTS+", "SportsNet Pittsburgh" to "SNP+", "SNP" to "SNP+",
        "CHSN" to "CHSN app", "Chicago Sports Network" to "CHSN app", "Space City" to "SCHN+", "SCHN" to "SCHN+",
        "Altitude" to "Altitude+", "Sportsnet" to "Sportsnet+", "TSN" to "TSN+", "RDS" to "RDS app", "TVA Sports" to "TVA+",
        "KJZZ" to "the team's app", "Victory+" to "Victory+", "Arizona's Family" to "Arizona's Family app",
    )

    private fun rsnApp(n: String): String? = rsnApps.firstOrNull { n.startsWith(it.first, true) }?.second

    private fun findUrl(network: String, place: UserPlace?): String =
        "https://www.google.com/search?q=" + java.net.URLEncoder.encode("$network channel " + (place?.label ?: "near me"), "UTF-8")

    fun plan(g: Game, place: UserPlace?, broadcasts: List<Broadcast> = g.broadcasts): List<Watch> {
        val league = g.league
        val out = ArrayList<Watch>()
        broadcasts.distinctBy { it.network }.forEach { b ->
            val n = b.network
            val app = Streaming.appFor(n)
            if (b.national) {
                val isOta = ota.any { it.equals(n, true) }
                val text = buildString {
                    append(if (isOta) "On your local $n station" else n)
                    if (app != null) append(" · usually streams on $app")
                }
                out.add(Watch(n, Reach.NATIONAL, text, if (isOta) findUrl(n, place) else null))
            } else {
                val market = b.market.lowercase()
                val team = when {
                    market.contains("home") -> g.home
                    market.contains("away") -> g.away
                    else -> null
                }
                val teams = if (team != null) listOf(team) else listOf(g.home, g.away)
                val reach = teams.map { Places.inMarket(place, it.team, league) }
                val stream = rsnApp(n) ?: app
                val who = (team ?: g.home).team.shortName
                when {
                    reach.any { it == true } -> {
                        val mine = teams[reach.indexOf(true)]
                        out.add(Watch(n, Reach.LOCAL_YOURS, "Your local channel: $n (${mine.team.shortName} TV)" +
                            (stream?.let { " · stream it on $it" } ?: ""), findUrl(n, place)))
                    }
                    reach.all { it == false } -> out.add(Watch(n, Reach.LOCAL_ELSEWHERE,
                        "$n is the $who's local channel — blacked out where you are" +
                            (league.outOfMarket?.let { "; watch with $it" } ?: "")))
                    else -> out.add(Watch(n, Reach.LOCAL_UNKNOWN, "$n (local TV for the $who area)" +
                        (stream?.let { " · $it" } ?: "") +
                        (if (place == null) " — set your location in Settings to see if you get it" else "")))
                }
            }
        }
        return out.sortedBy { it.reach.ordinal }
    }

    /** The networks worth showing on a score card: national ones and the local channel you actually get. */
    fun cardNetworks(g: Game, place: UserPlace?): List<Pair<String, Boolean>> =
        plan(g, place).filter { it.reach != Reach.LOCAL_ELSEWHERE }.map { it.network to (it.reach == Reach.LOCAL_YOURS) }

    /** NFL Sunday-afternoon CBS/FOX games are regional; say so instead of promising a game. */
    fun regionalNote(g: Game): String? {
        if (g.league.key != "NFL" || g.start == null) return null
        val et = g.start.atZone(ZoneId.of("America/New_York"))
        val cbsFox = g.broadcasts.any { it.network.equals("CBS", true) || it.network.equals("FOX", true) }
        return if (cbsFox && et.dayOfWeek == DayOfWeek.SUNDAY && et.hour in 12..17)
            "Sunday afternoon CBS/FOX games are regional: your station airs the game picked for your area (NFL Sunday Ticket has them all)."
        else null
    }
}
