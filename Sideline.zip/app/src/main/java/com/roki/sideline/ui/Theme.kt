package com.roki.sideline.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.TeamRef
import java.time.LocalDate

/** Sideline's palette: a deep night-stadium dark with electric blue, gold and a broadcast red for live. */
object Palette {
    val Bg = Color(0xFF070A10)
    val Surface = Color(0xFF0F141C)
    val Raised = Color(0xFF161D28)
    val Raised2 = Color(0xFF1D2633)
    val Line = Color(0xFF263142)
    val Text = Color(0xFFF2F5FA)
    val Sub = Color(0xFF9AA6B8)
    val Faint = Color(0xFF5E6A7D)
    val Blue = Color(0xFF3B82F6)
    val BlueSoft = Color(0xFF1E3A6B)
    val Gold = Color(0xFFF5B83D)
    val Live = Color(0xFFFF3B30)
    val Win = Color(0xFF34D399)
    val Loss = Color(0xFFF87171)
}

private val Scheme = darkColorScheme(
    primary = Palette.Blue,
    onPrimary = Color.White,
    primaryContainer = Palette.BlueSoft,
    onPrimaryContainer = Color(0xFFDCE8FF),
    secondary = Palette.Gold,
    onSecondary = Color(0xFF231700),
    secondaryContainer = Color(0xFF3A2C0A),
    onSecondaryContainer = Color(0xFFFFE3A6),
    tertiary = Palette.Win,
    tertiaryContainer = Color(0xFF0D3B2B),
    onTertiaryContainer = Color(0xFFB9F5DD),
    background = Palette.Bg,
    onBackground = Palette.Text,
    surface = Palette.Surface,
    onSurface = Palette.Text,
    surfaceVariant = Palette.Raised,
    onSurfaceVariant = Palette.Sub,
)

/** Type scale: heavy, tight headlines like a broadcast graphic; tabular numbers for scores. */
object Type {
    val Display = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp, lineHeight = 34.sp)
    val Title = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.2).sp, lineHeight = 24.sp)
    val Heading = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold, lineHeight = 20.sp)
    val Body = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal, lineHeight = 20.sp)
    val BodyStrong = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp)
    val Small = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Normal, lineHeight = 16.sp)
    val Label = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, lineHeight = 14.sp)
    val Score = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Black, fontFeatureSettings = "tnum", lineHeight = 26.sp)
    val ScoreBig = TextStyle(fontSize = 44.sp, fontWeight = FontWeight.Black, fontFeatureSettings = "tnum", letterSpacing = (-1).sp, lineHeight = 48.sp)
    val Num = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Medium, fontFeatureSettings = "tnum", lineHeight = 18.sp)
}

@Composable
fun SidelineTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content)
}

// ---------- navigation ----------

sealed class Route {
    data class TeamR(val league: League, val team: TeamRef) : Route()
    data class GameR(val league: League, val id: String) : Route()
    data class PlayerR(val league: League, val player: Player) : Route()
    data class LeagueR(val league: League) : Route()
    /** One event (Grand Prix, tournament, fight card) picked from a season calendar, by ESPN date. */
    data class EventR(val league: League, val label: String, val date: LocalDate) : Route()
}

class Nav(private val push: (Route) -> Unit) {
    fun team(league: League, team: TeamRef) = push(Route.TeamR(league, team))
    fun game(league: League, id: String) = push(Route.GameR(league, id))
    fun player(league: League, player: Player) = push(Route.PlayerR(league, player))
    fun league(league: League) = push(Route.LeagueR(league))
    fun event(league: League, label: String, date: LocalDate) = push(Route.EventR(league, label, date))
}

val LocalNav = staticCompositionLocalOf<Nav> { error("Nav not provided") }
