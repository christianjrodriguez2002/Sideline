package com.roki.sideline.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.TeamRef
import java.time.LocalDate

/** One set of colors. Dark is the default; Light is the same layout with a paper-white base. */
data class Colors(
    val bg: Color, val surface: Color, val raised: Color, val raised2: Color, val line: Color,
    val text: Color, val sub: Color, val faint: Color, val blue: Color, val blueSoft: Color,
    val gold: Color, val live: Color, val win: Color, val loss: Color, val dark: Boolean,
)

val DarkColors = Colors(
    bg = Color(0xFF06090F), surface = Color(0xFF0E131B), raised = Color(0xFF151C27), raised2 = Color(0xFF1D2635),
    line = Color(0xFF253042), text = Color(0xFFF4F7FB), sub = Color(0xFF9BA8BC), faint = Color(0xFF606D82),
    blue = Color(0xFF3B82F6), blueSoft = Color(0xFF1D3561), gold = Color(0xFFF5B83D), live = Color(0xFFFF3B30),
    win = Color(0xFF34D399), loss = Color(0xFFF87171), dark = true,
)

val LightColors = Colors(
    bg = Color(0xFFF5F7FA), surface = Color(0xFFFFFFFF), raised = Color(0xFFEEF2F7), raised2 = Color(0xFFDFE6EF),
    line = Color(0xFFD3DBE6), text = Color(0xFF0B1220), sub = Color(0xFF4B5868), faint = Color(0xFF8A96A8),
    blue = Color(0xFF2563EB), blueSoft = Color(0xFFBFD3FF), gold = Color(0xFFB7791F), live = Color(0xFFDC2626),
    win = Color(0xFF059669), loss = Color(0xFFDC2626), dark = false,
)

/** Look settings, saved on the phone. Changing any of them recomposes every screen. */
object Look {
    val light = androidx.compose.runtime.mutableStateOf(false)
    /** Text scale: 1.0 normal, 1.15 large, 0.9 compact. */
    val scale = androidx.compose.runtime.mutableFloatStateOf(1f)
    val compact = androidx.compose.runtime.mutableStateOf(false)

    fun load(context: android.content.Context) {
        val p = context.applicationContext.getSharedPreferences("sideline", android.content.Context.MODE_PRIVATE)
        light.value = p.getBoolean("lookLight", false)
        scale.floatValue = p.getFloat("lookScale", 1f)
        compact.value = p.getBoolean("lookCompact", false)
    }

    fun set(context: android.content.Context, light: Boolean = this.light.value, scale: Float = this.scale.floatValue, compact: Boolean = this.compact.value) {
        this.light.value = light
        this.scale.floatValue = scale
        this.compact.value = compact
        context.applicationContext.getSharedPreferences("sideline", android.content.Context.MODE_PRIVATE).edit()
            .putBoolean("lookLight", light).putFloat("lookScale", scale).putBoolean("lookCompact", compact).apply()
    }
}

/** The palette every screen reads. Each property follows the current Look, so a theme switch repaints the app. */
object Palette {
    private val c: Colors get() = if (Look.light.value) LightColors else DarkColors
    val Bg: Color get() = c.bg
    val Surface: Color get() = c.surface
    val Raised: Color get() = c.raised
    val Raised2: Color get() = c.raised2
    val Line: Color get() = c.line
    val Border: Color get() = c.line
    val Text: Color get() = c.text
    val Sub: Color get() = c.sub
    val Faint: Color get() = c.faint
    val Blue: Color get() = c.blue
    val BlueSoft: Color get() = c.blueSoft
    val Gold: Color get() = c.gold
    val Live: Color get() = c.live
    val Win: Color get() = c.win
    val Loss: Color get() = c.loss
    /** White on dark, near-black on light: for text drawn over team colors and photos it stays white. */
    val OnAccent: Color get() = Color.White
    /** Text on BlueSoft and other soft tints: white on dark, ink on light. */
    val OnSoft: Color get() = if (Look.light.value) c.text else Color.White
}

private fun scheme(c: Colors) = if (c.dark) darkColorScheme(
    primary = c.blue, onPrimary = Color.White, primaryContainer = c.blueSoft, onPrimaryContainer = Color(0xFFDCE8FF),
    secondary = c.gold, onSecondary = Color(0xFF231700), secondaryContainer = Color(0xFF3A2C0A), onSecondaryContainer = Color(0xFFFFE3A6),
    tertiary = c.win, tertiaryContainer = Color(0xFF0D3B2B), onTertiaryContainer = Color(0xFFB9F5DD),
    background = c.bg, onBackground = c.text, surface = c.surface, onSurface = c.text, surfaceVariant = c.raised, onSurfaceVariant = c.sub,
) else lightColorScheme(
    primary = c.blue, onPrimary = Color.White, primaryContainer = c.blueSoft, onPrimaryContainer = Color(0xFF0B1220),
    secondary = c.gold, onSecondary = Color.White, background = c.bg, onBackground = c.text, surface = c.surface, onSurface = c.text,
    surfaceVariant = c.raised, onSurfaceVariant = c.sub,
)

/** Text styles that follow the Look's text scale (and shrink a touch more in compact mode). */
object Type {
    private val k: Float get() = Look.scale.floatValue * (if (Look.compact.value) 0.94f else 1f)
    private fun style(size: Float, weight: FontWeight, line: Float, spacing: Float = 0f, tnum: Boolean = false) = TextStyle(
        fontSize = (size * k).sp, fontWeight = weight, lineHeight = (line * k).sp,
        letterSpacing = if (spacing == 0f) androidx.compose.ui.unit.TextUnit.Unspecified else spacing.sp,
        fontFeatureSettings = if (tnum) "tnum" else null,
    )
    val Display: TextStyle get() = style(30f, FontWeight.Black, 34f, -0.5f)
    val Title: TextStyle get() = style(20f, FontWeight.ExtraBold, 24f, -0.2f)
    val Heading: TextStyle get() = style(16f, FontWeight.Bold, 20f)
    val Body: TextStyle get() = style(14f, FontWeight.Normal, 20f)
    val BodyStrong: TextStyle get() = style(14f, FontWeight.SemiBold, 20f)
    val Small: TextStyle get() = style(12f, FontWeight.Normal, 16f)
    val Caption: TextStyle get() = style(11f, FontWeight.SemiBold, 14f)
    val Label: TextStyle get() = style(11f, FontWeight.Bold, 14f, 1.2f)
    val Score: TextStyle get() = style(22f, FontWeight.Black, 26f, tnum = true)
    val ScoreBig: TextStyle get() = style(44f, FontWeight.Black, 48f, -1f, tnum = true)
    val Num: TextStyle get() = style(13f, FontWeight.Medium, 18f, tnum = true)
}

/** Card and list spacing that tightens in compact mode. */
object Space {
    val card: androidx.compose.ui.unit.Dp get() = if (Look.compact.value) 11.dp else 16.dp
    val gap: androidx.compose.ui.unit.Dp get() = if (Look.compact.value) 7.dp else 10.dp
    val list: androidx.compose.ui.unit.Dp get() = if (Look.compact.value) 8.dp else 12.dp
}

@Composable
fun SidelineTheme(content: @Composable () -> Unit) {
    val colors = if (Look.light.value) LightColors else DarkColors
    MaterialTheme(colorScheme = scheme(colors), typography = Typography(), content = content)
}

sealed class Route {
    data class TeamR(val league: League, val team: TeamRef) : Route()
    data class GameR(val league: League, val id: String) : Route()
    data class PlayerR(val league: League, val player: Player) : Route()
    data class LeagueR(val league: League) : Route()
    data class EventR(val league: League, val label: String, val date: LocalDate) : Route()
    object SearchR : Route()
    data class CompareR(val league: League, val a: Player, val b: Player) : Route()
}

class Nav(private val push: (Route) -> Unit) {
    fun team(league: League, team: TeamRef) = push(Route.TeamR(league, team))
    fun game(league: League, id: String) = push(Route.GameR(league, id))
    fun player(league: League, player: Player) = push(Route.PlayerR(league, player))
    fun league(league: League) = push(Route.LeagueR(league))
    fun event(league: League, label: String, date: LocalDate) = push(Route.EventR(league, label, date))
    fun search() = push(Route.SearchR)
    fun compare(league: League, a: Player, b: Player) = push(Route.CompareR(league, a, b))
}

val LocalNav = staticCompositionLocalOf<Nav> { error("Nav not provided") }
