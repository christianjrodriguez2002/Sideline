package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject

/** One finished or current football drive. */
data class Drive(
    val teamId: String, val team: String, val logo: String, val result: String, val description: String,
    val start: String, val yards: Int?, val plays: Int?, val time: String, val scored: Boolean,
)

/** ESPN's written recap, as plain paragraphs. */
data class Recap(val headline: String, val paragraphs: List<String>)

/** One hole on a golf scorecard. [toPar] is ESPN's "-1", "E", "+2" style mark when given. */
data class Hole(val number: Int, val strokes: String, val toPar: String)

object Story {
    private fun JSONObject?.obj(k: String): JSONObject? = this?.optJSONObject(k)
    private fun JSONObject?.arr(k: String): JSONArray? = this?.optJSONArray(k)
    private fun JSONObject?.s(k: String): String = if (this == null || !has(k) || isNull(k)) "" else opt(k)?.toString().orEmpty().let {
        if (it.endsWith(".0")) it.dropLast(2) else it
    }
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    /** Home team's win chance through the game, 0..100, oldest first. Empty when ESPN has fewer than five points. */
    fun winProbability(root: JSONObject): List<Double> {
        val pts = root.arr("winprobability").objects().mapNotNull { p ->
            p.opt("homeWinPercentage")?.toString()?.toDoubleOrNull()?.let { v -> (if (v <= 1.0) v * 100 else v).coerceIn(0.0, 100.0) }
        }
        return if (pts.size >= 5) pts else emptyList()
    }

    /** Every football drive so far, oldest first, with the current one last. */
    fun drives(root: JSONObject): List<Drive> {
        val d = root.obj("drives")
        val list = d.arr("previous").objects() + listOfNotNull(d.obj("current")).filter { cur ->
            d.arr("previous").objects().none { it.s("id") == cur.s("id") && cur.s("id").isNotBlank() }
        }
        return list.mapNotNull { x ->
            val team = x.obj("team")
            val result = x.s("displayResult").ifBlank { x.s("result") }
            val desc = x.s("description")
            if (result.isBlank() && desc.isBlank()) return@mapNotNull null
            Drive(
                teamId = team.s("id"),
                team = team.s("abbreviation").ifBlank { team.s("shortDisplayName") },
                logo = team.arr("logos").objects().firstOrNull().s("href").ifBlank { team.s("logo") },
                result = result.ifBlank { "In progress" },
                description = desc,
                start = x.obj("start").s("text"),
                yards = x.opt("yards")?.toString()?.toDoubleOrNull()?.toInt(),
                plays = x.opt("offensivePlays")?.toString()?.toDoubleOrNull()?.toInt(),
                time = x.obj("timeElapsed").s("displayValue"),
                scored = x.optBoolean("isScore", false),
            )
        }
    }

    private val entities = mapOf(
        "&amp;" to "&", "&quot;" to "\"", "&#39;" to "'", "&apos;" to "'", "&rsquo;" to "’", "&lsquo;" to "‘",
        "&rdquo;" to "”", "&ldquo;" to "“", "&mdash;" to "—", "&ndash;" to "–", "&nbsp;" to " ",
        "&hellip;" to "…", "&lt;" to "<", "&gt;" to ">",
    )

    /** ESPN story HTML to plain paragraphs: tags and embed placeholders removed, entities decoded. */
    fun paragraphs(html: String): List<String> {
        if (html.isBlank()) return emptyList()
        var t = html.replace(Regex("""(?i)<br\s*/?>|</p>|</h\d>|</li>"""), "\n\n")
        t = t.replace(Regex("""(?is)<(script|style|figure|aside)[^>]*>.*?</\1>"""), " ")
        t = t.replace(Regex("""<[^>]+>"""), "")
        t = t.replace(Regex("""\[\[[^\]]*]]"""), "")
        entities.forEach { (k, v) -> t = t.replace(k, v) }
        t = t.replace(Regex("""&#(\d+);""")) { m -> m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: "" }
        return t.split(Regex("""\n\s*\n""")).map { it.replace(Regex("""\s+"""), " ").trim() }.filter { it.length > 1 }
    }

    /** The recap story attached to a game summary, or null when there isn't one yet. */
    fun recap(root: JSONObject): Recap? {
        val a = root.obj("article") ?: return null
        val paras = paragraphs(a.s("story"))
        if (paras.size < 2) return null
        return Recap(a.s("headline"), paras)
    }

    /** Hole-by-hole for each round a golfer has played, when ESPN includes it. Rounds without holes stay empty. */
    fun holes(competitor: JSONObject): List<List<Hole>> = competitor.arr("linescores").objects().map { round ->
        round.arr("linescores").objects().mapIndexedNotNull { i, h ->
            val strokes = h.s("value").ifBlank { h.s("displayValue") }
            if (strokes.isBlank()) null
            else Hole(h.s("period").toIntOrNull() ?: (i + 1), strokes, h.obj("scoreType").s("displayValue"))
        }
    }
}
