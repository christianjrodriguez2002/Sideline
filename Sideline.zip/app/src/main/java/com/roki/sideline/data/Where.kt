package com.roki.sideline.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale
import kotlin.coroutines.resume

/** Where you are, for local TV markets. */
data class UserPlace(val lat: Double, val lon: Double, val label: String, val fromGps: Boolean)

object Where {
    val place = mutableStateOf<UserPlace?>(null)
    private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("sideline", Context.MODE_PRIVATE)

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(context)
        if (p.contains("placeLat")) {
            place.value = UserPlace(
                p.getFloat("placeLat", 0f).toDouble(), p.getFloat("placeLon", 0f).toDouble(),
                p.getString("placeLabel", "") ?: "", p.getBoolean("placeGps", false),
            )
        }
    }

    fun set(context: Context, value: UserPlace?) {
        place.value = value
        val e = prefs(context).edit()
        if (value == null) e.remove("placeLat").remove("placeLon").remove("placeLabel").remove("placeGps")
        else e.putFloat("placeLat", value.lat.toFloat()).putFloat("placeLon", value.lon.toFloat())
            .putString("placeLabel", value.label).putBoolean("placeGps", value.fromGps)
        e.apply()
    }

    fun hasPermission(context: Context) =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** The phone's location, or null. */
    @SuppressLint("MissingPermission")
    suspend fun locate(context: Context): Location? {
        if (!hasPermission(context)) return null
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER, LocationManager.GPS_PROVIDER)
        val last = providers.mapNotNull { p -> runCatching { lm.getLastKnownLocation(p) }.getOrNull() }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 6 * 3600_000L) return last
        if (Build.VERSION.SDK_INT >= 30) {
            val provider = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
            else LocationManager.GPS_PROVIDER
            val fresh = withTimeoutOrNull(15_000) {
                suspendCancellableCoroutine<Location?> { cont ->
                    runCatching {
                        lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(context)) { loc -> if (cont.isActive) cont.resume(loc) }
                    }.onFailure { if (cont.isActive) cont.resume(null) }
                }
            }
            if (fresh != null) return fresh
        }
        return last
    }

    /** "Phoenix, AZ" for a point, using the phone's built-in geocoder, falling back to the nearest pro sports city. */
    @Suppress("DEPRECATION")
    suspend fun label(context: Context, lat: Double, lon: Double): String = withContext(Dispatchers.IO) {
        val viaGeocoder = if (Geocoder.isPresent()) runCatching {
            Geocoder(context, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()?.let { a ->
                listOfNotNull(a.locality ?: a.subAdminArea, stateShort(a.adminArea) ?: a.countryName).joinToString(", ")
            }
        }.getOrNull() else null
        viaGeocoder?.takeIf { it.isNotBlank() } ?: (Places.nearestMetro(lat, lon)?.let { "Near ${it.name}" } ?: "Your area")
    }

    /** A typed city or ZIP code to a place. */
    @Suppress("DEPRECATION")
    suspend fun search(context: Context, query: String): UserPlace? = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext null
        if (Geocoder.isPresent()) {
            runCatching { Geocoder(context, Locale.getDefault()).getFromLocationName(q, 1)?.firstOrNull() }.getOrNull()?.let { a ->
                val label = listOfNotNull(a.locality ?: a.subAdminArea ?: a.featureName, stateShort(a.adminArea) ?: a.countryName)
                    .distinct().joinToString(", ")
                return@withContext UserPlace(a.latitude, a.longitude, label.ifBlank { q }, false)
            }
        }
        // No geocoder on this phone: match a pro sports city by name.
        Places.metros.firstOrNull { m -> m.name.contains(q, true) || m.keys.any { it.trim().equals(q, true) } }
            ?.let { UserPlace(it.lat, it.lon, it.name, false) }
    }

    private val states = mapOf(
        "Alabama" to "AL", "Alaska" to "AK", "Arizona" to "AZ", "Arkansas" to "AR", "California" to "CA", "Colorado" to "CO",
        "Connecticut" to "CT", "Delaware" to "DE", "District of Columbia" to "DC", "Florida" to "FL", "Georgia" to "GA",
        "Hawaii" to "HI", "Idaho" to "ID", "Illinois" to "IL", "Indiana" to "IN", "Iowa" to "IA", "Kansas" to "KS",
        "Kentucky" to "KY", "Louisiana" to "LA", "Maine" to "ME", "Maryland" to "MD", "Massachusetts" to "MA", "Michigan" to "MI",
        "Minnesota" to "MN", "Mississippi" to "MS", "Missouri" to "MO", "Montana" to "MT", "Nebraska" to "NE", "Nevada" to "NV",
        "New Hampshire" to "NH", "New Jersey" to "NJ", "New Mexico" to "NM", "New York" to "NY", "North Carolina" to "NC",
        "North Dakota" to "ND", "Ohio" to "OH", "Oklahoma" to "OK", "Oregon" to "OR", "Pennsylvania" to "PA", "Rhode Island" to "RI",
        "South Carolina" to "SC", "South Dakota" to "SD", "Tennessee" to "TN", "Texas" to "TX", "Utah" to "UT", "Vermont" to "VT",
        "Virginia" to "VA", "Washington" to "WA", "West Virginia" to "WV", "Wisconsin" to "WI", "Wyoming" to "WY",
    )

    private fun stateShort(admin: String?): String? = admin?.let { states[it] ?: it }

    /** Get the phone's location and save it with a readable label. */
    suspend fun refreshFromPhone(context: Context): UserPlace? {
        val loc = locate(context) ?: return null
        val p = UserPlace(loc.latitude, loc.longitude, label(context, loc.latitude, loc.longitude), true)
        withContext(Dispatchers.Main) { set(context, p) }
        return p
    }
}
