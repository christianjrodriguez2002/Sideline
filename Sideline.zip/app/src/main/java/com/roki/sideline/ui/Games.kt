package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Competitor
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameDetail
import com.roki.sideline.data.GameState
import com.roki.sideline.data.League
import com.roki.sideline.data.Player
import com.roki.sideline.data.Predict
import com.roki.sideline.data.Streaming
import kotlinx.coroutines.delay

fun statusText(g: Game): String = when (g.state) {
    GameState.PRE -> Fmt.whenText(g.start)
    GameState.IN -> g.statusShort.ifBlank { "Live" }
    GameState.POST -> g.statusShort.ifBlank { "Final" }
}

// ---------- game card ----------

@Composable
fun GameCard(g: Game, modifier: Modifier = Modifier, showDate: Boolean = false, showLeague: Boolean = false) {
    val nav = LocalNav.current
    Panel(modifier, onClick = { nav.game(g.league, g.id) }, padding = 14.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showLeague) {
                Text("${g.league.emoji} ${g.league.short}", style = Type.Label, color = Palette.Sub)
                Spacer(Modifier.width(8.dp))
            }
            when (g.state) {
                GameState.IN -> LiveBadge(g.statusShort.ifBlank { "LIVE" }.uppercase())
                GameState.POST -> Text(((if (showDate) Fmt.dayShort(g.start) + " · " else "") + g.statusShort.ifBlank { "Final" }).uppercase(),
                    style = Type.Label, color = Palette.Sub)
                GameState.PRE -> Text(Fmt.whenText(g.start), style = Type.BodyStrong, color = Palette.Text)
            }
            Spacer(Modifier.weight(1f))
            if (g.state != GameState.POST) com.roki.sideline.data.Tv.cardNetworks(g, com.roki.sideline.data.Where.place.value).take(2).forEach { (n, mine) ->
                Spacer(Modifier.width(4.dp))
                if (mine) Tag("📍 $n", Palette.BlueSoft, Color.White) else Tag(n)
            }
        }
        TeamLine(g.league, g.away, g)
        TeamLine(g.league, g.home, g)
        val extra = when (g.state) {
            GameState.IN -> listOf(g.situation, g.lastPlay).filter { it.isNotBlank() }.joinToString(" · ")
            GameState.PRE -> listOfNotNull(
                g.note.ifBlank { null },
                g.odds?.let { o -> listOf(o.details, if (o.overUnder.isNotBlank()) "O/U ${o.overUnder}" else "").filter { it.isNotBlank() }.joinToString(" · ") }
                    ?.ifBlank { null },
                g.venue.ifBlank { null }?.takeIf { g.note.isBlank() && g.odds == null },
            ).joinToString(" · ")
            GameState.POST -> g.note
        }
        if (extra.isNotBlank()) Sub(extra, maxLines = 2)
    }
}

@Composable
private fun TeamLine(league: League, c: Competitor, g: Game) {
    val fav = Favorites.isFavorite(league, c.team.id)
    val lost = g.state == GameState.POST && !c.winner && (g.home.winner || g.away.winner)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Logo(c.team.logo, 30.dp)
        Spacer(Modifier.width(12.dp))
        if (c.rank.isNotBlank()) {
            Text(c.rank, style = Type.Small, color = Palette.Sub, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(4.dp))
        }
        Text(c.team.shortName.ifBlank { c.team.name }, style = Type.Heading,
            color = if (lost) Palette.Sub else if (fav) Palette.Gold else Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.width(8.dp))
        Text(c.record, Modifier.weight(1f), style = Type.Small, color = Palette.Faint, maxLines = 1)
        if (g.state != GameState.PRE) {
            Text(c.score, style = Type.Score, color = if (lost) Palette.Faint else Palette.Text)
            if (g.state == GameState.POST && c.winner) {
                Spacer(Modifier.width(4.dp))
                Text("◀", style = Type.Small, color = Palette.Gold)
            }
        }
    }
}

/** A small tile for horizontal rails on Home. */
@Composable
fun GameTile(g: Game) {
    val nav = LocalNav.current
    Column(
        Modifier.width(230.dp).clip(CardShape).background(Palette.Surface).border(1.dp, Palette.Line, CardShape)
            .clickable { nav.game(g.league, g.id) }.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${g.league.emoji} ${g.league.short}", style = Type.Label, color = Palette.Sub, modifier = Modifier.weight(1f))
            if (g.state == GameState.IN) LiveBadge(g.clock.ifBlank { "LIVE" })
        }
        listOf(g.away, g.home).forEach { c ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(c.team.logo, 22.dp)
                Spacer(Modifier.width(8.dp))
                Text(c.team.abbr, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text)
                if (g.state != GameState.PRE) Text(c.score, style = Type.Score, color = Palette.Text)
            }
        }
        Sub(if (g.state == GameState.PRE) Fmt.whenText(g.start) else g.statusShort, maxLines = 1)
    }
}


// ---------- game page ----------

@Composable
fun GameScreen(league: League, id: String) {
    Loaded(key = "game:${league.key}:$id", load = { force -> Espn.game(league, id, force) ?: throw IllegalStateException("No details for this game yet.") },
        skeletonRows = 4) { d, refresh ->
        LaunchedEffect(d) {
            if (d.game.state == GameState.IN) {
                delay(30_000)
                refresh()
            }
        }
        GameBody(d)
    }
}

@Composable
private fun GameBody(d: GameDetail) {
    val g = d.game
    val nav = LocalNav.current
    val context = LocalContext.current
    val awayC = teamColor(g.away.team.color, Palette.BlueSoft)
    val homeC = teamColor(g.home.team.color, Palette.Raised2)
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ScoreHero(g, awayC, homeC) }

        if (g.home.linescores.isNotEmpty() || g.away.linescores.isNotEmpty()) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Scoring by ${if (g.league.sport == "baseball") "inning" else "period"}")
                LineScore(g)
            }
        }

        // prediction
        if (g.state != GameState.POST) item {
            val espnHome = d.homeWinPct
            val estHome = Predict.homeWinProb(g.league, g.home.record, g.away.record)?.times(100)
            val home = espnHome ?: estHome
            if (home != null) Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader(if (g.state == GameState.IN) "Win probability" else "Prediction")
                val draw = d.drawPct ?: 0.0
                val away = d.awayWinPct ?: (100 - home - draw)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(Predict.pctText(away), style = Type.Title, color = Palette.Text)
                        Sub(g.away.team.shortName)
                    }
                    if (draw > 0) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(Predict.pctText(draw), style = Type.Heading, color = Palette.Sub)
                        Sub("Draw")
                    }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text(Predict.pctText(home), style = Type.Title, color = Palette.Text)
                        Sub(g.home.team.shortName)
                    }
                }
                SplitBar(away, awayC, homeC, draw)
                Sub(if (espnHome != null) d.predictorName else "Simple estimate from both records plus home edge (ESPN hasn't posted its model yet).")
            }
        }

        // where to watch, from where you are
        val bcs = d.broadcasts.ifEmpty { g.broadcasts }
        if (bcs.isNotEmpty() && g.state != GameState.POST) item {
            val place = com.roki.sideline.data.Where.place.value
            val plan = com.roki.sideline.data.Tv.plan(g, place, bcs)
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Where to watch" + (place?.let { " · ${it.label}" } ?: ""))
                plan.forEach { w ->
                    Row(verticalAlignment = Alignment.Top) {
                        Text(when (w.reach) {
                            com.roki.sideline.data.Reach.NATIONAL -> "📺"
                            com.roki.sideline.data.Reach.LOCAL_YOURS -> "📍"
                            com.roki.sideline.data.Reach.LOCAL_UNKNOWN -> "📡"
                            com.roki.sideline.data.Reach.LOCAL_ELSEWHERE -> "🚫"
                        }, style = Type.Body)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(w.text, style = Type.Body, color = if (w.reach == com.roki.sideline.data.Reach.LOCAL_ELSEWHERE) Palette.Sub else Palette.Text)
                            w.findUrl?.let { u ->
                                Text("Find it on your TV ›", Modifier.clickable { openUrl(context, u) }.padding(top = 2.dp),
                                    style = Type.Small, color = Palette.Blue, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                com.roki.sideline.data.Tv.regionalNote(g)?.let { Sub(it) }
                Sub(if (place == null) "Set your location in Settings to see which local channels reach you."
                    else "TV areas are approximate; blackouts and your provider can change what you get.")
            }
        }

        // odds
        val odds = d.odds ?: g.odds
        if (odds != null && g.state != GameState.POST) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Betting line" + if (odds.provider.isNotBlank()) " · ${odds.provider}" else "")
                Row {
                    OddsCell("Spread", odds.details, Modifier.weight(1f))
                    OddsCell("Total", odds.overUnder.let { if (it.isBlank()) "—" else "O/U $it" }, Modifier.weight(1f))
                }
                if (odds.awayMoneyline.isNotBlank() || odds.homeMoneyline.isNotBlank()) Row {
                    OddsCell("${g.away.team.abbr} ML", odds.awayMoneyline, Modifier.weight(1f))
                    if (odds.drawMoneyline.isNotBlank()) OddsCell("Draw", odds.drawMoneyline, Modifier.weight(1f))
                    OddsCell("${g.home.team.abbr} ML", odds.homeMoneyline, Modifier.weight(1f))
                }
            }
        }

        // live situation
        if (g.state == GameState.IN && (g.situation.isNotBlank() || g.lastPlay.isNotBlank())) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Right now")
                if (g.situation.isNotBlank()) Text(g.situation, style = Type.Heading, color = Palette.Text)
                if (g.lastPlay.isNotBlank()) Text(g.lastPlay, style = Type.Body, color = Palette.Sub)
            }
        }

        // scoring / key events
        if (d.scoringPlays.isNotEmpty()) item {
            var all by remember { mutableStateOf(false) }
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader(if (g.league.draws) "Key events" else "Scoring", action = if (d.scoringPlays.size > 8) (if (all) "Less" else "All ${d.scoringPlays.size}") else null,
                    onAction = { all = !all })
                (if (all) d.scoringPlays else d.scoringPlays.takeLast(8)).forEach { line ->
                    Row {
                        Box(Modifier.padding(top = 7.dp).width(6.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Palette.Blue))
                        Spacer(Modifier.width(10.dp))
                        Text(line, style = Type.Body, color = Palette.Text)
                    }
                }
            }
        }

        // leaders
        if (d.leaders.isNotEmpty()) {
            item { SectionHeader("Leaders", Modifier.padding(horizontal = 20.dp)) }
            items(d.leaders) { (group, list) ->
                Panel(Modifier.padding(horizontal = 16.dp)) {
                    Text(group, style = Type.Label, color = Palette.Sub)
                    list.forEach { l ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if (l.athleteId.isNotBlank() && g.league.playerStats) nav.player(g.league, Player(l.athleteId, l.athleteName, headshot = l.headshot))
                        }, verticalAlignment = Alignment.CenterVertically) {
                            Headshot(l.headshot, 38.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(l.athleteName, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Sub(l.category)
                            }
                            Text(l.value, style = Type.Heading, color = Palette.Text)
                        }
                    }
                }
            }
        }

        // team stats
        if (d.teamStats.isNotEmpty()) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Logo(g.away.team.logo, 22.dp)
                    Text("Team stats", Modifier.weight(1f), style = Type.Label, color = Palette.Sub, textAlign = TextAlign.Center)
                    Logo(g.home.team.logo, 22.dp)
                }
                d.teamStats.forEach { s -> StatCompare(s.label, s.away, s.home, awayC, homeC) }
            }
        }

        // lineups (soccer)
        if (d.lineups.isNotEmpty()) item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Lineups")
                d.lineups.forEach { (team, players) ->
                    Text(team, style = Type.BodyStrong, color = Palette.Text)
                    Sub(players.filter { it.starter }.joinToString(" · ") { p ->
                        listOf(p.jersey, p.name, p.position.let { if (it.isBlank()) "" else "($it)" }).filter { it.isNotBlank() }.joinToString(" ")
                    }.ifBlank { players.take(11).joinToString(" · ") { it.name } })
                }
            }
        }

        // box score
        if (d.box.isNotEmpty()) {
            item { SectionHeader("Box score", Modifier.padding(horizontal = 20.dp)) }
            items(d.box) { t ->
                Panel(Modifier.padding(horizontal = 16.dp)) {
                    Text("${t.teamName} · ${t.title}", style = Type.BodyStrong, color = Palette.Text)
                    DataTable(t.labels, t.rows)
                }
            }
        }

        // injuries
        if (d.injuries.isNotEmpty()) {
            item { SectionHeader("Injuries", Modifier.padding(horizontal = 20.dp)) }
            items(d.injuries) { inj -> Box(Modifier.padding(horizontal = 16.dp)) { InjuryRow(g.league, inj, showTeam = true) } }
        }

        // info
        item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                SectionHeader("Game info")
                InfoRow("When", Fmt.dayTime(g.start) + " ${Fmt.zoneShort()} (your time)")
                val vz = com.roki.sideline.data.Places.venueZone(g)
                if (com.roki.sideline.data.Places.differs(vz, g.start)) InfoRow("Local", Fmt.timeIn(g.start, vz!!) + " at the venue")
                if (g.venue.isNotBlank()) InfoRow("Where", g.venue)
                if (d.attendance.isNotBlank()) InfoRow("Crowd", d.attendance)
                if (d.seasonSeries.isNotBlank()) InfoRow("Series", d.seasonSeries)
                if (d.articleHeadline.isNotBlank()) InfoRow("Story", d.articleHeadline)
                Text("Open on ESPN.com ›", Modifier.clickable {
                    openUrl(context, "https://www.espn.com/${espnPath(g.league)}/game/_/gameId/${g.id}")
                }.padding(top = 4.dp), style = Type.BodyStrong, color = Palette.Blue)
            }
        }
    }
}

fun espnPath(league: League): String = when (league.slug) {
    "college-football" -> "college-football"
    "mens-college-basketball" -> "mens-college-basketball"
    "womens-college-basketball" -> "womens-college-basketball"
    else -> if (league.sport == "soccer") "soccer" else league.slug
}

@Composable
private fun OddsCell(label: String, value: String, modifier: Modifier) {
    Column(modifier) {
        Text(label.uppercase(), style = Type.Label, color = Palette.Faint)
        Text(value.ifBlank { "—" }, style = Type.Heading, color = Palette.Text)
    }
}

@Composable
fun InfoRow(k: String, v: String) {
    Row {
        Text(k, Modifier.width(72.dp), style = Type.Small, color = Palette.Faint)
        Text(v, style = Type.Body, color = Palette.Text)
    }
}

private fun leadNumber(s: String): Double? = Regex("""-?\d+(\.\d+)?""").find(s)?.value?.toDoubleOrNull()

@Composable
private fun StatCompare(label: String, away: String, home: String, awayC: Color, homeC: Color) {
    val a = leadNumber(away)
    val h = leadNumber(home)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row {
            Text(away, Modifier.weight(1f), style = Type.Num, color = Palette.Text)
            Text(label, Modifier.weight(2f), style = Type.Small, color = Palette.Sub, textAlign = TextAlign.Center)
            Text(home, Modifier.weight(1f), style = Type.Num, color = Palette.Text, textAlign = TextAlign.End)
        }
        if (a != null && h != null && a >= 0 && h >= 0 && a + h > 0) SplitBar(100 * a / (a + h), awayC, homeC)
    }
}

@Composable
private fun ScoreHero(g: Game, awayC: Color, homeC: Color) {
    val nav = LocalNav.current
    Box(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Brush.horizontalGradient(
        listOf(awayC.copy(alpha = 0.85f), Palette.Bg, homeC.copy(alpha = 0.85f))))) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (g.note.isNotBlank()) Text(g.note.uppercase(), style = Type.Label, color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center)
            Row(verticalAlignment = Alignment.CenterVertically) {
                HeroTeam(g.away, Modifier.weight(1f)) { nav.team(g.league, g.away.team) }
                Column(Modifier.weight(1.3f), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (g.state != GameState.PRE) {
                        Text("${g.away.score}  ${g.home.score}", style = Type.ScoreBig, color = Color.White, maxLines = 1)
                    } else {
                        Text(Fmt.time(g.start), style = Type.Title, color = Color.White)
                        Text(Fmt.day(g.start), style = Type.Small, color = Color.White.copy(alpha = 0.8f))
                        val vz = com.roki.sideline.data.Places.venueZone(g)
                        if (com.roki.sideline.data.Places.differs(vz, g.start))
                            Text(Fmt.timeIn(g.start, vz!!) + " local", style = Type.Small, color = Color.White.copy(alpha = 0.65f))
                    }
                    Spacer(Modifier.height(4.dp))
                    when (g.state) {
                        GameState.IN -> LiveBadge(g.statusShort.ifBlank { "LIVE" }.uppercase())
                        GameState.POST -> Text(g.statusDetail.uppercase(), style = Type.Label, color = Color.White.copy(alpha = 0.8f), textAlign = TextAlign.Center)
                        GameState.PRE -> Text(Fmt.zoneShort(), style = Type.Label, color = Color.White.copy(alpha = 0.7f))
                    }
                }
                HeroTeam(g.home, Modifier.weight(1f)) { nav.team(g.league, g.home.team) }
            }
            if (g.venue.isNotBlank()) Text(g.venue, style = Type.Small, color = Color.White.copy(alpha = 0.75f), textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun HeroTeam(c: Competitor, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Logo(c.team.logo, 64.dp)
        Text((if (c.rank.isNotBlank()) "${c.rank} " else "") + c.team.abbr, style = Type.Heading, color = Color.White)
        if (c.record.isNotBlank()) Text(c.record, style = Type.Small, color = Color.White.copy(alpha = 0.75f))
    }
}

@Composable
private fun LineScore(g: Game) {
    val n = maxOf(g.home.linescores.size, g.away.linescores.size)
    val reg = g.league.regularPeriods
    val labels = (1..n).map { i ->
        when {
            i <= reg || g.league.sport == "baseball" -> "$i"
            g.league.sport == "hockey" && i == reg + 1 -> "OT"
            g.league.sport == "hockey" -> "SO"
            else -> "OT" + if (i - reg > 1) "${i - reg}" else ""
        }
    } + listOf("T")
    val rows = listOf(g.away, g.home).map { c -> c.team.abbr to ((0 until n).map { c.linescores.getOrNull(it) ?: "" } + c.score) }
    DataTable(labels, rows, firstWidth = 70.dp)
}
