package com.roki.sideline.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.League
import com.roki.sideline.data.Play
import com.roki.sideline.data.Player
import com.roki.sideline.data.Settings
import com.roki.sideline.data.StandingTable
import com.roki.sideline.data.TeamRef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate

// ---------- play-by-play ----------

/** Every play, newest first, filterable by period, with scoring plays highlighted. */
@Composable
fun PlayByPlay(plays: List<Play>, live: Boolean) {
    if (plays.isEmpty()) return
    val periods = plays.map { it.period }.filter { it.isNotBlank() }.distinct()
    var pick by remember(periods.size) { mutableIntStateOf(0) }
    var all by remember { mutableStateOf(false) }
    val tabs = listOf("All") + periods
    val shown = plays.reversed().filter { pick == 0 || it.period == tabs[pick] }
    Panel(Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(if (live) "Play by play · live" else "Play by play")
        if (periods.size > 1) PillTabs(tabs, pick, Modifier.padding(0.dp)) { pick = it }
        (if (all) shown else shown.take(15)).forEach { p ->
            Row(verticalAlignment = Alignment.Top) {
                Text(
                    listOf(p.period, p.clock).filter { it.isNotBlank() }.joinToString(" "),
                    Modifier.width(64.dp),
                    style = Type.Small,
                    color = Palette.Faint
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        (if (p.team.isNotBlank()) "${p.team}: " else "") + p.text,
                        style = if (p.scoring) Type.BodyStrong else Type.Body,
                        color = Palette.Text
                    )
                    if (p.scoring && p.away.isNotBlank()) Text("${p.away}-${p.home}", style = Type.Small, color = Palette.Gold)
                }
            }
        }
        if (shown.size > 15) {
            Text(
                if (all) "Show fewer" else "Show all ${shown.size} plays",
                Modifier.clickable { all = !all },
                style = Type.BodyStrong,
                color = Palette.Blue
            )
        }
    }
}

// ---------- Tonight: every game in your leagues ----------

private suspend fun loadTonight(force: Boolean): List<Game> = coroutineScope {
    val leagues = (Settings.pinnedLeagues() + Favorites.list.map { it.league }).filter { it.teamBased }.distinctBy { it.key }
    val today = LocalDate.now(Fmt.zone())
    leagues.map { l ->
        async {
            runCatching {
                if (l.weekly) Espn.week(l, null, force = force).games.filter { it.start?.atZone(Fmt.zone())?.toLocalDate() == today }
                else Espn.day(l, today, force = force)
            }.getOrDefault(emptyList())
        }
    }.awaitAll().flatten().sortedWith(
        compareBy({ when (it.state) { GameState.IN -> 0; GameState.PRE -> 1; GameState.POST -> 2 } }, { it.start ?: Instant.MAX })
    )
}

/** All of today's games across pinned and followed leagues, live first, then by start time, with TV. */
@Composable
fun TonightScores() {
    Loaded(key = "tonight", load = { force -> loadTonight(force) }, pull = true) { games, refresh ->
        LaunchedEffect(games) {
            if (games.any { it.state == GameState.IN }) {
                delay(30_000)
                refresh()
            }
        }
        val cols = columns(420)
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(Space.gap)
        ) {
            item {
                val live = games.count { it.state == GameState.IN }
                Sub(
                    "${games.size} games today across your leagues" + (if (live > 0) " · $live live" else "") + " · times in ${Fmt.zoneShort()}",
                    Modifier.padding(top = 4.dp)
                )
            }
            if (games.isEmpty()) item { EmptyState("📺", "Nothing on today", "Pin more leagues to fill this list.") }
            items(games.chunked(cols)) { group ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    group.forEach { g -> GameCard(g, Modifier.weight(1f), showLeague = true) }
                    repeat(cols - group.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

// ---------- league leaders ----------

@Composable
fun LeadersTab(league: League) {
    val nav = LocalNav.current
    Loaded(key = "leaders:${league.key}", load = { force -> Espn.leaders(league, force) }, pull = true) { boards, _ ->
        var pick by remember(league.key) { mutableIntStateOf(0) }
        Column {
            if (boards.size > 1) PillTabs(boards.map { it.category }, pick.coerceAtMost(boards.lastIndex)) { pick = it }
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (boards.isEmpty()) item { EmptyState("📊", "Leaders aren't posted yet") }
                boards.getOrNull(pick)?.let { b ->
                    items(b.rows) { r ->
                        Panel(padding = 12.dp, onClick = {
                            if (r.athleteId.isNotBlank()) nav.player(league, Player(r.athleteId, r.name, headshot = r.headshot, teamName = r.team))
                        }) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${r.rank}", Modifier.width(28.dp), style = Type.Heading, color = if (r.rank <= 3) Palette.Gold else Palette.Faint)
                                Headshot(r.headshot, 42.dp, name = r.name)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(r.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    if (r.team.isNotBlank()) Sub(r.team)
                                }
                                Text(r.value, style = Type.Title, color = Palette.Text)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- playoffs ----------

/** Playoff picture from the standings (seeds and clinches), then the bracket once the postseason starts. */
@Composable
fun PlayoffsTab(league: League) {
    val nav = LocalNav.current
    Loaded(
        key = "po:${league.key}",
        load = { force -> Espn.playoffs(league, force) to runCatching { Espn.standings(league, force) }.getOrDefault(emptyList()) },
        pull = true
    ) { (rounds, tables), _ ->
        val seeded = tables.filter { t -> t.rows.count { it.stats["_seed"]?.toIntOrNull() != null } >= 2 }
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(Space.list)
        ) {
            if (rounds.isEmpty() && seeded.isEmpty()) item { EmptyState("🏆", "No playoff picture yet", "Seeds show up here as the season goes on.") }
            if (rounds.isNotEmpty()) {
                item { SectionHeader("Bracket") }
                rounds.reversed().forEach { r ->
                    item {
                        Panel {
                            Text(r.name, style = Type.Heading, color = Palette.Text)
                            r.series.forEach { s ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { s.games.lastOrNull()?.let { nav.game(league, it.id) } }.padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Logo(s.a.logo, 24.dp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(s.a.abbr, style = Type.BodyStrong, color = Palette.Text)
                                    Text(" vs ", style = Type.Small, color = Palette.Faint)
                                    Text(s.b.abbr, style = Type.BodyStrong, color = Palette.Text)
                                    Spacer(Modifier.width(6.dp))
                                    Logo(s.b.logo, 24.dp)
                                    Spacer(Modifier.weight(1f))
                                    Text(s.summary, style = Type.Small, color = Palette.Sub, textAlign = TextAlign.End)
                                }
                            }
                        }
                    }
                }
            }
            if (seeded.isNotEmpty()) {
                item { SectionHeader("Playoff picture") }
                items(seeded) { t -> SeedCard(league, t) }
            }
        }
    }
}

@Composable
private fun SeedCard(league: League, t: StandingTable) {
    val nav = LocalNav.current
    val rows = t.rows.filter { it.stats["_seed"]?.toIntOrNull() != null }.sortedBy { it.stats["_seed"]!!.toInt() }
    Panel {
        Text(t.title, style = Type.Heading, color = Palette.Text)
        rows.forEach { r ->
            val seed = r.stats["_seed"].orEmpty()
            val clinch = r.stats["_clinch"].orEmpty().trim()
            Row(
                Modifier.fillMaxWidth().clickable { nav.team(league, r.team) }.padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(seed, Modifier.width(26.dp), style = Type.Heading, color = Palette.Faint)
                Logo(r.team.logo, 22.dp)
                Spacer(Modifier.width(8.dp))
                Text(r.team.shortName.ifBlank { r.team.name }, Modifier.weight(1f), style = Type.BodyStrong,
                    color = if (Favorites.isFavorite(league, r.team.id)) Palette.Gold else Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (clinch.isNotBlank() && clinch != "-") Tag(clinchLabel(clinch), Palette.Win.copy(alpha = 0.2f), Palette.Win)
            }
        }
        Sub("Seeds update with every result. Tags mark teams that have clinched.")
    }
}

private fun clinchLabel(c: String): String = when (c.lowercase()) {
    "z", "*" -> "TOP SEED"
    "y" -> "DIVISION"
    "x" -> "CLINCHED"
    "w", "pi" -> "PLAY-IN"
    "e" -> "OUT"
    else -> c.uppercase()
}

// ---------- team season stats ----------

@Composable
fun TeamStatsTab(league: League, team: TeamRef) {
    Loaded(key = "tstats:${league.key}:${team.id}", load = { force -> Espn.teamStats(league, team.id, force) }, pull = true) { cats, _ ->
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(Space.list)
        ) {
            if (cats.isEmpty()) item { EmptyState("📊", "Season stats aren't posted yet") }
            items(cats) { (title, stats) ->
                Panel {
                    SectionHeader(title)
                    stats.forEach { s ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(s.label, Modifier.weight(1f), style = Type.Body, color = Palette.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.value, style = Type.BodyStrong, color = Palette.Text)
                            if (s.rank.isNotBlank()) {
                                Spacer(Modifier.width(8.dp))
                                Text(s.rank, Modifier.width(44.dp), style = Type.Small, color = Palette.Faint, textAlign = TextAlign.End)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- share a score as an image ----------

private suspend fun bitmapFrom(url: String): Bitmap? = withContext(Dispatchers.IO) {
    if (url.isBlank()) return@withContext null
    runCatching {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        try { conn.inputStream.use { BitmapFactory.decodeStream(it) } } finally { conn.disconnect() }
    }.getOrNull()
}

/** Draws a 1080x600 score card (team colors, logos, score, status) and opens the share sheet with it. */
suspend fun shareGame(context: Context, g: Game) {
    val w = 1080
    val h = 600
    val awayLogo = bitmapFrom(g.away.team.logo)
    val homeLogo = bitmapFrom(g.home.team.logo)
    val file = withContext(Dispatchers.Default) {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun hex(s: String, fallback: Int) = runCatching { android.graphics.Color.parseColor("#" + s.removePrefix("#")) }.getOrDefault(fallback)
        p.color = 0xFF06090F.toInt(); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.color = hex(g.away.team.color, 0xFF1D3561.toInt()); p.alpha = 150; c.drawRect(0f, 0f, w / 2f, h.toFloat(), p)
        p.color = hex(g.home.team.color, 0xFF1D2635.toInt()); p.alpha = 150; c.drawRect(w / 2f, 0f, w.toFloat(), h.toFloat(), p)
        p.alpha = 255
        p.color = 0xCC06090F.toInt(); c.drawRoundRect(RectF(40f, 40f, w - 40f, h - 40f), 48f, 48f, p)
        p.color = android.graphics.Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = 34f; p.alpha = 200
        c.drawText("${g.league.short.uppercase()}  ·  ${statusText(g).uppercase()}", w / 2f, 110f, p)
        p.alpha = 255
        awayLogo?.let { c.drawBitmap(Bitmap.createScaledBitmap(it, 170, 170, true), 140f, 170f, null) }
        homeLogo?.let { c.drawBitmap(Bitmap.createScaledBitmap(it, 170, 170, true), w - 310f, 170f, null) }
        p.textSize = 52f
        c.drawText(g.away.team.abbr, 225f, 410f, p)
        c.drawText(g.home.team.abbr, w - 225f, 410f, p)
        p.textSize = 150f
        val score = if (g.state == GameState.PRE) "vs" else "${g.away.score}  ${g.home.score}"
        c.drawText(score, w / 2f, 330f, p)
        p.textSize = 30f; p.alpha = 170
        c.drawText(listOf(Fmt.day(g.start), g.venue).filter { it.isNotBlank() }.joinToString("  ·  "), w / 2f, 500f, p)
        p.textSize = 26f; p.alpha = 130
        c.drawText("Sideline", w / 2f, 545f, p)
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, "sideline-${g.id}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        f
    }
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val send = Intent(Intent.ACTION_SEND)
        .setType("image/png")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .putExtra(Intent.EXTRA_TEXT, "${g.away.team.shortName} ${g.away.score}, ${g.home.team.shortName} ${g.home.score} (${statusText(g)})")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, "Share score").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
