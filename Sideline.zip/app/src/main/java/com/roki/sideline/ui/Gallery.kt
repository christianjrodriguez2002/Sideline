package com.roki.sideline.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Game
import com.roki.sideline.data.GamePhoto
import com.roki.sideline.data.GameState
import com.roki.sideline.data.League
import java.time.Instant

/** A row of photo thumbnails. Tapping one opens the full-screen viewer at that photo. */
@Composable
fun PhotoStrip(photos: List<GamePhoto>) {
    var open by remember { mutableStateOf<Int?>(null) }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(photos.size) { i ->
            AsyncImage(
                model = photos[i].url,
                contentDescription = photos[i].caption,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(width = 150.dp, height = 100.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Palette.Raised2)
                    .clickable { open = i }
            )
        }
    }
    open?.let { start -> PhotoViewer(photos, start) { open = null } }
}

/** Full screen, swipe between photos, caption and credit under each. */
@Composable
private fun PhotoViewer(photos: List<GamePhoto>, start: Int, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        val pager = rememberPagerState(initialPage = start) { photos.size }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                val p = photos[page]
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                    AsyncImage(model = p.url, contentDescription = p.caption, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(420.dp))
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (p.caption.isNotBlank()) Text(p.caption, style = Type.Body, color = Color.White)
                        if (p.credit.isNotBlank()) Text("Photo: ${p.credit}", style = Type.Small, color = Color.White.copy(alpha = 0.6f))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${pager.currentPage + 1} / ${photos.size}", Modifier.weight(1f), style = Type.BodyStrong, color = Color.White)
                Text(
                    "✕",
                    Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.15f)).clickable(onClick = onClose)
                        .spoken("Close photos")
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    style = Type.Heading, color = Color.White
                )
            }
        }
    }
}

@Composable
private fun PhotosHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("PHOTOS", Modifier.weight(1f), style = Type.Label, color = Palette.Sub)
        Tag("EXPERIMENTAL", Palette.Raised2, Palette.Sub)
    }
}

/** Game page photos. Loads on its own so the rest of the page never waits; hidden when there's nothing to show. */
@Composable
fun GamePhotos(g: Game, fromSummary: List<GamePhoto>) {
    Loaded(
        key = "photos:${g.league.key}:${g.id}:${g.state}:${fromSummary.size}",
        load = { force -> Espn.gamePhotos(g.league, g, fromSummary, force) },
        skeletonRows = 0,
    ) { photos, _ ->
        if (photos.isEmpty()) {
            if (g.state != GameState.POST) Sub("Photos usually appear after the game.", Modifier.padding(horizontal = 20.dp))
        } else Panel(Modifier.padding(horizontal = 16.dp)) {
            PhotosHeader()
            PhotoStrip(photos)
        }
    }
}

/** A "Photos" link on an event card (fight card, race weekend, tournament) that loads the gallery when tapped. */
@Composable
fun EventPhotos(league: League, start: Instant?, end: Instant?) {
    if (start == null) return
    var open by remember(league.key, start) { mutableStateOf(false) }
    Text(
        if (open) "Hide photos" else "Photos ›",
        Modifier.clickable { open = !open }.padding(vertical = 2.dp),
        style = Type.BodyStrong,
        color = Palette.Blue
    )
    if (open) Loaded(key = "evphotos:${league.key}:$start", load = { force -> Espn.eventPhotos(league, start, end, force) }, skeletonRows = 1) { photos, _ ->
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            PhotosHeader()
            if (photos.isEmpty()) Sub("No photos yet. They're mostly posted after the event.")
            else PhotoStrip(photos)
        }
    }
}
