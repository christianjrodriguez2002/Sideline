package com.roki.sideline.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.roki.sideline.data.Category
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.League
import com.roki.sideline.data.Leagues
import com.roki.sideline.data.Settings
import com.roki.sideline.work.Alerts
import kotlinx.coroutines.launch

@Composable
fun ScoresScreen(onEditPins: () -> Unit) {
    val pinned = Settings.pinnedLeagues()
    var selectedKey by rememberSaveable { mutableStateOf(pinned.firstOrNull()?.key ?: "NFL") }
    val selected = Leagues.of(selectedKey) ?: pinned.firstOrNull() ?: Leagues.all.first()
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val shown = if (pinned.any { it.key == selected.key }) pinned else listOf(selected) + pinned
            items(shown) { l ->
                val on = l.key == selected.key
                Row(
                    Modifier
                        .clip(ChipShape)
                        .background(if (on) Color(l.accent) else Palette.Raised)
                        .border(1.dp, if (on) Color.White.copy(alpha = 0.22f) else Palette.Line, ChipShape)
                        .clickable { selectedKey = l.key }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    LeagueMark(l, 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(l.short, style = Type.BodyStrong, color = Color.White)
                }
            }
            item {
                Box(
                    Modifier
                        .clip(ChipShape)
                        .border(1.dp, Palette.Line, ChipShape)
                        .clickable(onClick = onEditPins)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("+ Leagues", style = Type.BodyStrong, color = Palette.Sub)
                }
            }
        }
        androidx.compose.runtime.key(selected.key) { LeagueScores(selected) }
    }
}

@Composable
fun LeaguesScreen() {
    val nav = LocalNav.current
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("All sports", style = Type.Display, color = Palette.Text)
            Sub("Tap a league to open it. Star it to pin it.")
        }
        Category.entries.forEach { cat ->
            val list = Leagues.all.filter { it.category == cat }
            if (list.isNotEmpty()) {
                item {
                    PhotoHero(
                        photo = com.roki.sideline.data.Art.photoFor(cat),
                        tint = Color(list.first().accent),
                        height = 104.dp,
                        modifier = Modifier
                            .padding(top = 12.dp)
                            .clip(CardShape)
                            .border(1.dp, Color.White.copy(alpha = 0.12f), CardShape)
                    ) {
                        Column(
                            Modifier
                                .align(Alignment.BottomStart)
                                .padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Text(
                                "${list.size} LEAGUES",
                                style = Type.Label,
                                color = Color.White.copy(alpha = 0.78f)
                            )
                            Text(cat.title, style = Type.Title, color = Color.White)
                        }
                    }
                }
                list.chunked(2).forEach { pair ->
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { l -> LeagueTile(l, Modifier.weight(1f)) { nav.league(l) } }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LeagueTile(l: League, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val pinned = l.key in Settings.pins
    val accent = Color(l.accent)
    Column(
        modifier
            .clip(CardShape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        if (pinned) accent.copy(alpha = 0.22f) else Palette.Raised.copy(alpha = 0.5f),
                        Palette.Surface
                    )
                )
            )
            .border(1.dp, if (pinned) accent else Palette.Line, CardShape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LeagueMark(l, 44.dp)
            Spacer(Modifier.weight(1f))
            Text(
                if (pinned) "★" else "☆",
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { Settings.togglePin(context, l.key) }
                    .padding(6.dp),
                style = Type.Title,
                color = if (pinned) Palette.Gold else Palette.Faint
            )
        }
        Text(
            l.label,
            style = Type.BodyStrong,
            color = Palette.Text,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val nav = LocalNav.current
    var start by remember { mutableStateOf(Alerts.startOn(context)) }
    var final by remember { mutableStateOf(Alerts.finalOn(context)) }
    var pending by remember { mutableStateOf<Pair<Boolean, Boolean>?>(null) }
    var cacheCleared by remember { mutableStateOf(false) }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pending
        if (ok && p != null) {
            start = p.first
            final = p.second
            Alerts.set(context, start, final)
        }
        pending = null
    }
    fun applyAlerts(s: Boolean, f: Boolean) {
        if ((s || f) && Build.VERSION.SDK_INT >= 33 && !Alerts.canNotify(context)) {
            pending = s to f
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            start = s
            final = f
            Alerts.set(context, s, f)
        }
    }

    val clock = Settings.use24h.value
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val place = com.roki.sideline.data.Where.place.value
    var placeQuery by remember { mutableStateOf("") }
    var placeMsg by remember { mutableStateOf<String?>(null) }
    val locPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scope.launch {
            placeMsg = "Finding you…"
            placeMsg = if (com.roki.sideline.data.Where.refreshFromPhone(context) != null) null
            else "Couldn't get a location. Try typing your city or ZIP."
        } else {
            placeMsg = "Type your city or ZIP instead."
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Settings", style = Type.Display, color = Palette.Text)
            Sub("Your teams, location and clock.")
        }

        item {
            Panel {
                SectionHeader("You")
                OutlinedTextField(
                    value = Settings.name.value,
                    onValueChange = { Settings.setName(context, it) },
                    label = { Text("Your first name (for the greeting)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            Panel {
                SectionHeader("Your location")
                Text(place?.label ?: "Not set", style = Type.Heading, color = Palette.Text)
                Sub("Used to show which local channels reach you.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("📍 Use my location", {
                        if (com.roki.sideline.data.Where.hasPermission(context)) scope.launch {
                            placeMsg = "Finding you…"
                            placeMsg = if (com.roki.sideline.data.Where.refreshFromPhone(context) != null) null
                            else "Couldn't get a location. Try typing your city or ZIP."
                        } else locPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                    })
                    if (place != null) {
                        PillButton("Clear", { com.roki.sideline.data.Where.set(context, null) }, primary = false)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = placeQuery,
                        onValueChange = { placeQuery = it },
                        label = { Text("Or type a city or ZIP") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    PillButton("Set", {
                        scope.launch {
                            val found = com.roki.sideline.data.Where.search(context, placeQuery)
                            if (found != null) {
                                com.roki.sideline.data.Where.set(context, found)
                                placeQuery = ""
                                placeMsg = null
                            } else {
                                placeMsg = "Couldn't find \"$placeQuery\"."
                            }
                        }
                    })
                }
                placeMsg?.let { Sub(it) }
            }
        }

        item {
            Panel {
                SectionHeader("Time")
                Text("Times follow your phone automatically", style = Type.BodyStrong, color = Palette.Text)
                Sub(
                    "All times convert to your current local time zone (${Fmt.zoneLong()} · ${Fmt.zoneShort()}) and update automatically as you travel. Game pages also display the venue's local clock."
                )
                Text("Clock", style = Type.Label, color = Palette.Faint)
                PillTabs(
                    listOf("Phone default", "12-hour", "24-hour"),
                    when (clock) {
                        null -> 0
                        false -> 1
                        true -> 2
                    },
                    Modifier.padding(0.dp)
                ) {
                    Settings.setClock(
                        context,
                        when (it) {
                            1 -> false
                            2 -> true
                            else -> null
                        }
                    )
                }
            }
        }

        item {
            Panel {
                SectionHeader("Game alerts")
                ToggleRow(
                    "Starting soon",
                    "An hour before your teams play",
                    start
                ) { applyAlerts(it, final) }
                ToggleRow(
                    "Final scores",
                    "When your teams' games end",
                    final
                ) { applyAlerts(start, it) }
                Sub("Checks every 30 minutes.")
            }
        }

        item { SectionHeader("Pinned leagues") }
        itemsIndexed(Settings.pinnedLeagues()) { i, l ->
            Panel(padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LeagueMark(l, 34.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(l.label, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text)
                    if (i > 0) {
                        Text(
                            "▲",
                            Modifier.clickable { Settings.movePin(context, i, i - 1) }.padding(8.dp),
                            color = Palette.Sub
                        )
                    }
                    if (i < Settings.pins.size - 1) {
                        Text(
                            "▼",
                            Modifier.clickable { Settings.movePin(context, i, i + 1) }.padding(8.dp),
                            color = Palette.Sub
                        )
                    }
                    Text(
                        "✕",
                        Modifier.clickable { Settings.togglePin(context, l.key) }.padding(8.dp),
                        color = Palette.Loss
                    )
                }
            }
        }

        item { SectionHeader("Teams you follow") }
        if (Favorites.list.isEmpty()) {
            item { Sub("None yet. Tap ☆ on any team.") }
        }
        itemsIndexed(Favorites.list.toList()) { i, f ->
            Panel(padding = 12.dp, onClick = { nav.team(f.league, f.team) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Logo(f.team.logo, 32.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            f.team.name,
                            style = Type.BodyStrong,
                            color = Palette.Text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Sub(f.league.label)
                    }
                    if (i > 0) {
                        Text(
                            "▲",
                            Modifier.clickable { Favorites.move(context, i, i - 1) }.padding(8.dp),
                            color = Palette.Sub
                        )
                    }
                    if (i < Favorites.list.size - 1) {
                        Text(
                            "▼",
                            Modifier.clickable { Favorites.move(context, i, i + 1) }.padding(8.dp),
                            color = Palette.Sub
                        )
                    }
                    Text(
                        "✕",
                        Modifier.clickable { Favorites.toggle(context, f.league, f.team) }.padding(8.dp),
                        color = Palette.Loss
                    )
                }
            }
        }

        item {
            Panel {
                SectionHeader("Photo credits")
                Sub("Free-licensed photos from Wikimedia Commons. Tap one for its credit.")
                Spacer(Modifier.height(2.dp))
                com.roki.sideline.data.Art.all.forEachIndexed { idx, ph ->
                    if (idx > 0) HorizontalDivider(color = Palette.Line.copy(alpha = 0.5f), thickness = 0.5.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { openUrl(context, ph.page) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = ph.url,
                            contentDescription = ph.subject,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 56.dp, height = 36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Palette.Raised2)
                                .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            ph.subject,
                            Modifier.weight(1f),
                            style = Type.BodyStrong,
                            color = Palette.Text,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("↗", style = Type.BodyStrong, color = Palette.Blue)
                    }
                }
            }
        }

        item {
            Panel {
                SectionHeader("About")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Sideline", style = Type.Heading, color = Palette.Text, modifier = Modifier.weight(1f))
                    Tag("LOCAL-ONLY · ZERO TRACKING", Palette.Win.copy(alpha = 0.16f), Palette.Win)
                }
                Sub("Data from ESPN's public feeds. Team names and logos belong to their leagues and teams. For personal use.")
                Text(
                    "Sideline collects zero personal data and stores all user preferences locally on this device",
                    style = Type.Small,
                    fontWeight = FontWeight.SemiBold,
                    color = Palette.Text
                )
                Sub("Version 2.3 · Made by Roki Rodriguez")
                HorizontalDivider(color = Palette.Line, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Palette.Raised)
                        .border(1.dp, Palette.Line, RoundedCornerShape(10.dp))
                        .clickable {
                            Espn.clear()
                            cacheCleared = true
                        }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (cacheCleared) "Cached data cleared ✓" else "Clear cached data",
                        Modifier.weight(1f),
                        style = Type.BodyStrong,
                        color = if (cacheCleared) Palette.Win else Palette.Blue
                    )
                    Text("↻", style = Type.BodyStrong, color = if (cacheCleared) Palette.Win else Palette.Blue)
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.BodyStrong, color = Palette.Text)
            Sub(sub)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}
