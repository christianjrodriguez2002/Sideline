package com.roki.sideline.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.roki.sideline.data.Category
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.League
import com.roki.sideline.data.Leagues
import com.roki.sideline.data.Settings
import com.roki.sideline.work.Alerts
import kotlinx.coroutines.launch

// ---------- Scores tab: pinned leagues across the top ----------

@Composable
fun ScoresScreen(onEditPins: () -> Unit) {
    val pinned = Settings.pinnedLeagues()
    var selectedKey by rememberSaveable { mutableStateOf(pinned.firstOrNull()?.key ?: "NFL") }
    val selected = Leagues.of(selectedKey) ?: pinned.firstOrNull() ?: Leagues.all.first()
    Column(Modifier.fillMaxSize()) {
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val shown = if (pinned.any { it.key == selected.key }) pinned else listOf(selected) + pinned
            items(shown) { l ->
                val on = l.key == selected.key
                Row(
                    Modifier.clip(ChipShape).background(if (on) Color(l.accent) else Palette.Raised)
                        .border(1.dp, if (on) Color(l.accent) else Palette.Line, ChipShape)
                        .clickable { selectedKey = l.key }.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    LeagueMark(l, 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(l.short, style = Type.BodyStrong, color = Color.White)
                }
            }
            item {
                Box(Modifier.clip(ChipShape).border(1.dp, Palette.Line, ChipShape).clickable(onClick = onEditPins)
                    .padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("+ Leagues", style = Type.BodyStrong, color = Palette.Sub)
                }
            }
        }
        androidx.compose.runtime.key(selected.key) { LeagueScores(selected) }
    }
}

// ---------- Leagues tab: everything, by category ----------

@Composable
fun LeaguesScreen() {
    val nav = LocalNav.current
    val context = LocalContext.current
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("All sports", style = Type.Display, color = Palette.Text)
            Sub("Tap a league to open it. Pin your favorites to keep them on Home and Scores.")
        }
        Category.entries.forEach { cat ->
            val list = Leagues.all.filter { it.category == cat }
            if (list.isNotEmpty()) {
                item {
                    PhotoHero(com.roki.sideline.data.Art.photoFor(cat), Palette.Raised, height = 92.dp,
                        modifier = Modifier.padding(top = 10.dp).clip(CardShape)) {
                        Text(cat.title, Modifier.align(Alignment.BottomStart).padding(14.dp), style = Type.Title, color = Color.White)
                    }
                }
                list.chunked(2).forEach { pair ->
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { l -> LeagueTile(l, Modifier.weight(1f)) { nav.league(l) } }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        item { SectionHeader("On the web") }
        item { Sub("These don't have a free live-data feed, so they open their official schedules.") }
        Leagues.webOnly.chunked(2).forEach { pair ->
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { (name, emoji, url) ->
                        Row(
                            Modifier.weight(1f).clip(CardShape).background(Palette.Surface).border(1.dp, Palette.Line, CardShape)
                                .clickable { openUrl(context, url) }.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            LeagueBadge(emoji, 0xFF374151, 40.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(name, style = Type.BodyStrong, color = Palette.Text)
                                Sub("Schedule ↗")
                            }
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun LeagueTile(l: League, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val pinned = l.key in Settings.pins
    Column(
        modifier.clip(CardShape).background(Palette.Surface).border(1.dp, if (pinned) Color(l.accent) else Palette.Line, CardShape)
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LeagueMark(l, 44.dp)
            Spacer(Modifier.weight(1f))
            Text(if (pinned) "★" else "☆", Modifier.clickable { Settings.togglePin(context, l.key) }.padding(4.dp),
                style = Type.Title, color = if (pinned) Palette.Gold else Palette.Faint)
        }
        Text(l.label, style = Type.BodyStrong, color = Palette.Text, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val nav = LocalNav.current
    var start by remember { mutableStateOf(Alerts.startOn(context)) }
    var final by remember { mutableStateOf(Alerts.finalOn(context)) }
    var pending by remember { mutableStateOf<Pair<Boolean, Boolean>?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val p = pending
        if (ok && p != null) { start = p.first; final = p.second; Alerts.set(context, start, final) }
        pending = null
    }
    fun applyAlerts(s: Boolean, f: Boolean) {
        if ((s || f) && Build.VERSION.SDK_INT >= 33 && !Alerts.canNotify(context)) {
            pending = s to f
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else { start = s; final = f; Alerts.set(context, s, f) }
    }
    val clock = Settings.use24h.value
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val place = com.roki.sideline.data.Where.place.value
    var placeQuery by remember { mutableStateOf("") }
    var placeMsg by remember { mutableStateOf<String?>(null) }
    val locPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) scope.launch {
            placeMsg = "Finding you…"
            placeMsg = if (com.roki.sideline.data.Where.refreshFromPhone(context) != null) null else "Couldn't get a location. Try typing your city or ZIP."
        } else placeMsg = "No problem — type your city or ZIP instead."
    }

    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Settings", style = Type.Display, color = Palette.Text) }

        item {
            Panel {
                SectionHeader("You")
                OutlinedTextField(value = Settings.name.value, onValueChange = { Settings.setName(context, it) },
                    label = { Text("Your first name (for the greeting)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        }

        item {
            Panel {
                SectionHeader("Your location")
                Text(place?.label ?: "Not set", style = Type.Heading, color = Palette.Text)
                Sub("Used only on this phone to work out which local channels (team TV areas) reach you. City-level, never shared.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("📍 Use my location", {
                        if (com.roki.sideline.data.Where.hasPermission(context)) scope.launch {
                            placeMsg = "Finding you…"
                            placeMsg = if (com.roki.sideline.data.Where.refreshFromPhone(context) != null) null else "Couldn't get a location. Try typing your city or ZIP."
                        } else locPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                    })
                    if (place != null) PillButton("Clear", { com.roki.sideline.data.Where.set(context, null) }, primary = false)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = placeQuery, onValueChange = { placeQuery = it }, label = { Text("Or type a city or ZIP") },
                        singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    PillButton("Set", {
                        scope.launch {
                            val found = com.roki.sideline.data.Where.search(context, placeQuery)
                            if (found != null) { com.roki.sideline.data.Where.set(context, found); placeQuery = ""; placeMsg = null }
                            else placeMsg = "Couldn't find \"$placeQuery\"."
                        }
                    })
                }
                placeMsg?.let { Sub(it) }
            }
        }

        item {
            Panel {
                SectionHeader("Time")
                Text("Times follow your phone automatically", style = Type.BodyStrong, color = Palette.Text)
                Sub("Right now that's ${Fmt.zoneLong()} (${Fmt.zoneShort()}). Every start time, date and \"today\" in the app — " +
                    "including games played overseas — is converted to it, and game pages also show the clock at the venue " +
                    "when it's different. Travel, and the app travels with you.")
                Text("Clock", style = Type.Label, color = Palette.Faint)
                PillTabs(listOf("Phone default", "12-hour", "24-hour"), when (clock) { null -> 0; false -> 1; true -> 2 }, Modifier.padding(0.dp)) {
                    Settings.setClock(context, when (it) { 1 -> false; 2 -> true; else -> null })
                }
            }
        }

        item {
            Panel {
                SectionHeader("Game alerts")
                ToggleRow("Starting soon", "About an hour before your teams play, with the channel and stream", start) { applyAlerts(it, final) }
                ToggleRow("Final scores", "When your teams' games end", final) { applyAlerts(start, it) }
                Sub("Checks about every 30 minutes, so alerts can be a little late.")
            }
        }

        item { SectionHeader("Pinned leagues") }
        itemsIndexed(Settings.pinnedLeagues()) { i, l ->
            Panel(padding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LeagueMark(l, 34.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(l.label, Modifier.weight(1f), style = Type.BodyStrong, color = Palette.Text)
                    if (i > 0) Text("▲", Modifier.clickable { Settings.movePin(context, i, i - 1) }.padding(8.dp), color = Palette.Sub)
                    if (i < Settings.pins.size - 1) Text("▼", Modifier.clickable { Settings.movePin(context, i, i + 1) }.padding(8.dp), color = Palette.Sub)
                    Text("✕", Modifier.clickable { Settings.togglePin(context, l.key) }.padding(8.dp), color = Palette.Loss)
                }
            }
        }

        item { SectionHeader("Teams you follow") }
        if (Favorites.list.isEmpty()) item { Sub("None yet — open any league's Teams tab and tap ☆.") }
        itemsIndexed(Favorites.list.toList()) { i, f ->
            Panel(padding = 12.dp, onClick = { nav.team(f.league, f.team) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Logo(f.team.logo, 32.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.team.name, style = Type.BodyStrong, color = Palette.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Sub(f.league.label)
                    }
                    if (i > 0) Text("▲", Modifier.clickable { Favorites.move(context, i, i - 1) }.padding(8.dp), color = Palette.Sub)
                    if (i < Favorites.list.size - 1) Text("▼", Modifier.clickable { Favorites.move(context, i, i + 1) }.padding(8.dp), color = Palette.Sub)
                    Text("✕", Modifier.clickable { Favorites.toggle(context, f.league, f.team) }.padding(8.dp), color = Palette.Loss)
                }
            }
        }

        item {
            Panel {
                SectionHeader("Photo credits")
                Sub("Real photographs from Wikimedia Commons, all under free licenses (Creative Commons or public domain). " +
                    "Tap one for its photographer and license.")
                com.roki.sideline.data.Art.all.forEach { ph ->
                    Text("• " + ph.subject, Modifier.clickable { openUrl(context, ph.page) }.padding(vertical = 2.dp),
                        style = Type.Small, color = Palette.Blue)
                }
            }
        }

        item {
            Panel {
                SectionHeader("About")
                Text("Sideline", style = Type.Heading, color = Palette.Text)
                Sub("Scores, schedules, standings, rosters, injuries, odds and news from ESPN's public data feeds. " +
                    "Predictions come from ESPN's models when posted. Team names and logos belong to their leagues and teams. " +
                    "For personal use.")
                Text("Clear cached data", Modifier.clickable { Espn.clear() }.padding(top = 4.dp), style = Type.BodyStrong, color = Palette.Blue)
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = Type.BodyStrong, color = Palette.Text)
            Sub(sub)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}
