package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject

// ---------- live game graphics: models ----------

/** A player shown in a live graphic: the pitcher, the batter, a lineup spot. */
data class LivePlayer(val id: String, val name: String, val headshot: String, val line: String = "", val pos: String = "", val jersey: String = "")

/** One pitch: where it crossed the plate in ESPN's coordinates, and what happened. */
data class Pitch(val n: Int, val x: Double, val y: Double, val type: String, val mph: String, val result: String, val kind: PitchKind)
enum class PitchKind { BALL, STRIKE, IN_PLAY }

data class BaseballLive(
    val balls: Int, val strikes: Int, val outs: Int,
    val first: Boolean, val second: Boolean, val third: Boolean,
    val pitcher: LivePlayer?, val batter: LivePlayer?, val onDeck: String,
    /** The current at-bat's pitches, oldest first. */
    val pitches: List<Pitch>,
    /** Called strikes from the whole game, used to place the strike zone. */
    val calledStrikes: List<Pair<Double, Double>>,
    /** The team in the field and who's at each position (P, C, 1B, 2B, 3B, SS, LF, CF, RF). Empty when unknown. */
    val fieldingTeamId: String = "",
    val fielders: Map<String, LivePlayer> = emptyMap(),
)

/** A highlight clip from ESPN. [url] is a playable video (MP4 or HLS). */
data class Clip(val title: String, val thumb: String, val url: String, val seconds: Int)

/**
 * Field position on a 0-100 line: 0 is the away team's goal line, 100 the home team's. Null when ESPN didn't say
 * where the ball is, so the graphic draws no marker rather than a wrong one.
 */
data class FootballLive(
    val downText: String, val possessionId: String, val ballX: Double?, val toGainX: Double?,
    val redZone: Boolean, val awayTimeouts: Int?, val homeTimeouts: Int?, val lastPlay: String, val drive: String,
)

/** A shot on a shot chart. Basketball uses feet on a half court; hockey uses ESPN's rink grid (-100..100, -42.5..42.5). */
data class Shot(val x: Double, val y: Double, val made: Boolean, val teamId: String, val text: String, val period: String, val value: Int)

/** One team's starting eleven laid out in rows, back to front, each row left to right. */
data class Formation(val teamId: String, val teamName: String, val shape: String, val rows: List<List<LivePlayer>>)

data class Live(
    val baseball: BaseballLive? = null,
    val football: FootballLive? = null,
    val shots: List<Shot> = emptyList(),
    val formations: List<Formation> = emptyList(),
    val clips: List<Clip> = emptyList(),
    /** Photos from the recap and related stories inside the summary. Team news adds more when the page loads them. */
    val photos: List<GamePhoto> = emptyList(),
)

// ---------- parsing ----------

object LiveParse {
    private fun JSONObject?.obj(k: String): JSONObject? = this?.optJSONObject(k)
    private fun JSONObject?.arr(k: String): JSONArray? = this?.optJSONArray(k)
    private fun JSONObject?.s(k: String): String {
        if (this == null || !has(k) || isNull(k)) return ""
        return when (val v = opt(k)) {
            is String -> v
            is Double -> if (v == Math.floor(v)) v.toLong().toString() else v.toString()
            null -> ""
            else -> v.toString()
        }
    }
    private fun JSONObject?.num(k: String): Double? = this?.opt(k)?.let { (it as? Number)?.toDouble() ?: it.toString().toDoubleOrNull() }
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    /** The live situation, from the summary itself when ESPN includes it there. */
    fun situationOf(root: JSONObject): JSONObject? =
        root.obj("situation") ?: root.obj("header").arr("competitions").objects().firstOrNull().obj("situation")

    /** Everything the live graphics need for [game], from a summary feed. [situation] overrides the summary's own. */
    fun parse(root: JSONObject, league: League, game: Game, situation: JSONObject? = null): Live {
        val sit = situation ?: situationOf(root)
        val plays = root.arr("plays").objects()
        return Live(
            baseball = if (league.sport == "baseball") baseball(sit, plays, league)?.let { b ->
                val fieldingHome = fieldingIsHome(game.statusShort.ifBlank { game.statusDetail })
                if (fieldingHome == null) b else {
                    val team = if (fieldingHome) game.home.team.id else game.away.team.id
                    b.copy(fieldingTeamId = team, fielders = fielders(root, team, b.pitcher, league))
                }
            } else null,
            football = if (league.sport == "football") football(sit, game, root) else null,
            shots = when (league.sport) {
                "basketball" -> basketballShots(plays)
                "hockey" -> hockeyShots(plays)
                else -> emptyList()
            },
            formations = if (league.kind == Kind.SOCCER) formations(root, league) else emptyList(),
            clips = clips(root),
            photos = Photos.fromSummary(root),
        )
    }

    private fun player(o: JSONObject?, league: League): LivePlayer? {
        val a = o.obj("athlete") ?: return null
        val name = a.s("shortName").ifBlank { a.s("displayName") }
        if (name.isBlank()) return null
        val id = a.s("id")
        val head = a.obj("headshot").s("href").ifBlank { a.s("headshot") }.ifBlank { league.headshotUrl(id) }
        return LivePlayer(id, name, head, o.s("summary"), a.obj("position").s("abbreviation"))
    }

    private fun occupied(sit: JSONObject?, k: String): Boolean = when (val v = sit?.opt(k)) {
        is Boolean -> v
        is JSONObject -> true
        is String -> v.equals("true", true)
        else -> false
    }

    fun pitchKind(text: String): PitchKind {
        val t = text.lowercase()
        return when {
            t.contains("hit by pitch") -> PitchKind.BALL
            t.contains("in play") || t.contains("hit into") || t.contains("single") || t.contains("double") ||
                t.contains("triple") || t.contains("home run") || t.contains("grounded") || t.contains("flied") ||
                t.contains("lined") || t.contains("popped") -> PitchKind.IN_PLAY
            t.contains("ball") && !t.contains("foul") -> PitchKind.BALL
            else -> PitchKind.STRIKE
        }
    }

    private fun isCalledStrike(text: String) = text.lowercase().let { it.contains("strike looking") || it.contains("called strike") }

    private fun baseball(sit: JSONObject?, plays: List<JSONObject>, league: League): BaseballLive? {
        val pitchPlays = plays.filter { it.obj("pitchCoordinate") != null }
        if (sit == null && pitchPlays.isEmpty()) return null
        fun pitch(p: JSONObject, i: Int): Pitch? {
            val c = p.obj("pitchCoordinate") ?: return null
            val x = c.num("x") ?: return null
            val y = c.num("y") ?: return null
            val text = p.obj("type").s("text").ifBlank { p.s("text") }
            return Pitch(
                n = p.s("atBatPitchNumber").toIntOrNull() ?: (i + 1),
                x = x, y = y,
                type = p.obj("pitchType").s("text").ifBlank { p.obj("pitchType").s("abbreviation") },
                mph = p.s("pitchVelocity").substringBefore("."),
                result = text,
                kind = pitchKind(text),
            )
        }
        // The current at-bat is the run of pitches sharing the last pitch's at-bat id.
        val lastAtBat = pitchPlays.lastOrNull()?.s("atBatId").orEmpty()
        val current = if (lastAtBat.isBlank()) pitchPlays.takeLast(1) else pitchPlays.filter { it.s("atBatId") == lastAtBat }
        val called = pitchPlays.filter { isCalledStrike(it.obj("type").s("text").ifBlank { it.s("text") }) }
            .mapNotNull { p -> p.obj("pitchCoordinate")?.let { c -> (c.num("x") ?: return@mapNotNull null) to (c.num("y") ?: return@mapNotNull null) } }
        val onDeck = sit.obj("onDeck").obj("athlete").let { it.s("shortName").ifBlank { it.s("displayName") } }
            .ifBlank { sit.arr("dueUp").objects().firstOrNull().obj("athlete").let { it.s("shortName").ifBlank { it.s("displayName") } } }
        return BaseballLive(
            balls = sit?.optInt("balls", 0) ?: 0,
            strikes = sit?.optInt("strikes", 0) ?: 0,
            outs = sit?.optInt("outs", 0) ?: 0,
            first = occupied(sit, "onFirst"), second = occupied(sit, "onSecond"), third = occupied(sit, "onThird"),
            pitcher = player(sit.obj("pitcher"), league),
            batter = player(sit.obj("batter"), league),
            onDeck = onDeck,
            pitches = current.mapIndexedNotNull { i, p -> pitch(p, i) },
            calledStrikes = called,
        )
    }

    /**
     * Where the ball is, on a 0-100 line from the away goal line to the home goal line, from ESPN's "KC 35" style
     * text. Returns null when the text can't be placed.
     */
    fun ballX(possessionText: String, awayAbbr: String, homeAbbr: String): Double? {
        val t = possessionText.trim()
        if (t.isBlank()) return null
        val yard = Regex("""(\d{1,2})\s*$""").find(t)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        if (yard == 50.0) return 50.0
        val side = t.substringBefore(" ").trim()
        return when {
            side.equals(awayAbbr, true) -> yard
            side.equals(homeAbbr, true) -> 100 - yard
            else -> null
        }
    }

    private fun football(sit: JSONObject?, game: Game, root: JSONObject): FootballLive? {
        if (sit == null) return null
        val poss = sit.s("possession")
        val down = sit.optInt("down", 0)
        val dist = sit.optInt("distance", 0)
        val text = sit.s("downDistanceText").ifBlank { sit.s("shortDownDistanceText") }
            .ifBlank { if (down in 1..4) "${listOf("1st", "2nd", "3rd", "4th")[down - 1]} & $dist" else "" }
        val x = ballX(sit.s("possessionText"), game.away.team.abbr, game.home.team.abbr)
        val dir = when (poss) {
            game.away.team.id -> 1
            game.home.team.id -> -1
            else -> 0
        }
        val goal = text.contains("goal", true)
        val gain = if (x == null || dir == 0 || down !in 1..4) null
        else if (goal) (if (dir > 0) 100.0 else 0.0)
        else (x + dir * dist).coerceIn(0.0, 100.0)
        fun timeouts(k: String) = sit.opt(k)?.let { (it as? Number)?.toInt() ?: it.toString().toIntOrNull() }
        return FootballLive(
            downText = text,
            possessionId = poss,
            ballX = x,
            toGainX = gain,
            redZone = sit.optBoolean("isRedZone", false),
            awayTimeouts = timeouts("awayTimeouts"),
            homeTimeouts = timeouts("homeTimeouts"),
            lastPlay = sit.obj("lastPlay").s("text").ifBlank { game.lastPlay },
            drive = root.obj("drives").obj("current").s("description"),
        )
    }

    private fun validCoord(v: Double?) = v != null && v > -1000 && v < 1000

    /**
     * Basketball shots in feet on a half court: x 0..50 across, y 0..47 up from the baseline. ESPN sometimes sends a
     * full court (y up to 94); shots in the far half are folded over so every shot lands on one basket.
     */
    fun basketballShots(plays: List<JSONObject>): List<Shot> = plays.mapNotNull { p ->
        if (!p.optBoolean("shootingPlay", false)) return@mapNotNull null
        val text = p.s("text")
        if (text.contains("free throw", true)) return@mapNotNull null
        val c = p.obj("coordinate") ?: return@mapNotNull null
        var x = c.num("x")
        var y = c.num("y")
        if (!validCoord(x) || !validCoord(y)) return@mapNotNull null
        if (y!! > 47) { y = 94 - y; x = 50 - x!! }
        Shot(x!!.coerceIn(0.0, 50.0), y.coerceIn(0.0, 47.0), p.optBoolean("scoringPlay", false), p.obj("team").s("id"), text,
            p.obj("period").s("number"), p.optInt("scoreValue", 0))
    }

    /** Hockey shots and goals on ESPN's rink grid. */
    fun hockeyShots(plays: List<JSONObject>): List<Shot> = plays.mapNotNull { p ->
        val type = p.obj("type").s("text")
        val isGoal = type.equals("Goal", true) || (p.optBoolean("scoringPlay", false) && p.optBoolean("shootingPlay", true))
        if (!isGoal && !type.contains("Shot", true)) return@mapNotNull null
        val c = p.obj("coordinate") ?: return@mapNotNull null
        val x = c.num("x")
        val y = c.num("y")
        if (!validCoord(x) || !validCoord(y)) return@mapNotNull null
        Shot(x!!.coerceIn(-100.0, 100.0), y!!.coerceIn(-42.5, 42.5), isGoal, p.obj("team").s("id"), p.s("text"),
            p.obj("period").s("number"), if (isGoal) 1 else 0)
    }

    /** 0 keeper, 1 defence, 2 holding midfield, 3 midfield, 4 attacking midfield, 5 attack. */
    fun depth(pos: String): Int {
        val p = pos.uppercase().replace("-", "")
        return when {
            p == "G" || p == "GK" -> 0
            p.startsWith("CD") || p.endsWith("B") || p == "D" || p == "SW" -> 1
            p.startsWith("DM") -> 2
            p.startsWith("AM") || p == "CAM" -> 4
            p == "F" || p.startsWith("CF") || p == "ST" || p.endsWith("W") || p == "SS" -> 5
            else -> 3
        }
    }

    /**
     * Left to right: -2 wide left (LB, LM, LW), -1 central but left (CD-L, CM-L), 0 centre, 1 and 2 on the right.
     * Wide players sit outside the central ones in their row.
     */
    fun side(pos: String): Int {
        val p = pos.uppercase()
        val tag = p.substringAfter("-", "")
        return when {
            tag == "L" -> -1
            tag == "R" -> 1
            tag.isEmpty() && p.startsWith("L") -> -2
            tag.isEmpty() && p.startsWith("R") -> 2
            else -> 0
        }
    }

    /** Split [players] (keeper excluded, back to front) into rows of the sizes in a shape like "4-2-3-1". */
    fun rows(shape: String, players: List<Pair<LivePlayer, String>>): List<List<LivePlayer>> {
        val sorted = players.sortedWith(compareBy({ depth(it.second) }))
        val counts = shape.split("-").mapNotNull { it.trim().toIntOrNull() }
        val sizes = if (counts.sum() == sorted.size && counts.isNotEmpty()) counts
        else sorted.groupBy { depth(it.second) }.toSortedMap().values.map { it.size }
        val out = ArrayList<List<LivePlayer>>()
        var i = 0
        for (n in sizes) {
            out.add(sorted.subList(i, i + n).sortedBy { side(it.second) }.map { it.first })
            i += n
        }
        return out
    }

    /**
     * Which team is in the field, from the inning text: the home team fields in the top half ("Top 7th", "End 6th"
     * leads into a top), the away team in the bottom ("Bot 7th", "Mid 7th"). Null when the text doesn't say.
     */
    fun fieldingIsHome(status: String): Boolean? {
        val s = status.trim().lowercase()
        return when {
            s.startsWith("top") || s.startsWith("end") -> true
            s.startsWith("bot") || s.startsWith("mid") -> false
            else -> null
        }
    }

    private val fieldPositions = setOf("P", "C", "1B", "2B", "3B", "SS", "LF", "CF", "RF")

    /**
     * Who's at each position for [teamId], from the box score. Box scores list starters first and substitutes after,
     * so a later player at a position replaces an earlier one; anyone marked as subbed out is skipped. The current
     * pitcher comes from the live situation. Returns empty when fewer than five positions can be placed.
     */
    fun fielders(root: JSONObject, teamId: String, pitcher: LivePlayer?, league: League): Map<String, LivePlayer> {
        val side = root.obj("boxscore").arr("players").objects().firstOrNull { it.obj("team").s("id") == teamId } ?: return emptyMap()
        val batting = side.arr("statistics").objects().firstOrNull { it.s("type").equals("batting", true) || it.s("name").equals("batting", true) }
            ?: side.arr("statistics").objects().firstOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, LivePlayer>()
        batting.arr("athletes").objects().forEach { e ->
            if (e.optBoolean("subbedOut", false) || (e.has("active") && !e.optBoolean("active", true))) return@forEach
            val a = e.obj("athlete") ?: return@forEach
            val raw = e.obj("position").s("abbreviation").ifBlank { a.obj("position").s("abbreviation") }.uppercase()
            val pos = raw.substringAfterLast("-")
            if (pos !in fieldPositions) return@forEach
            val id = a.s("id")
            out[pos] = LivePlayer(id, a.s("shortName").ifBlank { a.s("displayName") },
                a.obj("headshot").s("href").ifBlank { league.headshotUrl(id) }, pos = pos)
        }
        if (pitcher != null) out["P"] = pitcher.copy(pos = "P")
        return if (out.size >= 5) out else emptyMap()
    }

    /** Highlight clips with a playable link, newest first as ESPN lists them. */
    fun clips(root: JSONObject): List<Clip> = root.arr("videos").objects().mapNotNull { v ->
        val links = v.obj("links")
        val url = listOf(
            links.obj("source").obj("HD").s("href"),
            links.obj("source").s("href"),
            links.obj("mobile").obj("source").s("href"),
            links.obj("source").obj("HLS").s("href"),
            links.obj("mobile").s("href"),
        ).firstOrNull { u -> u.startsWith("http") && (u.contains(".mp4") || u.contains(".m3u8")) } ?: return@mapNotNull null
        val title = v.s("headline").ifBlank { v.s("title") }.ifBlank { v.s("description") }
        if (title.isBlank()) null else Clip(title, v.s("thumbnail").ifBlank { v.obj("posterImages").obj("default").s("href") }, url, v.optInt("duration", 0))
    }

    private fun formations(root: JSONObject, league: League): List<Formation> = root.arr("rosters").objects().mapNotNull { r ->
        val team = r.obj("team")
        val starters = r.arr("roster").objects().filter { it.optBoolean("starter", false) }
        if (starters.size < 11) return@mapNotNull null
        val withPos = starters.map { x ->
            val a = x.obj("athlete")
            val id = a.s("id")
            val pos = x.obj("position").s("abbreviation").ifBlank { a.obj("position").s("abbreviation") }
            LivePlayer(
                id = id,
                name = a.s("shortName").ifBlank { a.s("displayName") }.substringAfterLast(". ").substringAfterLast(' '),
                headshot = a.obj("headshot").s("href").ifBlank { league.headshotUrl(id) },
                pos = pos,
                jersey = x.s("jersey"),
            ) to pos
        }
        val keeper = withPos.firstOrNull { depth(it.second) == 0 } ?: withPos.first()
        val shape = r.s("formation").ifBlank { r.obj("formation").s("name") }
        Formation(team.s("id"), team.s("displayName").ifBlank { team.s("abbreviation") }, shape,
            listOf(listOf(keeper.first)) + rows(shape, withPos.filter { it !== keeper }))
    }
}
