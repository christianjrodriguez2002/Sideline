package com.roki.sideline.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

data class CalendarItem(val label: String, val start: Instant?, val end: Instant?)

/**
 * ESPN's public JSON feeds (no key, no account). Responses are cached briefly in memory; live data uses a short cache.
 *
 * Time zones: ESPN files games under US Eastern dates. To show "your" day correctly anywhere in the world, a day view
 * asks ESPN for the day before, the day itself and the day after, then keeps the games that start on your local date.
 */
object Espn {
    private const val LIVE_TTL = 20_000L
    private const val TTL = 5 * 60_000L
    private data class Entry(val at: Long, val json: JSONObject)
    private val cache = HashMap<String, Entry>()

    suspend fun get(url: String, ttl: Long = TTL, force: Boolean = false): JSONObject = withContext(Dispatchers.IO) {
        if (!force) synchronized(cache) {
            cache[url]?.takeIf { System.currentTimeMillis() - it.at < ttl }?.let { return@withContext it.json }
        }
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Sideline/2.7")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException(if (code == 404 || code == 400) "Nothing posted here yet." else "ESPN answered HTTP $code.")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val json = if (text.trimStart().startsWith("[")) JSONObject().put("items", org.json.JSONArray(text)) else JSONObject(text)
            synchronized(cache) { cache[url] = Entry(System.currentTimeMillis(), json) }
            json
        } finally {
            conn.disconnect()
        }
    }

    fun clear() = synchronized(cache) { cache.clear() }

    private val YMD = DateTimeFormatter.BASIC_ISO_DATE

    data class Board(val games: List<Game>, val week: Pair<Int, Int>?)

    private fun groupsParam(league: League, all: Boolean) = if (all && league.allGroups != null) "&groups=${league.allGroups}" else ""

    /** Games that start on [date] in the phone's time zone. */
    suspend fun day(league: League, date: LocalDate, all: Boolean = false, force: Boolean = false): List<Game> = coroutineScope {
        val zone = Fmt.zone()
        val days = listOf(date.minusDays(1), date, date.plusDays(1))
        val lists = days.map { d ->
            async {
                val ttl = if (d.isBefore(LocalDate.now(zone).minusDays(2))) 30 * 60_000L else LIVE_TTL
                runCatching {
                    Parse.scoreboard(get(league.site + "/scoreboard?dates=${YMD.format(d)}&limit=300" + groupsParam(league, all), ttl, force), league)
                }
            }
        }.awaitAll()
        if (lists.all { it.isFailure }) throw lists.first().exceptionOrNull() ?: IllegalStateException("Couldn't load scores.")
        onLocalDate(lists.flatMap { it.getOrDefault(emptyList()) }, date, zone)
    }

    /** Keeps the games that start on [date] in [zone], once each, in start order. */
    fun onLocalDate(games: List<Game>, date: LocalDate, zone: ZoneId): List<Game> =
        games.distinctBy { it.id }.filter { g -> g.start?.atZone(zone)?.toLocalDate() == date }.sortedBy { it.start ?: Instant.MAX }

    /** Football: one week at a time (null = this week). */
    suspend fun week(league: League, week: Pair<Int, Int>?, all: Boolean = false, force: Boolean = false): Board {
        val q = (if (week != null) "?week=${week.first}&seasontype=${week.second}" else "?limit=300") +
            (if (week != null) "&limit=300" else "") + groupsParam(league, all)
        val root = get(league.site + "/scoreboard" + q, LIVE_TTL, force)
        return Board(Parse.scoreboard(root, league), Parse.week(root))
    }

    /** ESPN's "current" slate: the next or latest matchday. Used when a day is empty. */
    suspend fun current(league: League, force: Boolean = false): List<Game> =
        Parse.scoreboard(get(league.site + "/scoreboard?limit=300", LIVE_TTL, force), league)

    suspend fun standings(league: League, force: Boolean = false) = Parse.standings(get(league.standingsUrl, TTL, force), league)

    suspend fun rankings(league: League, force: Boolean = false) = Parse.rankings(get(league.site + "/rankings", TTL, force))

    suspend fun teams(league: League) = Parse.teams(get(league.site + "/teams?limit=1000", 24 * 3600_000L))

    suspend fun team(league: League, id: String, force: Boolean = false) = Parse.teamDetail(get(league.site + "/teams/$id", TTL, force))

    /** The team's regular-season bye week, or 0 when the league has none. Uses the cached schedule feed. */
    suspend fun byeWeek(league: League, id: String, force: Boolean = false): Int =
        if (!league.weekly) 0 else runCatching { Parse.byeWeek(get(league.site + "/teams/$id/schedule", TTL, force)) }.getOrDefault(0)

    suspend fun schedule(league: League, id: String, force: Boolean = false): List<Game> {
        val regular = Parse.schedule(get(league.site + "/teams/$id/schedule", TTL, force), league)
        val post = if (league.kind == Kind.TEAM)
            runCatching { Parse.schedule(get(league.site + "/teams/$id/schedule?seasontype=3", TTL, force), league) }.getOrDefault(emptyList())
        else emptyList()
        return (regular + post).distinctBy { it.id }.sortedBy { it.start ?: Instant.MAX }
    }

    suspend fun roster(league: League, id: String) = Parse.roster(get(league.site + "/teams/$id/roster", 30 * 60_000L))
        .map { p -> if (p.headshot.isBlank()) p.copy(headshot = league.headshotUrl(p.id)) else p }

    suspend fun injuries(league: League, force: Boolean = false) =
        if (!league.injuries) emptyList() else Parse.injuries(get(league.site + "/injuries", TTL, force))
            .map { i -> if (i.headshot.isBlank()) i.copy(headshot = league.headshotUrl(i.athleteId)) else i }

    suspend fun news(league: League, teamId: String? = null, force: Boolean = false): List<Article> {
        val url = league.site + "/news?limit=40" + (teamId?.let { "&team=$it" } ?: "")
        val list = runCatching { Parse.articles(get(url, TTL, force)) }.getOrElse { if (teamId == null) throw it else emptyList() }
        if (list.isNotEmpty() || teamId == null) return list
        return runCatching { Parse.articles(get(league.site + "/teams/$teamId/news", TTL, force)) }.getOrDefault(emptyList())
    }

    suspend fun transactions(league: League, force: Boolean = false) =
        Parse.transactions(get(league.site + "/transactions?limit=60", TTL, force))

    suspend fun game(league: League, eventId: String, force: Boolean = false): GameDetail? {
        val d = Parse.gameDetail(get(league.site + "/summary?event=$eventId", LIVE_TTL, force), league) ?: return null
        fun fill(l: Leader) = if (l.headshot.isBlank()) l.copy(headshot = league.headshotUrl(l.athleteId)) else l
        return d.copy(
            leaders = d.leaders.map { (g, list) -> g to list.map(::fill) },
            injuries = d.injuries.map { i -> if (i.headshot.isBlank()) i.copy(headshot = league.headshotUrl(i.athleteId)) else i },
        )
    }

    suspend fun athlete(league: League, id: String) = Parse.overview(get(league.athleteBase + "/$id/overview", TTL))

    // ---------- event sports ----------

    private fun eventUrl(league: League, date: LocalDate?) =
        league.site + "/scoreboard" + (date?.let { "?dates=${YMD.format(it)}" } ?: "")

    suspend fun fights(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.fightCards(get(eventUrl(league, date), LIVE_TTL, force)).map { card ->
            fun fill(f: Fighter) = if (f.headshot.isBlank()) f.copy(headshot = league.headshotUrl(f.id)) else f
            card.copy(fights = card.fights.map { it.copy(a = fill(it.a), b = fill(it.b)) })
        }

    suspend fun races(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.raceWeekends(get(eventUrl(league, date), LIVE_TTL, force))

    suspend fun golf(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.tournaments(get(eventUrl(league, date), LIVE_TTL, force))

    suspend fun tennis(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.tennisEvents(get(eventUrl(league, date), LIVE_TTL, force))

    /** The season's event list (Grands Prix, tournaments, fight cards) from the scoreboard's calendar. */
    suspend fun calendar(league: League): List<CalendarItem> {
        val root = get(league.site + "/scoreboard", 60 * 60_000L)
        val cal = root.optJSONArray("leagues")?.optJSONObject(0)?.optJSONArray("calendar") ?: return emptyList()
        return (0 until cal.length()).mapNotNull { i ->
            val o = cal.optJSONObject(i) ?: return@mapNotNull null
            val label = o.optString("label", "").ifBlank { o.optString("name", "") }
            if (label.isBlank()) null
            else CalendarItem(label, Parse.instant(o.optString("startDate", "")), Parse.instant(o.optString("endDate", "")))
        }.sortedBy { it.start ?: Instant.MAX }
    }

    /** Local date ESPN should be asked about for an event that starts at [start] (ESPN uses US Eastern days). */
    fun espnDate(start: Instant?): LocalDate? = start?.atZone(ZoneId.of("America/New_York"))?.toLocalDate()

    suspend fun cricket(force: Boolean = false): List<CricketSeries> {
        val tz = Fmt.zone().id
        return Parse.cricket(get("https://site.api.espn.com/apis/personalized/v2/scoreboard/header?sport=cricket&region=us&tz=$tz",
            LIVE_TTL, force))
    }
}
