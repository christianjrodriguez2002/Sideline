package com.roki.sideline.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

data class CalendarItem(val label: String, val start: Instant?, val end: Instant?)

/**
 * ESPN's public JSON feeds (no key, no account). Responses are cached briefly in memory; live data uses a short cache.
 *
 * Time zones: ESPN files games under US Eastern dates. To show "your" day correctly anywhere in the world, a day view
 * asks ESPN for the day before, the day itself and the day after, then keeps the games that start on your local date.
 */
object Espn {
    private const val LIVE_TTL = 20_000L
    private const val TTL = 5 * 60_000L
    private data class Entry(val at: Long, val json: JSONObject)
    private val cache = HashMap<String, Entry>()

    /** Folder for the on-disk copy of each feed, set by the Application. Null means memory only. */
    @Volatile var diskDir: java.io.File? = null

    /** True when the last answer came from the disk copy because the network failed. */
    val offline = androidx.compose.runtime.mutableStateOf(false)

    private fun diskFile(url: String) = diskDir?.let { java.io.File(it, url.hashCode().toUInt().toString(16) + ".json") }

    private fun readDisk(url: String): JSONObject? = runCatching {
        diskFile(url)?.takeIf { it.exists() }?.readText()?.let { JSONObject(it) }
    }.getOrNull()

    private fun writeDisk(url: String, json: JSONObject) {
        runCatching { diskFile(url)?.let { f -> f.parentFile?.mkdirs(); f.writeText(json.toString()) } }
    }

    /** Requests already on the way: a second caller for the same feed waits for the first instead of refetching. */
    private val inFlight = HashMap<String, kotlinx.coroutines.Deferred<JSONObject>>()
    /** At most six downloads at once, so a Home screen full of teams doesn't flood the connection. */
    private val gate = kotlinx.coroutines.sync.Semaphore(6)
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)

    suspend fun get(url: String, ttl: Long = TTL, force: Boolean = false): JSONObject {
        if (!force) synchronized(cache) {
            cache[url]?.takeIf { System.currentTimeMillis() - it.at < ttl }?.let { return it.json }
        }
        val job = synchronized(inFlight) {
            inFlight[url]?.takeIf { it.isActive } ?: scope.async { load(url, ttl) }.also { inFlight[url] = it }
        }
        return try {
            job.await()
        } finally {
            synchronized(inFlight) { if (inFlight[url] === job && !job.isActive) inFlight.remove(url) }
        }
    }

    private suspend fun load(url: String, ttl: Long): JSONObject = withContext(Dispatchers.IO) {
        try {
            val json = gate.withPermit { fetch(url) }
            synchronized(cache) { cache[url] = Entry(System.currentTimeMillis(), json) }
            writeDisk(url, json)
            offline.value = false
            json
        } catch (e: java.io.IOException) {
            // No network: the last copy of this feed is better than an error screen.
            val saved = readDisk(url) ?: throw e
            offline.value = true
            synchronized(cache) { cache[url] = Entry(System.currentTimeMillis() - ttl + 10_000, saved) }
            saved
        }
    }

    private fun fetch(url: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Sideline/3.2")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException(if (code == 404 || code == 400) "Nothing posted here yet." else "ESPN answered HTTP $code.")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            return if (text.trimStart().startsWith("[")) JSONObject().put("items", org.json.JSONArray(text)) else JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    fun clear() {
        synchronized(cache) { cache.clear() }
        runCatching { diskDir?.listFiles()?.forEach { it.delete() } }
    }

    private val YMD = DateTimeFormatter.BASIC_ISO_DATE

    data class Board(val games: List<Game>, val week: Pair<Int, Int>?)

    private fun groupsParam(league: League, all: Boolean) = if (all && league.allGroups != null) "&groups=${league.allGroups}" else ""

    /** Games that start on [date] in the phone's time zone. */
    suspend fun day(league: League, date: LocalDate, all: Boolean = false, force: Boolean = false): List<Game> = coroutineScope {
        val zone = Fmt.zone()
        val days = listOf(date.minusDays(1), date, date.plusDays(1))
        val lists = days.map { d ->
            async {
                val ttl = if (d.isBefore(LocalDate.now(zone).minusDays(2))) 30 * 60_000L else LIVE_TTL
                runCatching {
                    Parse.scoreboard(get(league.site + "/scoreboard?dates=${YMD.format(d)}&limit=300" + groupsParam(league, all), ttl, force), league)
                }
            }
        }.awaitAll()
        if (lists.all { it.isFailure }) throw lists.first().exceptionOrNull() ?: IllegalStateException("Couldn't load scores.")
        onLocalDate(lists.flatMap { it.getOrDefault(emptyList()) }, date, zone)
    }

    /** Keeps the games that start on [date] in [zone], once each, in start order. */
    fun onLocalDate(games: List<Game>, date: LocalDate, zone: ZoneId): List<Game> =
        games.distinctBy { it.id }.filter { g -> g.start?.atZone(zone)?.toLocalDate() == date }.sortedBy { it.start ?: Instant.MAX }

    /** Football: one week at a time (null = this week). */
    suspend fun week(league: League, week: Pair<Int, Int>?, all: Boolean = false, force: Boolean = false): Board {
        val q = (if (week != null) "?week=${week.first}&seasontype=${week.second}" else "?limit=300") +
            (if (week != null) "&limit=300" else "") + groupsParam(league, all)
        val root = get(league.site + "/scoreboard" + q, LIVE_TTL, force)
        return Board(Parse.scoreboard(root, league), Parse.week(root))
    }

    /** ESPN's "current" slate: the next or latest matchday. Used when a day is empty. */
    suspend fun current(league: League, force: Boolean = false): List<Game> =
        Parse.scoreboard(get(league.site + "/scoreboard?limit=300", LIVE_TTL, force), league)

    suspend fun standings(league: League, force: Boolean = false) = Parse.standings(get(league.standingsUrl, TTL, force), league)

    suspend fun rankings(league: League, force: Boolean = false) = Parse.rankings(get(league.site + "/rankings", TTL, force))

    suspend fun teams(league: League) = Parse.teams(get(league.site + "/teams?limit=1000", 24 * 3600_000L))

    suspend fun team(league: League, id: String, force: Boolean = false) = Parse.teamDetail(get(league.site + "/teams/$id", TTL, force))

    /** The team's regular-season bye week, or 0 when the league has none. Uses the cached schedule feed. */
    suspend fun byeWeek(league: League, id: String, force: Boolean = false): Int =
        if (!league.weekly) 0 else runCatching { Parse.byeWeek(get(league.site + "/teams/$id/schedule", TTL, force)) }.getOrDefault(0)

    suspend fun schedule(league: League, id: String, force: Boolean = false): List<Game> {
        val regular = Parse.schedule(get(league.site + "/teams/$id/schedule", TTL, force), league)
        val post = if (league.kind == Kind.TEAM)
            runCatching { Parse.schedule(get(league.site + "/teams/$id/schedule?seasontype=3", TTL, force), league) }.getOrDefault(emptyList())
        else emptyList()
        return (regular + post).distinctBy { it.id }.sortedBy { it.start ?: Instant.MAX }
    }

    suspend fun roster(league: League, id: String) = Parse.roster(get(league.site + "/teams/$id/roster", 30 * 60_000L))
        .map { p -> if (p.headshot.isBlank()) p.copy(headshot = league.headshotUrl(p.id)) else p }

    suspend fun injuries(league: League, force: Boolean = false) =
        if (!league.injuries) emptyList() else Parse.injuries(get(league.site + "/injuries", TTL, force))
            .map { i -> if (i.headshot.isBlank()) i.copy(headshot = league.headshotUrl(i.athleteId)) else i }

    suspend fun news(league: League, teamId: String? = null, force: Boolean = false): List<Article> {
        val url = league.site + "/news?limit=40" + (teamId?.let { "&team=$it" } ?: "")
        val list = runCatching { Parse.articles(get(url, TTL, force)) }.getOrElse { if (teamId == null) throw it else emptyList() }
        if (list.isNotEmpty() || teamId == null) return list
        return runCatching { Parse.articles(get(league.site + "/teams/$teamId/news", TTL, force)) }.getOrDefault(emptyList())
    }

    suspend fun transactions(league: League, force: Boolean = false) =
        Parse.transactions(get(league.site + "/transactions?limit=60", TTL, force))

    suspend fun game(league: League, eventId: String, force: Boolean = false): GameDetail? {
        val d = Parse.gameDetail(get(league.site + "/summary?event=$eventId", LIVE_TTL, force), league) ?: return null
        fun fill(l: Leader) = if (l.headshot.isBlank()) l.copy(headshot = league.headshotUrl(l.athleteId)) else l
        // Baseball and football graphics need the live situation. When the summary leaves it out, the day's
        // scoreboard carries it for every game in progress.
        var live = d.live
        val needsSituation = d.game.state == GameState.IN && (league.sport == "baseball" || league.sport == "football") &&
            (live?.baseball?.pitcher == null && live?.football?.downText.isNullOrBlank())
        if (needsSituation) {
            val day = espnDate(d.game.start)?.let { YMD.format(it) }
            val board = runCatching { get(league.site + "/scoreboard" + (day?.let { "?dates=$it" } ?: ""), LIVE_TTL, force) }.getOrNull()
            val event = board?.optJSONArray("events")?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) } }
                ?.firstOrNull { it.optString("id") == eventId }
            val sit = event?.optJSONArray("competitions")?.optJSONObject(0)?.optJSONObject("situation")
            if (sit != null) {
                val root = get(league.site + "/summary?event=$eventId", LIVE_TTL)
                live = runCatching { LiveParse.parse(root, league, d.game, sit) }.getOrNull() ?: live
            }
        }
        return d.copy(
            live = live,
            leaders = d.leaders.map { (g, list) -> g to list.map(::fill) },
            injuries = d.injuries.map { i -> if (i.headshot.isBlank()) i.copy(headshot = league.headshotUrl(i.athleteId)) else i },
        )
    }

    /** A game's photos: recap and related stories first, then each team's news from the game window. */
    suspend fun gamePhotos(league: League, g: Game, fromSummary: List<GamePhoto>, force: Boolean = false): List<GamePhoto> {
        val start = g.start ?: return fromSummary
        val (from, to) = Photos.gameWindow(start)
        val teams = coroutineScope {
            listOf(g.away.team.id, g.home.team.id).map { id ->
                async { runCatching { Photos.fromNews(get(league.site + "/news?limit=50&team=$id", TTL, force), from, to) }.getOrDefault(emptyList()) }
            }.awaitAll()
        }
        return Photos.merge(fromSummary, *teams.toTypedArray()).take(40)
    }

    /** An event's photos (fight card, race weekend, tournament): the league's news from the event window. */
    suspend fun eventPhotos(league: League, start: Instant, end: Instant?, force: Boolean = false): List<GamePhoto> {
        val (from, to) = Photos.eventWindow(start, end)
        return Photos.merge(Photos.fromNews(get(league.site + "/news?limit=50", TTL, force), from, to)).take(40)
    }

    /** League stat leaders (top 10 per category). */
    suspend fun leaders(league: League, force: Boolean = false): List<LeaderBoard> =
        More.leaders(get("https://site.api.espn.com/apis/site/v3/sports/${league.sport}/${league.slug}/leaders", 60 * 60_000L, force))

    /** A team's season stats by category. */
    suspend fun teamStats(league: League, id: String, force: Boolean = false): List<Pair<String, List<TeamStat>>> =
        More.teamStats(get(league.site + "/teams/$id/statistics", 60 * 60_000L, force))

    /** This season's postseason games, grouped into rounds and series. Empty before the playoffs start. */
    suspend fun playoffs(league: League, force: Boolean = false): List<Round> {
        val year = java.time.LocalDate.now(Fmt.zone()).year
        val games = (listOf(year - 1, year)).flatMap { y ->
            runCatching { Parse.scoreboard(get(league.site + "/scoreboard?seasontype=3&dates=$y&limit=500", 30 * 60_000L, force), league) }
                .getOrDefault(emptyList())
        }.distinctBy { it.id }
        // Keep the most recent postseason only: games within ten months of the newest one.
        val newest = games.mapNotNull { it.start }.maxOrNull() ?: return emptyList()
        return More.rounds(games.filter { (it.start ?: newest).isAfter(newest.minusSeconds(300L * 24 * 3600)) })
    }

    /** Players matching [q] from ESPN's search. */
    suspend fun searchPlayers(q: String): List<PlayerHit> {
        val enc = java.net.URLEncoder.encode(q.trim(), "UTF-8")
        return More.searchPlayers(get("https://site.web.api.espn.com/apis/search/v2?query=$enc&limit=25&type=player", 10 * 60_000L))
    }

    suspend fun athlete(league: League, id: String) = Parse.overview(get(league.athleteBase + "/$id/overview", TTL))

    // ---------- event sports ----------

    private fun eventUrl(league: League, date: LocalDate?) =
        league.site + "/scoreboard" + (date?.let { "?dates=${YMD.format(it)}" } ?: "")

    suspend fun fights(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.fightCards(get(eventUrl(league, date), LIVE_TTL, force)).map { card ->
            fun fill(f: Fighter) = if (f.headshot.isBlank()) f.copy(headshot = league.headshotUrl(f.id)) else f
            card.copy(fights = card.fights.map { it.copy(a = fill(it.a), b = fill(it.b)) })
        }

    suspend fun races(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.raceWeekends(get(eventUrl(league, date), LIVE_TTL, force))

    suspend fun golf(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.tournaments(get(eventUrl(league, date), LIVE_TTL, force))

    suspend fun tennis(league: League, date: LocalDate? = null, force: Boolean = false) =
        Parse.tennisEvents(get(eventUrl(league, date), LIVE_TTL, force))

    /** The season's event list (Grands Prix, tournaments, fight cards) from the scoreboard's calendar. */
    suspend fun calendar(league: League): List<CalendarItem> {
        val root = get(league.site + "/scoreboard", 60 * 60_000L)
        val cal = root.optJSONArray("leagues")?.optJSONObject(0)?.optJSONArray("calendar") ?: return emptyList()
        return (0 until cal.length()).mapNotNull { i ->
            val o = cal.optJSONObject(i) ?: return@mapNotNull null
            val label = o.optString("label", "").ifBlank { o.optString("name", "") }
            if (label.isBlank()) null
            else CalendarItem(label, Parse.instant(o.optString("startDate", "")), Parse.instant(o.optString("endDate", "")))
        }.sortedBy { it.start ?: Instant.MAX }
    }

    /** Local date ESPN should be asked about for an event that starts at [start] (ESPN uses US Eastern days). */
    fun espnDate(start: Instant?): LocalDate? = start?.atZone(ZoneId.of("America/New_York"))?.toLocalDate()

    suspend fun cricket(force: Boolean = false): List<CricketSeries> {
        val tz = Fmt.zone().id
        return Parse.cricket(get("https://site.api.espn.com/apis/personalized/v2/scoreboard/header?sport=cricket&region=us&tz=$tz",
            LIVE_TTL, force))
    }
}
