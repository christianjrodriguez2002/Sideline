package com.roki.sideline.data

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** A newer build published under the repo's Releases. */
data class Update(val version: String, val apkUrl: String, val pageUrl: String, val notes: String = "")

/** Where the update download stands; the Home banner watches this. */
sealed class Download {
    object Idle : Download()
    data class Running(val percent: Int) : Download()
    data class Done(val file: File) : Download()
    data class Failed(val reason: String) : Download()
}

/**
 * Checks GitHub Releases for a newer Sideline, downloads the APK into the app's own folder, and opens the installer.
 * The installed version comes from the package itself, so nothing here changes when the version number does.
 */
object Updates {
    const val REPO = "christianjrodriguez2002/Sideline"
    const val RELEASES = "https://github.com/$REPO/releases"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    private const val TTL = 6 * 3600_000L

    val download = mutableStateOf<Download>(Download.Idle)

    fun installed(context: Context): String =
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()

    /** The newest release if it is newer than what's installed and hasn't been dismissed, otherwise null. */
    suspend fun check(context: Context, force: Boolean = false): Update? {
        cleanup(context)
        val root = runCatching { Espn.get(API, TTL, force) }.getOrNull() ?: return null
        val tag = root.optString("tag_name")
        val latest = versionOf(root.optString("name")).ifBlank { versionOf(tag) }
        if (latest.isBlank() || !newer(latest, installed(context))) return null
        val assets = root.optJSONArray("assets")
        val apk = (0 until (assets?.length() ?: 0)).mapNotNull { assets?.optJSONObject(it) }
            .firstOrNull { it.optString("name").endsWith(".apk") }?.optString("browser_download_url").orEmpty()
        if (apk.isBlank()) return null
        val skipped = Favorites.prefs(context).getString("skipUpdate", "")
        if (skipped == latest) return null
        val u = Update(latest, apk, root.optString("html_url").ifBlank { RELEASES }, notes(root.optString("body")))
        // A finished download from an earlier visit is still good: offer Install straight away.
        val f = file(context, u)
        if (download.value is Download.Idle && f.exists() && f.length() > 0) download.value = Download.Done(f)
        return u
    }

    /** Remember that this version was dismissed so the banner stays away until the next one. */
    fun skip(context: Context, u: Update) {
        Favorites.prefs(context).edit().putString("skipUpdate", u.version).apply()
    }

    /** Drop downloaded APKs that are no newer than what's running, so old installers don't pile up. */
    private fun cleanup(context: Context) {
        val mine = installed(context)
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.listFiles()?.forEach { f ->
            if (f.name.endsWith(".apk") && !newer(versionOf(f.name), mine)) runCatching { f.delete() }
        }
    }

    private fun file(context: Context, u: Update) =
        File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Sideline-${u.version}.apk")

    /** Download into the app's folder and watch progress until the installer can open it. */
    fun start(context: Context, u: Update) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
        if (dm == null) { download.value = Download.Failed("Downloads aren't available on this phone."); return }
        val target = file(context, u)
        runCatching { target.delete() }
        val req = DownloadManager.Request(Uri.parse(u.apkUrl))
            .setTitle("Sideline ${u.version}")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, target.name)
        val id = runCatching { dm.enqueue(req) }.getOrElse { download.value = Download.Failed("Couldn't start the download."); return }
        download.value = Download.Running(0)
        CoroutineScope(Dispatchers.IO).launch {
            while (true) {
                delay(500)
                var status = -1
                var done = 0L
                var total = -1L
                var reason = 0
                dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                    if (c.moveToFirst()) {
                        status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                        done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                        total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                        reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                    }
                }
                when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> { download.value = Download.Done(target); return@launch }
                    DownloadManager.STATUS_FAILED, -1 -> {
                        download.value = Download.Failed(if (reason == DownloadManager.ERROR_INSUFFICIENT_SPACE) "Not enough storage." else "Download failed. Try again.")
                        return@launch
                    }
                    else -> download.value = Download.Running(if (total > 0) (100 * done / total).toInt().coerceIn(0, 99) else 0)
                }
            }
        }
    }

    /**
     * Open the system installer for the downloaded APK. The first time, Android asks you to allow Sideline to install
     * apps; that screen opens instead, and tapping Install again afterwards goes straight to the installer.
     */
    fun install(context: Context, file: File) {
        if (Build.VERSION.SDK_INT >= 26 && !context.packageManager.canRequestPackageInstalls()) {
            val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(i) }
            return
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        runCatching { context.startActivity(i) }.onFailure { download.value = Download.Failed("Couldn't open the installer.") }
    }

    /** Release notes as plain lines: markdown bullets and headings stripped, blank lines dropped. */
    fun notes(body: String): String = body.lines()
        .map { it.trim().trimStart('#', '-', '*', ' ') }
        .filter { it.isNotBlank() }
        .joinToString("\n") { "• $it" }

    /** "2.4" out of "Sideline 2.4", "v2.4-build7" or "2.4". */
    fun versionOf(s: String): String = Regex("""\d+(\.\d+)+""").find(s)?.value ?: ""

    /** True when [a] is a higher version than [b], comparing number by number. */
    fun newer(a: String, b: String): Boolean {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrNull(i) ?: 0) - (y.getOrNull(i) ?: 0)
            if (d != 0) return d > 0
        }
        return false
    }
}
