package com.roki.sideline.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment

/** A newer build published under the repo's Releases. */
data class Update(val version: String, val apkUrl: String, val pageUrl: String)

/**
 * Checks GitHub Releases for a newer Sideline and hands the APK to the system downloader. The installed version comes
 * from the package itself, so nothing needs updating here when the version number changes.
 */
object Updates {
    const val REPO = "christianjrodriguez2002/Sideline"
    const val RELEASES = "https://github.com/$REPO/releases"
    private const val API = "https://api.github.com/repos/$REPO/releases/latest"
    private const val TTL = 6 * 3600_000L

    fun installed(context: Context): String =
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()

    /** The newest release if it is newer than what's installed and hasn't been dismissed, otherwise null. */
    suspend fun check(context: Context, force: Boolean = false): Update? {
        val root = runCatching { Espn.get(API, TTL, force) }.getOrNull() ?: return null
        val tag = root.optString("tag_name")
        val latest = versionOf(root.optString("name")).ifBlank { versionOf(tag) }
        if (latest.isBlank() || !newer(latest, installed(context))) return null
        val assets = root.optJSONArray("assets")
        val apk = (0 until (assets?.length() ?: 0)).mapNotNull { assets?.optJSONObject(it) }
            .firstOrNull { it.optString("name").endsWith(".apk") }?.optString("browser_download_url").orEmpty()
        if (apk.isBlank()) return null
        val skipped = Favorites.prefs(context).getString("skipUpdate", "")
        if (skipped == latest) return null
        return Update(latest, apk, root.optString("html_url").ifBlank { RELEASES })
    }

    /** Remember that this version was dismissed so the banner stays away until the next one. */
    fun skip(context: Context, u: Update) {
        Favorites.prefs(context).edit().putString("skipUpdate", u.version).apply()
    }

    /** Download with the system downloader; tapping the finished download notification opens the installer. */
    fun download(context: Context, u: Update) {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager ?: return
        val req = DownloadManager.Request(Uri.parse(u.apkUrl))
            .setTitle("Sideline ${u.version}")
            .setDescription("Tap when finished to install")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "Sideline-${u.version}.apk")
        runCatching { dm.enqueue(req) }
    }

    /** "2.4" out of "Sideline 2.4", "v2.4-build7" or "2.4". */
    fun versionOf(s: String): String = Regex("""\d+(\.\d+)+""").find(s)?.value ?: ""

    /** True when [a] is a higher version than [b], comparing number by number. */
    fun newer(a: String, b: String): Boolean {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = (x.getOrNull(i) ?: 0) - (y.getOrNull(i) ?: 0)
            if (d != 0) return d > 0
        }
        return false
    }
}
