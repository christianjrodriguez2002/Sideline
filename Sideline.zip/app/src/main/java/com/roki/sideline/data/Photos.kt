package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** A news photo from a game or event, with the caption and photographer credit ESPN publishes with it. */
data class GamePhoto(val url: String, val caption: String, val credit: String, val fromRecap: Boolean = false)

/**
 * Game and event photos from ESPN's free data. Sources, in the order they're shown:
 *  1. the recap story's photos, attached to the game summary
 *  2. related stories attached to the game summary
 *  3. each team's news from the game window (team sports)
 *  4. the league's news from the event window (UFC, racing, golf, tennis)
 * Logo composites ("stitcher" images) and tiny images are skipped, and the same photo is only shown once.
 */
object Photos {
    private fun JSONObject?.obj(k: String): JSONObject? = this?.optJSONObject(k)
    private fun JSONObject?.arr(k: String): JSONArray? = this?.optJSONArray(k)
    private fun JSONObject?.s(k: String): String = if (this == null || !has(k) || isNull(k)) "" else opt(k)?.toString().orEmpty()
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    /** Photos worth showing from one story's image list. */
    fun fromImages(images: JSONArray?): List<GamePhoto> = images.objects().mapNotNull { i ->
        val url = i.s("url").ifBlank { i.s("href") }
        if (!url.startsWith("http")) return@mapNotNull null
        val type = i.s("type").lowercase()
        if (type == "stitcher" || type == "logo" || url.contains("/teamlogos/")) return@mapNotNull null
        val w = i.optInt("width", 0)
        if (w in 1..299) return@mapNotNull null
        GamePhoto(url, i.s("caption").ifBlank { i.s("alt") }.ifBlank { i.s("name") }, i.s("credit"))
    }

    /** Sources 1 and 2: the recap and related stories inside a game summary. */
    fun fromSummary(root: JSONObject): List<GamePhoto> {
        val recap = fromImages(root.obj("article").arr("images")).map { it.copy(fromRecap = true) }
        val news = (root.obj("news").arr("articles") ?: root.arr("news")).objects().flatMap { fromImages(it.arr("images")) }
        return recap + news
    }

    /** Sources 3 and 4: every photo from news stories published inside [from]..[to]. */
    fun fromNews(root: JSONObject, from: Instant, to: Instant): List<GamePhoto> =
        (root.arr("articles") ?: root.arr("feed") ?: root.obj("news").arr("articles")).objects().flatMap { a ->
            val at = Parse.instant(a.s("published")) ?: return@flatMap emptyList()
            if (at.isBefore(from) || at.isAfter(to)) emptyList() else fromImages(a.arr("images"))
        }

    /** The same picture at another size has the same file name apart from a "_1296x729" style size tag. */
    fun key(url: String): String =
        url.substringAfterLast('/').substringBefore('?').substringBeforeLast('.').replace(Regex("""_\d+x\d+.*$"""), "").lowercase()

    /** Whether [text] names [term] as a whole word. Team names are matched with their capitals ("Rays", not "rays"). */
    private fun mentions(text: String, term: String, anyCase: Boolean = false): Boolean {
        if (term.length < 3 || !text.contains(term, ignoreCase = true)) return false
        val opts = if (anyCase) setOf(RegexOption.IGNORE_CASE) else emptySet()
        return Regex("""(?<![\w])""" + Regex.escape(term) + """(?![\w])""", opts).containsMatchIn(text)
    }

    /** Words too common to identify a team on their own ("Manchester City" vs "a city"). */
    private val generic = setOf("city", "united", "club", "real", "sporting", "athletic", "state", "university", "college",
        "national", "team", "inter", "fc", "cf", "sc", "afc")

    /** Ways a caption can name a team: full name, short name and nickname (the last word, when it's distinctive). */
    private fun terms(t: TeamRef): List<String> {
        val nick = t.name.substringAfterLast(' ').takeIf { it.length >= 4 && it.lowercase() !in generic && it != t.name }
        return listOfNotNull(t.name, t.shortName, nick).filter { it.isNotBlank() && it.lowercase() !in generic }.distinct()
    }

    /** Postseason rounds. A photo naming one belongs to a playoff game. */
    private val rounds = listOf(
        "World Series", "Division Series", "Championship Series", "ALDS", "NLDS", "ALCS", "NLCS", "Wild Card",
        "Super Bowl", "AFC Championship", "NFC Championship", "Divisional Round", "Conference Finals", "Conference Semifinals",
        "NBA Finals", "WNBA Finals", "Stanley Cup Final", "Play-In", "College Football Playoff", "NCAA Tournament", "Final Four",
        "Elite Eight", "Sweet 16", "Sweet Sixteen", "All-Star",
    )

    /** Competitions a soccer or rugby caption may name, longest first so "Club World Cup" isn't read as "World Cup". */
    private val competitions = listOf(
        "FIFA Club World Cup", "Club World Cup", "UEFA Champions League", "Champions League", "UEFA Europa League", "Europa League",
        "Conference League", "Nations League", "Premier League", "FA Cup", "Carabao Cup", "EFL Cup", "League Cup", "Community Shield",
        "LaLiga", "La Liga", "Copa del Rey", "Supercopa", "Bundesliga", "DFB Cup", "DFB-Pokal", "Serie A", "Coppa Italia",
        "Supercoppa", "Ligue 1", "Coupe de France", "Trophee des Champions", "MLS Cup", "Leagues Cup", "U.S. Open Cup",
        "Concacaf Champions Cup", "Gold Cup", "Copa Libertadores", "Copa Sudamericana", "Copa America", "World Cup qualifier",
        "World Cup Qualifier", "FIFA World Cup", "World Cup", "UEFA Euro", "EURO 20", "Euro 20", "friendly", "Six Nations",
        "Rugby World Cup", "Autumn Nations", "Rugby Championship",
    ).sortedByDescending { it.length }

    /** The names a league's own games go by. */
    private fun ownCompetitions(leagueKey: String, label: String): List<String> = listOf(label) + when (leagueKey) {
        "EPL" -> listOf("Premier League")
        "UCL" -> listOf("Champions League", "UEFA Champions League")
        "LALIGA" -> listOf("LaLiga", "La Liga")
        "MLS" -> listOf("MLS Cup")
        "WORLDCUP" -> listOf("World Cup", "FIFA World Cup")
        "EURO" -> listOf("UEFA Euro", "EURO 20", "Euro 20")
        "COPA" -> listOf("Copa America")
        "SIXNATIONS" -> listOf("Six Nations")
        "RWC" -> listOf("Rugby World Cup", "World Cup")
        else -> emptyList()
    }

    /** Competitions [caption] names, longest match first, each stretch of text counted once. */
    fun competitionsIn(caption: String): List<String> {
        var rest = caption
        val found = ArrayList<String>()
        competitions.forEach { c ->
            val r = Regex("""(?<![\w])""" + Regex.escape(c), RegexOption.IGNORE_CASE)
            if (r.containsMatchIn(rest)) { found += c; rest = r.replace(rest, " ") }
        }
        return found
    }

    private val months = listOf("january", "february", "march", "april", "may", "june", "july", "august", "september",
        "october", "november", "december")

    /** Dates written in a caption, like "October 28, 2026" or "28 October 2026". */
    fun datesIn(caption: String): List<LocalDate> {
        val m = months.joinToString("|")
        val us = Regex("""\b($m)\s+(\d{1,2}),?\s+(\d{4})\b""", RegexOption.IGNORE_CASE).findAll(caption).mapNotNull { x ->
            runCatching { LocalDate.of(x.groupValues[3].toInt(), months.indexOf(x.groupValues[1].lowercase()) + 1, x.groupValues[2].toInt()) }.getOrNull()
        }
        val uk = Regex("""\b(\d{1,2})\s+($m),?\s+(\d{4})\b""", RegexOption.IGNORE_CASE).findAll(caption).mapNotNull { x ->
            runCatching { LocalDate.of(x.groupValues[3].toInt(), months.indexOf(x.groupValues[2].lowercase()) + 1, x.groupValues[1].toInt()) }.getOrNull()
        }
        return (us + uk).toList()
    }

    /** Years written in a caption, like the "2024" in "the 2024 World Series". */
    fun yearsIn(caption: String): List<Int> =
        Regex("""\b(19[5-9]\d|20\d\d)\b""").findAll(caption).map { it.value.toInt() }.toList()

    /** Checks shared by games and events: a dated caption must fall inside the window, and a year must be this season's. */
    private fun inWindow(c: String, from: Instant, to: Instant): Boolean {
        val first = from.atZone(ZoneOffset.UTC).toLocalDate().minusDays(1)
        val last = to.atZone(ZoneOffset.UTC).toLocalDate().plusDays(1)
        if (datesIn(c).any { it.isBefore(first) || it.isAfter(last) }) return false
        val years = setOf(first.year - 1, first.year, last.year)
        return yearsIn(c).all { it in years }
    }

    /** What a game's photos are checked against. */
    class GameCheck(
        val ours: List<TeamRef>,
        val others: List<TeamRef>,
        val leagueKey: String,
        val leagueLabel: String,
        val note: String,
        val from: Instant,
        val to: Instant,
        val soccerLike: Boolean,
    )

    /**
     * Whether a photo belongs to this game, judged by its caption. News feeds carry photos from other games, so:
     *  - a photo naming a team that isn't playing is dropped
     *  - a news photo must name one of the two teams (the game's own recap may be uncaptioned)
     *  - a dated caption must fall around the game, and any year must be this season's
     *  - "Game 3" doesn't belong to Game 5, and a playoff round doesn't belong to a regular season game
     *  - in soccer and rugby, naming another competition (a league match photo in a cup game) is dropped
     */
    fun aboutGame(p: GamePhoto, k: GameCheck): Boolean {
        val c = p.caption
        if (c.isBlank()) return p.fromRecap
        val ourTerms = k.ours.flatMap { terms(it) }.distinct()
        if (!p.fromRecap && ourTerms.none { mentions(c, it) }) return false
        val otherTerms = k.others.filter { t -> k.ours.none { it.id == t.id } }.flatMap { terms(it) }
            .filter { t -> ourTerms.none { o -> o.contains(t, ignoreCase = true) } }
        if (otherTerms.any { mentions(c, it) }) return false
        if (!inWindow(c, k.from, k.to)) return false
        val ourGame = gameNumber(k.note)
        val captionGame = gameNumber(c)
        if (captionGame != null && captionGame != ourGame) return false
        if (k.note.isBlank() && rounds.any { mentions(c, it) }) return false
        if (k.soccerLike) {
            val own = ownCompetitions(k.leagueKey, k.leagueLabel)
            if (competitionsIn(c).any { named -> own.none { it.equals(named, true) } }) return false
        }
        return true
    }

    /**
     * Whether a photo belongs to an event (fight card, race weekend, tournament): its caption must name someone
     * competing in it, and any date or year must fit the event.
     */
    fun aboutEvent(p: GamePhoto, names: List<String>, from: Instant, to: Instant): Boolean {
        val c = p.caption
        if (c.isBlank() || names.isEmpty()) return false
        val hit = names.any { n ->
            val full = n.trim()
            // "J. Sinner" style names only match on the surname
            if (full.contains('.')) full.substringAfterLast(' ').let { it.length >= 4 && mentions(c, it) } else mentions(c, full)
        }
        return hit && inWindow(c, from, to)
    }

    /** The game number in a series note like "World Series · Game 5", or null. */
    fun gameNumber(note: String): Int? = Regex("""\bGame (\d+)\b""").find(note)?.groupValues?.get(1)?.toIntOrNull()

    /** Merge sources in order, dropping repeats. */
    fun merge(vararg lists: List<GamePhoto>): List<GamePhoto> {
        val seen = HashSet<String>()
        return lists.flatMap { it }.filter { p -> seen.add(key(p.url)) }
    }

    /** The window a team's game-day stories are taken from: three hours before the start to a day and a half after. */
    fun gameWindow(start: Instant): Pair<Instant, Instant> = start.minus(Duration.ofHours(3)) to start.plus(Duration.ofHours(36))

    /** The window for an event: half a day before it starts to a day and a half after it ends. */
    fun eventWindow(start: Instant, end: Instant?): Pair<Instant, Instant> =
        start.minus(Duration.ofHours(12)) to (end ?: start).plus(Duration.ofHours(36))
}
