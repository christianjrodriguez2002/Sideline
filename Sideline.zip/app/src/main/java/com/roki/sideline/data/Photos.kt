package com.roki.sideline.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant

/** A news photo from a game or event, with the caption and photographer credit ESPN publishes with it. */
data class GamePhoto(val url: String, val caption: String, val credit: String)

/**
 * Game and event photos from ESPN's free data. Sources, in the order they're shown:
 *  1. the recap story's photos, attached to the game summary
 *  2. related stories attached to the game summary
 *  3. each team's news from the game window (team sports)
 *  4. the league's news from the event window (UFC, racing, golf, tennis)
 * Logo composites ("stitcher" images) and tiny images are skipped, and the same photo is only shown once.
 */
object Photos {
    private fun JSONObject?.obj(k: String): JSONObject? = this?.optJSONObject(k)
    private fun JSONObject?.arr(k: String): JSONArray? = this?.optJSONArray(k)
    private fun JSONObject?.s(k: String): String = if (this == null || !has(k) || isNull(k)) "" else opt(k)?.toString().orEmpty()
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }

    /** Photos worth showing from one story's image list. */
    fun fromImages(images: JSONArray?): List<GamePhoto> = images.objects().mapNotNull { i ->
        val url = i.s("url").ifBlank { i.s("href") }
        if (!url.startsWith("http")) return@mapNotNull null
        val type = i.s("type").lowercase()
        if (type == "stitcher" || type == "logo" || url.contains("/teamlogos/")) return@mapNotNull null
        val w = i.optInt("width", 0)
        if (w in 1..299) return@mapNotNull null
        GamePhoto(url, i.s("caption").ifBlank { i.s("alt") }.ifBlank { i.s("name") }, i.s("credit"))
    }

    /** Sources 1 and 2: the recap and related stories inside a game summary. */
    fun fromSummary(root: JSONObject): List<GamePhoto> {
        val recap = fromImages(root.obj("article").arr("images"))
        val news = (root.obj("news").arr("articles") ?: root.arr("news")).objects().flatMap { fromImages(it.arr("images")) }
        return recap + news
    }

    /** Sources 3 and 4: every photo from news stories published inside [from]..[to]. */
    fun fromNews(root: JSONObject, from: Instant, to: Instant): List<GamePhoto> =
        (root.arr("articles") ?: root.arr("feed") ?: root.obj("news").arr("articles")).objects().flatMap { a ->
            val at = Parse.instant(a.s("published")) ?: return@flatMap emptyList()
            if (at.isBefore(from) || at.isAfter(to)) emptyList() else fromImages(a.arr("images"))
        }

    /** The same picture at another size has the same file name apart from a "_1296x729" style size tag. */
    fun key(url: String): String =
        url.substringAfterLast('/').substringBefore('?').substringBeforeLast('.').replace(Regex("""_\d+x\d+.*$"""), "").lowercase()

    /** Merge sources in order, dropping repeats. */
    fun merge(vararg lists: List<GamePhoto>): List<GamePhoto> {
        val seen = HashSet<String>()
        return lists.flatMap { it }.filter { p -> seen.add(key(p.url)) }
    }

    /** The window a team's game-day stories are taken from: three hours before the start to a day and a half after. */
    fun gameWindow(start: Instant): Pair<Instant, Instant> = start.minus(Duration.ofHours(3)) to start.plus(Duration.ofHours(36))

    /** The window for an event: half a day before it starts to a day and a half after it ends. */
    fun eventWindow(start: Instant, end: Instant?): Pair<Instant, Instant> =
        start.minus(Duration.ofHours(12)) to (end ?: start).plus(Duration.ofHours(36))
}
