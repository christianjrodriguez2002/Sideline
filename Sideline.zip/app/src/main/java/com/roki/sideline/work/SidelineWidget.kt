package com.roki.sideline.work

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.View
import android.widget.RemoteViews
import com.roki.sideline.MainActivity
import com.roki.sideline.R
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorite
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.LocalDate

/** One widget row: both teams with logos, the score or start time in the middle, and a status line. */
internal data class Row(
    val logoA: String, val a: String, val mid: String, val b: String, val logoB: String,
    val status: String, val live: Boolean,
)

/**
 * Home screen widget: a scoreboard row for each followed team, with logos, live score or start time, and status.
 * Android refreshes it every 30 minutes; the app also refreshes it whenever Home loads.
 */
class SidelineWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                refresh(context, manager, ids)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        private val ROWS = listOf(
            intArrayOf(R.id.row1, R.id.row1_logo_a, R.id.row1_a, R.id.row1_mid, R.id.row1_b, R.id.row1_logo_b, R.id.row1_status),
            intArrayOf(R.id.row2, R.id.row2_logo_a, R.id.row2_a, R.id.row2_mid, R.id.row2_b, R.id.row2_logo_b, R.id.row2_status),
            intArrayOf(R.id.row3, R.id.row3_logo_a, R.id.row3_a, R.id.row3_mid, R.id.row3_b, R.id.row3_logo_b, R.id.row3_status),
            intArrayOf(R.id.row4, R.id.row4_logo_a, R.id.row4_a, R.id.row4_mid, R.id.row4_b, R.id.row4_logo_b, R.id.row4_status),
        )
        private const val LIVE = 0xFFFF3B30.toInt()
        private const val SUB = 0xFF9BA8BC.toInt()
        private val logoCache = HashMap<String, Bitmap?>()

        /** Rebuild every placed widget from live data. Safe to call from any thread. */
        suspend fun update(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SidelineWidget::class.java))
            if (ids.isNotEmpty()) refresh(context, manager, ids)
        }

        private suspend fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
            Favorites.load(context)
            Settings.load(context)
            val favs = Favorites.list.toList().take(ROWS.size)
            val rows = coroutineScope { favs.map { f -> async { runCatching { row(f) }.getOrNull() } }.awaitAll() }.filterNotNull()
            val logos = rows.flatMap { listOf(it.logoA, it.logoB) }.distinct().filter { it.isNotBlank() }
                .associateWith { logo(it) }
            val rv = views(context, rows, logos, favs.isEmpty())
            ids.forEach { id -> manager.updateAppWidget(id, rv) }
        }

        private fun views(context: Context, rows: List<Row>, logos: Map<String, Bitmap?>, noTeams: Boolean): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget_sideline)
            ROWS.forEachIndexed { i, ids ->
                val r = rows.getOrNull(i)
                rv.setViewVisibility(ids[0], if (r == null) View.GONE else View.VISIBLE)
                if (r == null) return@forEachIndexed
                setLogo(rv, ids[1], logos[r.logoA])
                rv.setTextViewText(ids[2], r.a)
                rv.setTextViewText(ids[3], r.mid)
                rv.setTextViewText(ids[4], r.b)
                setLogo(rv, ids[5], logos[r.logoB])
                rv.setTextViewText(ids[6], r.status)
                rv.setTextColor(ids[6], if (r.live) LIVE else SUB)
            }
            rv.setViewVisibility(R.id.widget_empty, if (noTeams) View.VISIBLE else View.GONE)
            rv.setTextViewText(R.id.widget_empty, "Follow teams in Sideline to see them here")
            rv.setTextViewText(R.id.widget_updated, Fmt.time(Instant.now()))
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.widget_root, open)
            return rv
        }

        internal fun setLogo(rv: RemoteViews, id: Int, bmp: Bitmap?) {
            if (bmp != null) rv.setImageViewBitmap(id, bmp) else rv.setImageViewResource(id, R.drawable.ic_stat_sideline)
        }

        /** A small logo bitmap, fetched once per process; RemoteViews must stay light, so 72 px is plenty. */
        internal suspend fun logo(url: String): Bitmap? = withContext(Dispatchers.IO) {
            synchronized(logoCache) { if (logoCache.containsKey(url)) return@withContext logoCache[url] }
            val bmp = runCatching {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 10_000
                conn.readTimeout = 10_000
                try {
                    conn.inputStream.use { BitmapFactory.decodeStream(it) }?.let { Bitmap.createScaledBitmap(it, 72, 72, true) }
                } finally {
                    conn.disconnect()
                }
            }.getOrNull()
            synchronized(logoCache) { logoCache[url] = bmp }
            bmp
        }

        internal suspend fun row(f: Favorite): Row? {
            val league = f.league
            val id = f.team.id
            val today = LocalDate.now(Fmt.zone())
            val todays = runCatching {
                if (league.weekly) Espn.week(league, null).games else Espn.day(league, today)
            }.getOrDefault(emptyList()).filter { it.involves(id) }
            val schedule = runCatching { Espn.schedule(league, id) }.getOrDefault(emptyList())
            val live = todays.firstOrNull { it.state == GameState.IN } ?: schedule.firstOrNull { it.state == GameState.IN }
            val next = (todays + schedule).filter { it.state == GameState.PRE }.distinctBy { it.id }.minByOrNull { it.start ?: Instant.MAX }
            val last = (todays + schedule).filter { it.state == GameState.POST }.distinctBy { it.id }.maxByOrNull { it.start ?: Instant.MIN }
            val g = live ?: next ?: last
            if (g == null) return Row(f.team.logo, f.team.abbr, "", "", "", "No games scheduled", false)
            return gameRow(g, id)
        }

        /** A row for any game; [id] (a followed team) adds W/L to finals and picks vs/at. */
        internal fun gameRow(g: Game, id: String?): Row {
            val league = g.league
            return when (g.state) {
                GameState.IN -> Row(g.away.team.logo, g.away.team.abbr, "${g.away.score} - ${g.home.score}", g.home.team.abbr, g.home.team.logo,
                    "LIVE · " + g.statusShort.ifBlank { league.short }, true)
                GameState.PRE -> Row(g.away.team.logo, g.away.team.abbr, if (id != null && g.home.team.id == id) "vs" else "at", g.home.team.abbr, g.home.team.logo,
                    "${league.emoji} ${Fmt.whenText(g.start)}" + (g.broadcasts.firstOrNull()?.let { " · ${it.network}" } ?: ""), false)
                GameState.POST -> {
                    val tail = if (id != null) {
                        val me = g.sideOf(id)
                        val res = if (me.winner) "W" else if (g.opponentOf(id).winner) "L" else "D"
                        " · ${me.team.abbr} $res · ${Fmt.dayShort(g.start)}"
                    } else ""
                    Row(g.away.team.logo, g.away.team.abbr, "${g.away.score} - ${g.home.score}", g.home.team.abbr, g.home.team.logo,
                        g.statusShort.ifBlank { "Final" } + tail, false)
                }
            }
        }
    }
}
