package com.roki.sideline.work

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.roki.sideline.MainActivity
import com.roki.sideline.R
import com.roki.sideline.data.Espn
import com.roki.sideline.data.Favorite
import com.roki.sideline.data.Favorites
import com.roki.sideline.data.Fmt
import com.roki.sideline.data.Game
import com.roki.sideline.data.GameState
import com.roki.sideline.data.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate

/**
 * Home screen widget: one line per followed team with its live score, next game or last result.
 * Android refreshes it every 30 minutes; the app also refreshes it whenever Home loads.
 */
class SidelineWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                refresh(context, manager, ids)
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        private val LINES = intArrayOf(R.id.widget_line1, R.id.widget_line2, R.id.widget_line3, R.id.widget_line4)

        /** Rebuild every placed widget from live data. Safe to call from any thread. */
        suspend fun update(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, SidelineWidget::class.java))
            if (ids.isNotEmpty()) refresh(context, manager, ids)
        }

        private suspend fun refresh(context: Context, manager: AppWidgetManager, ids: IntArray) {
            Favorites.load(context)
            Settings.load(context)
            val favs = Favorites.list.toList().take(LINES.size)
            val lines = if (favs.isEmpty()) listOf("Follow teams in Sideline to see them here")
            else coroutineScope { favs.map { f -> async { runCatching { line(f) }.getOrElse { "${f.team.abbr}  ·  no data" } } }.awaitAll() }
            ids.forEach { id -> manager.updateAppWidget(id, views(context, lines)) }
        }

        private fun views(context: Context, lines: List<String>): RemoteViews {
            val rv = RemoteViews(context.packageName, R.layout.widget_sideline)
            LINES.forEachIndexed { i, viewId ->
                val text = lines.getOrNull(i)
                rv.setTextViewText(viewId, text ?: "")
                rv.setViewVisibility(viewId, if (text == null) android.view.View.GONE else android.view.View.VISIBLE)
            }
            rv.setTextViewText(R.id.widget_updated, "Updated ${Fmt.time(Instant.now())}")
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            rv.setOnClickPendingIntent(R.id.widget_root, open)
            return rv
        }

        /** "⚾ LAD 3-2 SF · Top 7th", "🏈 ARI at SEA · Sun 1:05pm" or "🏀 PHX · W 112-104 vs LAL". */
        private suspend fun line(f: Favorite): String {
            val league = f.league
            val id = f.team.id
            val today = LocalDate.now(Fmt.zone())
            val todays = runCatching {
                if (league.weekly) Espn.week(league, null).games else Espn.day(league, today)
            }.getOrDefault(emptyList()).filter { it.involves(id) }
            val schedule = runCatching { Espn.schedule(league, id) }.getOrDefault(emptyList())
            val live = todays.firstOrNull { it.state == GameState.IN } ?: schedule.firstOrNull { it.state == GameState.IN }
            val next = (todays + schedule).filter { it.state == GameState.PRE }.distinctBy { it.id }.minByOrNull { it.start ?: Instant.MAX }
            val last = (todays + schedule).filter { it.state == GameState.POST }.distinctBy { it.id }.maxByOrNull { it.start ?: Instant.MIN }
            val e = league.emoji
            return when {
                live != null -> "$e ${score(live)} · ${live.statusShort.ifBlank { "Live" }}"
                next != null -> "$e ${matchup(next, id)} · ${Fmt.whenText(next.start)}"
                last != null -> {
                    val me = last.sideOf(id)
                    val opp = last.opponentOf(id)
                    val r = if (me.winner) "W" else if (opp.winner) "L" else "D"
                    "$e ${f.team.abbr} · $r ${me.score}-${opp.score} ${if (me.home) "vs" else "at"} ${opp.team.abbr}"
                }
                else -> "$e ${f.team.abbr} · no games scheduled"
            }
        }

        private fun score(g: Game) = "${g.away.team.abbr} ${g.away.score}-${g.home.team.abbr} ${g.home.score}"
        private fun matchup(g: Game, id: String): String {
            val me = g.sideOf(id)
            val opp = g.opponentOf(id)
            return "${me.team.abbr} ${if (me.home) "vs" else "at"} ${opp.team.abbr}"
        }
    }
}
