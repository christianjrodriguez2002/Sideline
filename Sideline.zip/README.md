# Sideline

Made by Roki Rodriguez.

A personal, all-sports Android app with a dark, broadcast-style look. Built on ESPN's free public data feeds:
no account, no API key, no ads.

## Sports

| | Leagues |
| --- | --- |
| **US Pro** | NFL · NBA · MLB · NHL · WNBA · UFL |
| **Soccer** | Premier League · MLS · Champions League · LaLiga · Bundesliga · Serie A · Ligue 1 |
| **International soccer** | FIFA World Cup · UEFA Euro · Copa América (light up when the tournament is on) |
| **College** | College Football · Men's College Basketball · Women's College Basketball (with AP/Coaches rankings, Top 25 or all games) |
| **Combat** | UFC fight cards, main event first, with records and results |
| **Motorsports** | Formula 1 · NASCAR Cup · IndyCar: every session (practice, qualifying, sprint, race) with results and driver standings |
| **Golf & Tennis** | PGA Tour leaderboards · ATP and WTA tournaments with draws, rounds and set scores (Grand Slams included) |
| **Cricket & Rugby** | IPL first, plus other live cricket series · Six Nations · Rugby World Cup |
| **On the web** | Boxing, MotoGP and WWE have no free live-data feed, so they open their official schedules |

## Screens

- **Home**: greeting, your pinned leagues, a "Live & today" rail across your leagues, and a card for every team you
  follow: record and standing, live score, next game (TV, where it streams, win chance), last result, injury report,
  headlines.
- **Scores**: pinned leagues across the top; a day strip (or week, for football) for team sports; fight cards, race
  weekends, leaderboards and draws for event sports. Live games refresh on their own.
- **Leagues**: every sport by category. Each league has Scores, Standings, Rankings (college), Teams, Injuries,
  News and Moves (trades/signings), or Calendar for event sports.
- **Team pages**: schedule and results with recent form, roster, standings, injuries, news.
- **Game pages**: big score header in both teams' colors, scoring by period, win probability / prediction, where to
  watch, betting line (spread, total, moneylines incl. draw for soccer), live situation, key events / scoring plays,
  leaders, team-stat comparison bars, lineups (soccer), full box score, injuries.
- **Player pages**: bio, injury status, season & career stats, next game, news.
- **Settings**: your name for the greeting, clock style, game alerts, pinned-league order, followed teams.

## Your time zone

Every time and date follows your phone's time zone automatically (shown on screen, e.g. "Times in MST"). "Today" means
*your* today: ESPN files games under US Eastern dates, so the app pulls the day before and after too and keeps only the
games that start on your local date. That's what makes a 7:30 pm Phoenix tip-off, an 8 am Premier League kickoff or an
overnight IPL match land on the right day. The clock follows your phone's 12/24-hour setting, or pick one in Settings.

## Where you are: local channels and venue clocks

Set your location in Settings (📍 "Use my location", city-level only, or type a city/ZIP). The app then works out which
team TV areas you're inside:

- **National TV** shows the network and the app it usually streams on. Over-the-air networks (ABC, CBS, FOX, NBC)
  read "On your local FOX station" with a **Find it on your TV** link for your city.
- **Local channels** (regional sports networks) show as **📍 Your local channel** with its streaming app when you're in
  that team's area, or as blacked out with the league's out-of-market package when you're not. Score cards only show
  channels you can actually get.
- **NFL Sunday afternoons** carry a note that CBS/FOX games are regional.
- If the location came from your phone, it refreshes when you open the app, so it follows you when you travel.

Game pages show the start in **your time** and, when it's different, **the clock at the venue** (e.g. "9:30 pm EDT
local"). Race sessions and fight cards do the same for the track or arena.

TV areas are approximated by distance from each team's city, so the app says "area" rather than promising a channel.

## Photos

League and category headers use real photographs from Wikimedia Commons, all under free licenses (Creative Commons
or public domain), no AI images. Settings → Photo credits links each one to its page with photographer and license.
League logos come from ESPN alongside the team logos.

## Build the APK

Your repo (github.com/christianjrodriguez2002/Sideline) builds from `Sideline.zip`: its workflow unzips the file,
runs the parser tests, builds a signed release APK and publishes it as a GitHub Release.

**From your phone (or any browser)**

1. Open the repo on GitHub, tap `Sideline.zip`, then the trash/delete icon, and commit the deletion.
2. Tap **Add file → Upload files**, pick the new `Sideline.zip`, commit.
3. Open the **Actions** tab and wait for the green check (about 5 minutes).
4. Open **Releases** (right side of the repo page) → the newest "Sideline build N" → download `app-release.apk`
   and install it. Every build is signed with the same key, so it installs right over the previous version.

**From a computer with git** (source checked in instead of the zip)

Unzip into a folder, then `git init`, `git add .`, `git commit -m "Sideline 2.2"`, `git branch -M main`,
`git remote add origin https://github.com/YOUR-USERNAME/Sideline.git`, `git push -u origin main`. The workflow in
`.github/workflows/build-apk.yml` builds on every push and uploads the APK under the run's **Artifacts**.

## Notes

- ESPN's feeds are public but unofficial. If ESPN changes a feed, that screen may come up empty until the parser is
  updated. Every screen has a retry, and one broken item never takes down a list.
- "Where to stream" shows the real TV network, then where it usually streams. Blackouts and your TV plan still apply.
- For personal use. Team names and logos belong to their leagues and teams.

## Project layout

```
app/src/main/java/com/roki/sideline/
  data/   Models.kt  league catalog + models          Espn.kt   feeds, cache, local-day logic
          Parse.kt   JSON -> models (all sports)      Local.kt  favorites, pins, streaming map, prediction, time formatting
  work/   Alerts.kt  game-time and final-score notifications
  ui/     Theme, Kit (design system), HomeScreen, Browse (Scores/Leagues/Settings), LeagueScreen, EventViews,
          Games (game cards + game page), TeamScreen (+ player page)
app/src/test/  parser and time-zone tests on ESPN-shaped samples
```
